var class_phone_app_1_1_data_1_1_b_r_a_n_d =
[
    [ "BRAND", "class_phone_app_1_1_data_1_1_b_r_a_n_d.html#a42c00491169bb6a3210875db913cef29", null ],
    [ "Country_Name", "class_phone_app_1_1_data_1_1_b_r_a_n_d.html#ac172d3dde1c832ac8e5543e4d29f8355", null ],
    [ "Factory_inHungary", "class_phone_app_1_1_data_1_1_b_r_a_n_d.html#aa4d803f1a6838a406db42bafd80eb5bc", null ],
    [ "Id", "class_phone_app_1_1_data_1_1_b_r_a_n_d.html#abff9913a9f3bc66d67bc9ca253ed8560", null ],
    [ "Modell", "class_phone_app_1_1_data_1_1_b_r_a_n_d.html#a1b53a0cd8e9be4f452803377d69df124", null ],
    [ "Name", "class_phone_app_1_1_data_1_1_b_r_a_n_d.html#a8182ba9a97cdf3e6d26fb231bd50ed47", null ],
    [ "Reliability", "class_phone_app_1_1_data_1_1_b_r_a_n_d.html#a48910cf0df2ef9653b016a3a1b6ff2d9", null ],
    [ "Year_of_Foundation", "class_phone_app_1_1_data_1_1_b_r_a_n_d.html#aef3b6bc3ab80bfc47e31f47b4060605d", null ]
];