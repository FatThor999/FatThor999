var class_phone_app_1_1_data_1_1_modell =
[
    [ "Base_Price", "class_phone_app_1_1_data_1_1_modell.html#a6b3484b9f8f41e2d08b338bd28982bb8", null ],
    [ "BRAND", "class_phone_app_1_1_data_1_1_modell.html#a4905e448954c8cad88577a0234341f24", null ],
    [ "Brand_ID", "class_phone_app_1_1_data_1_1_modell.html#ad7bb08d08ab768463fc038e985204324", null ],
    [ "Display_Size", "class_phone_app_1_1_data_1_1_modell.html#a32f78d0a8541d0570c5362b3d838b469", null ],
    [ "Guarantee", "class_phone_app_1_1_data_1_1_modell.html#a42ec0da5d2b87752a92d158612679324", null ],
    [ "Id", "class_phone_app_1_1_data_1_1_modell.html#a4cf78afcd4b30ff7bb9c067264013e5f", null ],
    [ "Name", "class_phone_app_1_1_data_1_1_modell.html#acc18889f27932beff333c9f34fbb3c10", null ],
    [ "Operating_System", "class_phone_app_1_1_data_1_1_modell.html#a9044c37b745ed6233aadd6fb540daa40", null ],
    [ "Provider____", "class_phone_app_1_1_data_1_1_modell.html#a537445b7627b1d20e497fac951fc0216", null ],
    [ "Provider_ID", "class_phone_app_1_1_data_1_1_modell.html#a59322e3c4ad9e808e0ba913f06b2583b", null ]
];