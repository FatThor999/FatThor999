var class_phone_app_1_1_data_1_1_phone_database_entities =
[
    [ "PhoneDatabaseEntities", "class_phone_app_1_1_data_1_1_phone_database_entities.html#a8a90fdbeae5204feb78988234a9732ac", null ],
    [ "OnModelCreating", "class_phone_app_1_1_data_1_1_phone_database_entities.html#a874574a821b90780bfd27baafdfb0e1d", null ],
    [ "BRAND", "class_phone_app_1_1_data_1_1_phone_database_entities.html#a3d716628c84a2b3928f934e106f12219", null ],
    [ "Modell", "class_phone_app_1_1_data_1_1_phone_database_entities.html#a164e92679f95a18cca934d32a72446d1", null ],
    [ "Provider____", "class_phone_app_1_1_data_1_1_phone_database_entities.html#ab1561bba8fb6c766227f6e607e12a306", null ]
];