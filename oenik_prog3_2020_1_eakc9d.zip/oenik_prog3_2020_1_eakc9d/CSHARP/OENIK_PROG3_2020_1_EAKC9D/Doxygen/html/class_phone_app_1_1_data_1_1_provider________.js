var class_phone_app_1_1_data_1_1_provider________ =
[
    [ "Provider____", "class_phone_app_1_1_data_1_1_provider________.html#a0365e9a1ed0f042b77db401c7203c0d9", null ],
    [ "Country", "class_phone_app_1_1_data_1_1_provider________.html#a4848cc069d7daa0741fccf6db354a11e", null ],
    [ "Coverage", "class_phone_app_1_1_data_1_1_provider________.html#ad1fa0a55a09d5bd7950de0be4212eb4d", null ],
    [ "Id", "class_phone_app_1_1_data_1_1_provider________.html#aacb33a23bdb4fc6dbd034985dabd21d0", null ],
    [ "Modell", "class_phone_app_1_1_data_1_1_provider________.html#aee69fa1666b0462198b52c9e17f9bc00", null ],
    [ "Name", "class_phone_app_1_1_data_1_1_provider________.html#a5bfa3fe7f69e412ce35a89124d1bb20e", null ],
    [ "Reliability", "class_phone_app_1_1_data_1_1_provider________.html#a5afa6a96afef264f869c651e40013501", null ],
    [ "Year_of_Foundation", "class_phone_app_1_1_data_1_1_provider________.html#a4745f38ee801e65bd24def934b67c9cc", null ]
];