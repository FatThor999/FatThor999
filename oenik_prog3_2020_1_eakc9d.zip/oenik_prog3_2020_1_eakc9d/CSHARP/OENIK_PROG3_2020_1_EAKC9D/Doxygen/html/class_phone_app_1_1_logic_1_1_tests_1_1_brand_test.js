var class_phone_app_1_1_logic_1_1_tests_1_1_brand_test =
[
    [ "CreateTest", "class_phone_app_1_1_logic_1_1_tests_1_1_brand_test.html#ad920ebd2537dafaf988fdeccec750efa", null ],
    [ "DeleteTest", "class_phone_app_1_1_logic_1_1_tests_1_1_brand_test.html#ad3ef67ff764a8e0b9538cb21c0b3e3ad", null ],
    [ "GetAllTest", "class_phone_app_1_1_logic_1_1_tests_1_1_brand_test.html#ab6236006727360e656a203a71d277bde", null ],
    [ "Init", "class_phone_app_1_1_logic_1_1_tests_1_1_brand_test.html#adf35dc623db551698210788e836a010d", null ],
    [ "ReadTest", "class_phone_app_1_1_logic_1_1_tests_1_1_brand_test.html#a4f80ebd7729a4aff77278139c3961920", null ],
    [ "UpdateTest", "class_phone_app_1_1_logic_1_1_tests_1_1_brand_test.html#aefcf275967d72156872e9e7c60ec4877", null ]
];