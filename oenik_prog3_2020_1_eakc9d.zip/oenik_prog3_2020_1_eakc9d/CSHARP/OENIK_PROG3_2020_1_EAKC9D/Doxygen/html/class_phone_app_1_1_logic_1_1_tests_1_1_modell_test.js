var class_phone_app_1_1_logic_1_1_tests_1_1_modell_test =
[
    [ "CreateTest", "class_phone_app_1_1_logic_1_1_tests_1_1_modell_test.html#af5be4f248783c78747e068c816e4c2aa", null ],
    [ "DeleteTest", "class_phone_app_1_1_logic_1_1_tests_1_1_modell_test.html#ab70435736eea37de7516e61a1f7c46da", null ],
    [ "GetAllTest", "class_phone_app_1_1_logic_1_1_tests_1_1_modell_test.html#a09995b5d24c4db51485e2355b5a58db7", null ],
    [ "Init", "class_phone_app_1_1_logic_1_1_tests_1_1_modell_test.html#a2d354f09a679501a162f85c1cc112045", null ],
    [ "ReadTest", "class_phone_app_1_1_logic_1_1_tests_1_1_modell_test.html#a880a2c8884d2158230a2d2974408ee24", null ],
    [ "UpdateTest", "class_phone_app_1_1_logic_1_1_tests_1_1_modell_test.html#a30422ddb50c2520b21b7620e1e52b035", null ]
];