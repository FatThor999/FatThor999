var class_phone_app_1_1_logic_1_1_tests_1_1_not_crud_test =
[
    [ "Init", "class_phone_app_1_1_logic_1_1_tests_1_1_not_crud_test.html#a6e1f6a9a103eb17db634e492fe72cfa1", null ],
    [ "LongestAvaregeGuaranteeTest", "class_phone_app_1_1_logic_1_1_tests_1_1_not_crud_test.html#a38b6eb59c9b762ebcb4d5273774d762a", null ],
    [ "MostExpensiveModellTest", "class_phone_app_1_1_logic_1_1_tests_1_1_not_crud_test.html#ad3784aa53360a37df957f239b5b7058d", null ],
    [ "MostFamousProviderModells", "class_phone_app_1_1_logic_1_1_tests_1_1_not_crud_test.html#ad2984d94baae40cacfbb544d49c96f39", null ],
    [ "MostReliableModellTest", "class_phone_app_1_1_logic_1_1_tests_1_1_not_crud_test.html#aeeccdfa6085a1e4f7bc15f63b6037e8a", null ]
];