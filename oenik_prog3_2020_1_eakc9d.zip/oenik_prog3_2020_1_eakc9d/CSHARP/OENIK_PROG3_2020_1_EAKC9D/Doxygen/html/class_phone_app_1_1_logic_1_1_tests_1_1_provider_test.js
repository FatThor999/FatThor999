var class_phone_app_1_1_logic_1_1_tests_1_1_provider_test =
[
    [ "CreateTest", "class_phone_app_1_1_logic_1_1_tests_1_1_provider_test.html#af7bb88dac9797617e52b00da36b515f4", null ],
    [ "DeleteTest", "class_phone_app_1_1_logic_1_1_tests_1_1_provider_test.html#acfb75cd4716887c7c8dd56f2b1b861b8", null ],
    [ "GetAllTest", "class_phone_app_1_1_logic_1_1_tests_1_1_provider_test.html#a0a9ee20e37ed7c78612619ad8ed2867a", null ],
    [ "Init", "class_phone_app_1_1_logic_1_1_tests_1_1_provider_test.html#afff3d0549234a55157cb29685dc873d0", null ],
    [ "ReadTest", "class_phone_app_1_1_logic_1_1_tests_1_1_provider_test.html#a99bdb639883e72ac0f8b7712c539c7b4", null ],
    [ "UpdateTest", "class_phone_app_1_1_logic_1_1_tests_1_1_provider_test.html#ac8ba6ad14c72ce3163c8a54b660bbf07", null ]
];