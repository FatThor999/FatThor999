var class_phone_app_1_1_repository_1_1_repositories_1_1_brand_repository =
[
    [ "BrandRepository", "class_phone_app_1_1_repository_1_1_repositories_1_1_brand_repository.html#aff22815782a43578a41d7cdcd585aae0", null ],
    [ "Create", "class_phone_app_1_1_repository_1_1_repositories_1_1_brand_repository.html#aebe80a529b35d416b9ca50568a145947", null ],
    [ "Delete", "class_phone_app_1_1_repository_1_1_repositories_1_1_brand_repository.html#a531df0e126bc039feab317ad3bcd4f57", null ],
    [ "GetAll", "class_phone_app_1_1_repository_1_1_repositories_1_1_brand_repository.html#a375db39d744d26fd6d8c295786c7f7e3", null ],
    [ "GetById", "class_phone_app_1_1_repository_1_1_repositories_1_1_brand_repository.html#a12d8df7b84936e9e7c5a4461324b7e0e", null ],
    [ "Update", "class_phone_app_1_1_repository_1_1_repositories_1_1_brand_repository.html#a2203c637f1a24b7ebac3a8c1f610b8a5", null ]
];