var class_phone_app_1_1_repository_1_1_repositories_1_1_modell_repository =
[
    [ "ModellRepository", "class_phone_app_1_1_repository_1_1_repositories_1_1_modell_repository.html#acdd6342d97683db263e3e7758cef1358", null ],
    [ "Create", "class_phone_app_1_1_repository_1_1_repositories_1_1_modell_repository.html#a78a1f1ea1fc4ed48aafe3b5eaf561d5d", null ],
    [ "Delete", "class_phone_app_1_1_repository_1_1_repositories_1_1_modell_repository.html#acf7385c888ed206bb1fa4d7de45d185d", null ],
    [ "GetAll", "class_phone_app_1_1_repository_1_1_repositories_1_1_modell_repository.html#a18995b89106dcc661050f89cb4b9beb6", null ],
    [ "GetById", "class_phone_app_1_1_repository_1_1_repositories_1_1_modell_repository.html#a555f70e02fd3e5a350f2ad5e023a41a8", null ],
    [ "Update", "class_phone_app_1_1_repository_1_1_repositories_1_1_modell_repository.html#a1f166a4bc35825c6be9b5603b11e7321", null ]
];