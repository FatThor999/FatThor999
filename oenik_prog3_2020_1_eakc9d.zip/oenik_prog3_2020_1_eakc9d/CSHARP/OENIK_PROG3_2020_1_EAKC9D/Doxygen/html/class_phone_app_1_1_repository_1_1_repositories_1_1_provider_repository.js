var class_phone_app_1_1_repository_1_1_repositories_1_1_provider_repository =
[
    [ "ProviderRepository", "class_phone_app_1_1_repository_1_1_repositories_1_1_provider_repository.html#a3855de81173587c582be8d26aea1b77f", null ],
    [ "Create", "class_phone_app_1_1_repository_1_1_repositories_1_1_provider_repository.html#a2f06eaa2f66e8e26372e9c84688f7c4a", null ],
    [ "Delete", "class_phone_app_1_1_repository_1_1_repositories_1_1_provider_repository.html#ad4d96153e35e7834bec72b899bf88994", null ],
    [ "GetAll", "class_phone_app_1_1_repository_1_1_repositories_1_1_provider_repository.html#a4b69dca63e9589b7e9dc03014fc50d1d", null ],
    [ "GetById", "class_phone_app_1_1_repository_1_1_repositories_1_1_provider_repository.html#a04864ae9907cc03e26aebd55a9f6eaef", null ],
    [ "Update", "class_phone_app_1_1_repository_1_1_repositories_1_1_provider_repository.html#a07ae757dfafd642f2431de1b28091676", null ]
];