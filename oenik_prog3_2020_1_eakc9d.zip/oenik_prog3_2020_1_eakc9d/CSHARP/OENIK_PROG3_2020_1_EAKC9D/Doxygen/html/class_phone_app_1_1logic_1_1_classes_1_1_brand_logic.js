var class_phone_app_1_1logic_1_1_classes_1_1_brand_logic =
[
    [ "BrandLogic", "class_phone_app_1_1logic_1_1_classes_1_1_brand_logic.html#a9858227b9c1c33702186845d1b1c8caa", null ],
    [ "Create", "class_phone_app_1_1logic_1_1_classes_1_1_brand_logic.html#ac22725b93b2311acebeaf2957d96f880", null ],
    [ "Creates", "class_phone_app_1_1logic_1_1_classes_1_1_brand_logic.html#a2824827af03ec9bb3da48ff5fad3fc81", null ],
    [ "Delete", "class_phone_app_1_1logic_1_1_classes_1_1_brand_logic.html#ad30305907792039416e83840dc32166d", null ],
    [ "GetAll", "class_phone_app_1_1logic_1_1_classes_1_1_brand_logic.html#a9a46d8a490ac96d4a92f4fafbd776a21", null ],
    [ "GetById", "class_phone_app_1_1logic_1_1_classes_1_1_brand_logic.html#a0a8d38c3b8c674d7915e8c43923d0da0", null ],
    [ "Update", "class_phone_app_1_1logic_1_1_classes_1_1_brand_logic.html#a9f042b5d1395a7e95fcdc978f4b0ee76", null ]
];