var class_phone_app_1_1logic_1_1_classes_1_1_extra_functions =
[
    [ "ExtraFunctions", "class_phone_app_1_1logic_1_1_classes_1_1_extra_functions.html#ae783f716ef6839a25f57478902b7fef5", null ],
    [ "Creates", "class_phone_app_1_1logic_1_1_classes_1_1_extra_functions.html#a32089b02619e8ecfc6d4abe5a3c2d213", null ],
    [ "LongestAvaregeGuarantee", "class_phone_app_1_1logic_1_1_classes_1_1_extra_functions.html#a15460dcecb206ef846e9a763328ad528", null ],
    [ "MostExpensiveModell", "class_phone_app_1_1logic_1_1_classes_1_1_extra_functions.html#aa8918b6051b5bf625bda5c75e50d9b71", null ],
    [ "MostFamousProviderModells", "class_phone_app_1_1logic_1_1_classes_1_1_extra_functions.html#a20654628b2608376f541dbc8bd982a93", null ],
    [ "MostReliableModells", "class_phone_app_1_1logic_1_1_classes_1_1_extra_functions.html#ae69cba70a27c4590844adf604a0f955d", null ]
];