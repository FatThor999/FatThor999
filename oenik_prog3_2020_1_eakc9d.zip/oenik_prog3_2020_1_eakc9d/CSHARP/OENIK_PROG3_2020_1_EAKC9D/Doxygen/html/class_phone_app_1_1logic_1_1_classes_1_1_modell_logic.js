var class_phone_app_1_1logic_1_1_classes_1_1_modell_logic =
[
    [ "ModellLogic", "class_phone_app_1_1logic_1_1_classes_1_1_modell_logic.html#afb841b61d9617970fd306a738d4b1cfc", null ],
    [ "Create", "class_phone_app_1_1logic_1_1_classes_1_1_modell_logic.html#a6ae714d6be40d717204b2b4fbafea9d0", null ],
    [ "Creates", "class_phone_app_1_1logic_1_1_classes_1_1_modell_logic.html#afb9e0e46f1eef27133f21a4e35b056bc", null ],
    [ "Delete", "class_phone_app_1_1logic_1_1_classes_1_1_modell_logic.html#ac30efd9555e96fb3bc238e632a6c83b0", null ],
    [ "GetAll", "class_phone_app_1_1logic_1_1_classes_1_1_modell_logic.html#ac0ce21ea6545da1e7852bcbe2f916fa8", null ],
    [ "GetById", "class_phone_app_1_1logic_1_1_classes_1_1_modell_logic.html#ab0b577a8be3f80ba5a23dd509ba7d2ee", null ],
    [ "Update", "class_phone_app_1_1logic_1_1_classes_1_1_modell_logic.html#ab3cf96bf4f65a58aaa0d3bb96f08a1b9", null ]
];