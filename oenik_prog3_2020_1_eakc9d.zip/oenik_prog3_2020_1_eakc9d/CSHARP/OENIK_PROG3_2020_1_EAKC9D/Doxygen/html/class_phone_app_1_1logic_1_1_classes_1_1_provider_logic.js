var class_phone_app_1_1logic_1_1_classes_1_1_provider_logic =
[
    [ "ProviderLogic", "class_phone_app_1_1logic_1_1_classes_1_1_provider_logic.html#af923a87fd05475c07b5b9f3b71c42ebb", null ],
    [ "Create", "class_phone_app_1_1logic_1_1_classes_1_1_provider_logic.html#a886302b46afd9731f629c088bb7c8ae8", null ],
    [ "Creates", "class_phone_app_1_1logic_1_1_classes_1_1_provider_logic.html#a80b0a1683f617d423241edc9c8aae1ad", null ],
    [ "Delete", "class_phone_app_1_1logic_1_1_classes_1_1_provider_logic.html#af791f9923684aa093d805619da55ad17", null ],
    [ "GetAll", "class_phone_app_1_1logic_1_1_classes_1_1_provider_logic.html#a6f044b6df43d10a3842ce3784eb24515", null ],
    [ "GetById", "class_phone_app_1_1logic_1_1_classes_1_1_provider_logic.html#af622a046dc46069b7281a611a48f97be", null ],
    [ "Update", "class_phone_app_1_1logic_1_1_classes_1_1_provider_logic.html#a6824d4349c74fbafa633938174ed2050", null ]
];