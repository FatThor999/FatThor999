var dir_0240a88fed236f54cb1bf0017c4dc8fd =
[
    [ "AssemblyInfo.cs", "_phone_app_8_repository_2_properties_2_assembly_info_8cs_source.html", null ]
];