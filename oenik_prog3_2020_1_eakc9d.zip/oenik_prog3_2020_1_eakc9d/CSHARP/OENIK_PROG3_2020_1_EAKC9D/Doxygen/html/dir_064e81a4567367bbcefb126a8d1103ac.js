var dir_064e81a4567367bbcefb126a8d1103ac =
[
    [ "BrandLogic.cs", "_brand_logic_8cs_source.html", null ],
    [ "ExtraFunctions.cs", "_extra_functions_8cs_source.html", null ],
    [ "ModellLogic.cs", "_modell_logic_8cs_source.html", null ],
    [ "ProviderLogic.cs", "_provider_logic_8cs_source.html", null ]
];