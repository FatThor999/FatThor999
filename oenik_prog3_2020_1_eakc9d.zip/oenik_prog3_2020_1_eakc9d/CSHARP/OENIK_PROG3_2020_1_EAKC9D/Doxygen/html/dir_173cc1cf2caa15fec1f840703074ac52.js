var dir_173cc1cf2caa15fec1f840703074ac52 =
[
    [ "LICENSE.TXT", "_system_8_runtime_8_compiler_services_8_unsafe_84_85_80_2_l_i_c_e_n_s_e_8_t_x_t_source.html", null ],
    [ "THIRD-PARTY-NOTICES.TXT", "_system_8_runtime_8_compiler_services_8_unsafe_84_85_80_2_t_h_i_r_d-_p_a_r_t_y-_n_o_t_i_c_e_s_8_t_x_t_source.html", null ]
];