var dir_1c08934039bffc25cbe41fcb7eb8363c =
[
    [ "obj", "dir_1f667b2bb3f9409b651d4d52c9b2f44a.html", "dir_1f667b2bb3f9409b651d4d52c9b2f44a" ],
    [ "Properties", "dir_93edf07a433baa4b494f2fa369d72de8.html", "dir_93edf07a433baa4b494f2fa369d72de8" ],
    [ "BrandTest.cs", "_brand_test_8cs_source.html", null ],
    [ "ModellTest.cs", "_modell_test_8cs_source.html", null ],
    [ "NotCrudTest.cs", "_not_crud_test_8cs_source.html", null ],
    [ "ProviderTest.cs", "_provider_test_8cs_source.html", null ]
];