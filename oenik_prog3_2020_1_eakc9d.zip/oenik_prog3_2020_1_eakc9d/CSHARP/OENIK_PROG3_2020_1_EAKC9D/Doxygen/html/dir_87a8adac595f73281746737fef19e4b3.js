var dir_87a8adac595f73281746737fef19e4b3 =
[
    [ "packages", "dir_6498d144da3e524762c8c68384938e89.html", "dir_6498d144da3e524762c8c68384938e89" ],
    [ "PhoneApp.Data", "dir_e21fc0b465fc1ea3f2481c854dd1a6a1.html", "dir_e21fc0b465fc1ea3f2481c854dd1a6a1" ],
    [ "PhoneApp.logic", "dir_b3c252682593eabc5564dbe62910d8f9.html", "dir_b3c252682593eabc5564dbe62910d8f9" ],
    [ "PhoneApp.Logic.Tests", "dir_1c08934039bffc25cbe41fcb7eb8363c.html", "dir_1c08934039bffc25cbe41fcb7eb8363c" ],
    [ "PhoneApp.Program", "dir_94b8a1dd3146f5edc6acbb0a5312fae6.html", "dir_94b8a1dd3146f5edc6acbb0a5312fae6" ],
    [ "PhoneApp.Repository", "dir_637026a22739e75ee97d3d92a8d4f78a.html", "dir_637026a22739e75ee97d3d92a8d4f78a" ]
];