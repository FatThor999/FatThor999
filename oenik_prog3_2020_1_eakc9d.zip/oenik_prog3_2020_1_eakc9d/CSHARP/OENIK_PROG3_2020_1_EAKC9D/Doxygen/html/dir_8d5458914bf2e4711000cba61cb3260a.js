var dir_8d5458914bf2e4711000cba61cb3260a =
[
    [ "BrandRepository.cs", "_brand_repository_8cs_source.html", null ],
    [ "ModellRepository.cs", "_modell_repository_8cs_source.html", null ],
    [ "ProviderRepository.cs", "_provider_repository_8cs_source.html", null ]
];