var dir_93edf07a433baa4b494f2fa369d72de8 =
[
    [ "AssemblyInfo.cs", "_phone_app_8_logic_8_tests_2_properties_2_assembly_info_8cs_source.html", null ]
];