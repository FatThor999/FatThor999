var dir_94b8a1dd3146f5edc6acbb0a5312fae6 =
[
    [ "obj", "dir_316cfce66592522782304f7df163dad0.html", "dir_316cfce66592522782304f7df163dad0" ],
    [ "Properties", "dir_cd451b92b920e31a9af5aa8a1ae8d2cb.html", "dir_cd451b92b920e31a9af5aa8a1ae8d2cb" ],
    [ "GlobalSuppressions.cs", "_global_suppressions_8cs_source.html", null ],
    [ "Program.cs", "_program_8cs_source.html", null ]
];