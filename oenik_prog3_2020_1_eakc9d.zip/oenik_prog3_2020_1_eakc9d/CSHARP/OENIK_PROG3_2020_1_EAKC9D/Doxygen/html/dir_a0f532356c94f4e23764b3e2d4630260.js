var dir_a0f532356c94f4e23764b3e2d4630260 =
[
    [ "AssemblyInfo.cs", "_phone_app_8_data_2_properties_2_assembly_info_8cs_source.html", null ]
];