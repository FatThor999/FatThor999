var dir_ae23b19ff1b026fb19bc572a942a9376 =
[
    [ "AssemblyInfo.cs", "_phone_app_8logic_2_properties_2_assembly_info_8cs_source.html", null ]
];