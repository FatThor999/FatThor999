var dir_cd451b92b920e31a9af5aa8a1ae8d2cb =
[
    [ "AssemblyInfo.cs", "_phone_app_8_program_2_properties_2_assembly_info_8cs_source.html", null ]
];