var dir_d522931ffa1371640980b621734a4381 =
[
    [ "Patai Péter", "dir_d67bf311d0b7bb8e418a209933e83d13.html", "dir_d67bf311d0b7bb8e418a209933e83d13" ]
];