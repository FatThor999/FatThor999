var dir_e21fc0b465fc1ea3f2481c854dd1a6a1 =
[
    [ "obj", "dir_387b688bbd1c53a355a7f828ea0e9e60.html", "dir_387b688bbd1c53a355a7f828ea0e9e60" ],
    [ "Properties", "dir_a0f532356c94f4e23764b3e2d4630260.html", "dir_a0f532356c94f4e23764b3e2d4630260" ],
    [ "BRAND.cs", "_b_r_a_n_d_8cs_source.html", null ],
    [ "Model1.Context.cs", "_model1_8_context_8cs_source.html", null ],
    [ "Model1.cs", "_model1_8cs_source.html", null ],
    [ "Modell.cs", "_modell_8cs_source.html", null ],
    [ "PhoneModell.Designer.cs", "_phone_modell_8_designer_8cs_source.html", null ],
    [ "Provider____.cs", "_provider_________8cs_source.html", null ]
];