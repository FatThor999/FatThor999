var dir_e48d24a5510011f2a54022ec0ae0f8c7 =
[
    [ "LICENSE.TXT", "_system_8_threading_8_tasks_8_extensions_84_85_81_2_l_i_c_e_n_s_e_8_t_x_t_source.html", null ],
    [ "THIRD-PARTY-NOTICES.TXT", "_system_8_threading_8_tasks_8_extensions_84_85_81_2_t_h_i_r_d-_p_a_r_t_y-_n_o_t_i_c_e_s_8_t_x_t_source.html", null ]
];