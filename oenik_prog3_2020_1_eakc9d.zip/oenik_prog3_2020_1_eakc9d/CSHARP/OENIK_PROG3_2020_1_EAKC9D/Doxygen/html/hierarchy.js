var hierarchy =
[
    [ "PhoneApp.Data.BRAND", "class_phone_app_1_1_data_1_1_b_r_a_n_d.html", null ],
    [ "PhoneApp.Logic.Tests.BrandTest", "class_phone_app_1_1_logic_1_1_tests_1_1_brand_test.html", null ],
    [ "DbContext", null, [
      [ "PhoneApp.Data.PhoneDatabaseEntities", "class_phone_app_1_1_data_1_1_phone_database_entities.html", null ]
    ] ],
    [ "PhoneApp.logic.Classes.ExtraFunctions", "class_phone_app_1_1logic_1_1_classes_1_1_extra_functions.html", null ],
    [ "PhoneApp.logic.Interfaces.ILogic< T, TK >", "interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic.html", null ],
    [ "PhoneApp.logic.Interfaces.ILogic< BRAND, string >", "interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic.html", [
      [ "PhoneApp.logic.Classes.BrandLogic", "class_phone_app_1_1logic_1_1_classes_1_1_brand_logic.html", null ]
    ] ],
    [ "PhoneApp.logic.Interfaces.ILogic< Modell, string >", "interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic.html", [
      [ "PhoneApp.logic.Classes.ModellLogic", "class_phone_app_1_1logic_1_1_classes_1_1_modell_logic.html", null ]
    ] ],
    [ "PhoneApp.logic.Interfaces.ILogic< Provider____, string >", "interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic.html", [
      [ "PhoneApp.logic.Classes.ProviderLogic", "class_phone_app_1_1logic_1_1_classes_1_1_provider_logic.html", null ]
    ] ],
    [ "PhoneApp.Repository.Interfaces.IRepository< T, TK >", "interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html", null ],
    [ "PhoneApp.Repository.Interfaces.IRepository< BRAND, string >", "interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html", [
      [ "PhoneApp.Repository.Repositories.BrandRepository", "class_phone_app_1_1_repository_1_1_repositories_1_1_brand_repository.html", null ]
    ] ],
    [ "PhoneApp.Repository.Interfaces.IRepository< Modell, string >", "interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html", [
      [ "PhoneApp.Repository.Repositories.ModellRepository", "class_phone_app_1_1_repository_1_1_repositories_1_1_modell_repository.html", null ]
    ] ],
    [ "PhoneApp.Repository.Interfaces.IRepository< PhoneApp.Data.BRAND, string >", "interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html", null ],
    [ "PhoneApp.Repository.Interfaces.IRepository< PhoneApp.Data.Modell, string >", "interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html", null ],
    [ "PhoneApp.Repository.Interfaces.IRepository< PhoneApp.Data.Provider____, string >", "interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html", null ],
    [ "PhoneApp.Repository.Interfaces.IRepository< Provider____, string >", "interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html", [
      [ "PhoneApp.Repository.Repositories.ProviderRepository", "class_phone_app_1_1_repository_1_1_repositories_1_1_provider_repository.html", null ]
    ] ],
    [ "PhoneApp.Data.Modell", "class_phone_app_1_1_data_1_1_modell.html", null ],
    [ "PhoneApp.Logic.Tests.ModellTest", "class_phone_app_1_1_logic_1_1_tests_1_1_modell_test.html", null ],
    [ "PhoneApp.Logic.Tests.NotCrudTest", "class_phone_app_1_1_logic_1_1_tests_1_1_not_crud_test.html", null ],
    [ "PhoneApp.Program.Program", "class_phone_app_1_1_program_1_1_program.html", null ],
    [ "PhoneApp.Data.Provider____", "class_phone_app_1_1_data_1_1_provider________.html", null ],
    [ "PhoneApp.Logic.Tests.ProviderTest", "class_phone_app_1_1_logic_1_1_tests_1_1_provider_test.html", null ]
];