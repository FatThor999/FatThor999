var interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository =
[
    [ "Create", "interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html#a7b4bf9d38952aea06bd417ccc3ce47dc", null ],
    [ "Delete", "interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html#a2a6abfd14c8b4d1fcd80cab1ef98ebdc", null ],
    [ "GetAll", "interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html#a4e151e605bbe8fa162cd3fcad52e24ad", null ],
    [ "GetById", "interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html#a863ab93a4b138ff3bfe1732c9e6a128e", null ],
    [ "Update", "interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html#a35f691b7758a686dd0b3d46a8b0f3eff", null ]
];