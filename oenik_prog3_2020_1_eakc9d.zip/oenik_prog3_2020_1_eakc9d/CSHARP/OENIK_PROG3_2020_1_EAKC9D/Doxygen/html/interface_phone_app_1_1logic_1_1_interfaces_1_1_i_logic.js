var interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic =
[
    [ "Create", "interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic.html#a8f4babb2af7647eab0afb76c662e6872", null ],
    [ "Delete", "interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic.html#a421d1edb831fe2a38f7288456f50e1bc", null ],
    [ "GetAll", "interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic.html#a1479c78f1d65fd13dbde3985927e97d8", null ],
    [ "GetById", "interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic.html#ac4659cc4c5f3faa5dc045ed7d430b27a", null ],
    [ "Update", "interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic.html#a4ec63c61a295c904e09550dce532611c", null ]
];