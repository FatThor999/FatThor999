var namespace_phone_app =
[
    [ "Data", "namespace_phone_app_1_1_data.html", "namespace_phone_app_1_1_data" ],
    [ "Logic", "namespace_phone_app_1_1_logic.html", "namespace_phone_app_1_1_logic" ],
    [ "logic", "namespace_phone_app_1_1logic.html", "namespace_phone_app_1_1logic" ],
    [ "Program", "namespace_phone_app_1_1_program.html", "namespace_phone_app_1_1_program" ],
    [ "Repository", "namespace_phone_app_1_1_repository.html", "namespace_phone_app_1_1_repository" ]
];