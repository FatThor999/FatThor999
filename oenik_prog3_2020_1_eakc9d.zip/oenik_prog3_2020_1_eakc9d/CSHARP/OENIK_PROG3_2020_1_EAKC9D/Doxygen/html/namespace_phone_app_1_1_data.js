var namespace_phone_app_1_1_data =
[
    [ "BRAND", "class_phone_app_1_1_data_1_1_b_r_a_n_d.html", "class_phone_app_1_1_data_1_1_b_r_a_n_d" ],
    [ "Modell", "class_phone_app_1_1_data_1_1_modell.html", "class_phone_app_1_1_data_1_1_modell" ],
    [ "PhoneDatabaseEntities", "class_phone_app_1_1_data_1_1_phone_database_entities.html", "class_phone_app_1_1_data_1_1_phone_database_entities" ],
    [ "Provider____", "class_phone_app_1_1_data_1_1_provider________.html", "class_phone_app_1_1_data_1_1_provider________" ]
];