var namespace_phone_app_1_1_logic =
[
    [ "Tests", "namespace_phone_app_1_1_logic_1_1_tests.html", "namespace_phone_app_1_1_logic_1_1_tests" ]
];