var namespace_phone_app_1_1_logic_1_1_tests =
[
    [ "BrandTest", "class_phone_app_1_1_logic_1_1_tests_1_1_brand_test.html", "class_phone_app_1_1_logic_1_1_tests_1_1_brand_test" ],
    [ "ModellTest", "class_phone_app_1_1_logic_1_1_tests_1_1_modell_test.html", "class_phone_app_1_1_logic_1_1_tests_1_1_modell_test" ],
    [ "NotCrudTest", "class_phone_app_1_1_logic_1_1_tests_1_1_not_crud_test.html", "class_phone_app_1_1_logic_1_1_tests_1_1_not_crud_test" ],
    [ "ProviderTest", "class_phone_app_1_1_logic_1_1_tests_1_1_provider_test.html", "class_phone_app_1_1_logic_1_1_tests_1_1_provider_test" ]
];