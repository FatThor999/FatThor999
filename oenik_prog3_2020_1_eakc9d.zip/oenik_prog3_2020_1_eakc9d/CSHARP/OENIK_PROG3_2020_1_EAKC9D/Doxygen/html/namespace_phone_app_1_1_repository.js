var namespace_phone_app_1_1_repository =
[
    [ "Interfaces", "namespace_phone_app_1_1_repository_1_1_interfaces.html", "namespace_phone_app_1_1_repository_1_1_interfaces" ],
    [ "Repositories", "namespace_phone_app_1_1_repository_1_1_repositories.html", "namespace_phone_app_1_1_repository_1_1_repositories" ]
];