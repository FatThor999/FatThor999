var namespace_phone_app_1_1_repository_1_1_interfaces =
[
    [ "IRepository", "interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html", "interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository" ]
];