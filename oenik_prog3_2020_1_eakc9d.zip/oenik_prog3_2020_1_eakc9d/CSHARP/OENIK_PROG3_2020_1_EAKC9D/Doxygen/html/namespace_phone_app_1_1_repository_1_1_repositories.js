var namespace_phone_app_1_1_repository_1_1_repositories =
[
    [ "BrandRepository", "class_phone_app_1_1_repository_1_1_repositories_1_1_brand_repository.html", "class_phone_app_1_1_repository_1_1_repositories_1_1_brand_repository" ],
    [ "ModellRepository", "class_phone_app_1_1_repository_1_1_repositories_1_1_modell_repository.html", "class_phone_app_1_1_repository_1_1_repositories_1_1_modell_repository" ],
    [ "ProviderRepository", "class_phone_app_1_1_repository_1_1_repositories_1_1_provider_repository.html", "class_phone_app_1_1_repository_1_1_repositories_1_1_provider_repository" ]
];