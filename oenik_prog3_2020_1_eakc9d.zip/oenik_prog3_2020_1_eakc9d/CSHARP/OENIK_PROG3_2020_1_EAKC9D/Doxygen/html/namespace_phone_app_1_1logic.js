var namespace_phone_app_1_1logic =
[
    [ "Classes", "namespace_phone_app_1_1logic_1_1_classes.html", "namespace_phone_app_1_1logic_1_1_classes" ],
    [ "Interfaces", "namespace_phone_app_1_1logic_1_1_interfaces.html", "namespace_phone_app_1_1logic_1_1_interfaces" ]
];