var namespace_phone_app_1_1logic_1_1_classes =
[
    [ "BrandLogic", "class_phone_app_1_1logic_1_1_classes_1_1_brand_logic.html", "class_phone_app_1_1logic_1_1_classes_1_1_brand_logic" ],
    [ "ExtraFunctions", "class_phone_app_1_1logic_1_1_classes_1_1_extra_functions.html", "class_phone_app_1_1logic_1_1_classes_1_1_extra_functions" ],
    [ "ModellLogic", "class_phone_app_1_1logic_1_1_classes_1_1_modell_logic.html", "class_phone_app_1_1logic_1_1_classes_1_1_modell_logic" ],
    [ "ProviderLogic", "class_phone_app_1_1logic_1_1_classes_1_1_provider_logic.html", "class_phone_app_1_1logic_1_1_classes_1_1_provider_logic" ]
];