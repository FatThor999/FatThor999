var namespace_phone_app_1_1logic_1_1_interfaces =
[
    [ "ILogic", "interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic.html", "interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic" ]
];