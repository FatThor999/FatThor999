var namespaces_dup =
[
    [ "NUnit 3.11 - October 6, 2018", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md190", [
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md189", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md191", null ]
    ] ],
    [ "NUnit 3.10.1 - March 12, 2018", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md192", null ],
    [ "NUnit 3.10 - March 12, 2018", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md193", [
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md194", null ]
    ] ],
    [ "NUnit 3.9 - November 10, 2017", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md195", [
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md196", null ]
    ] ],
    [ "NUnit 3.8.1 - August 28, 2017", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md197", [
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md198", null ]
    ] ],
    [ "NUnit 3.8 - August 27, 2017", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md199", [
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md200", null ]
    ] ],
    [ "NUnit 3.7.1 - June 6, 2017", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md201", [
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md202", null ]
    ] ],
    [ "NUnit 3.7 - May 29, 2017", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md203", [
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md204", null ]
    ] ],
    [ "NUnit 3.6.1 - February 26, 2017", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md205", [
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md206", null ]
    ] ],
    [ "NUnit 3.6 - January 9, 2017", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md207", [
      [ "Framework", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md208", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md209", null ]
    ] ],
    [ "NUnit 3.5 - October 3, 2016", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md210", [
      [ "Framework", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md211", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md212", null ]
    ] ],
    [ "NUnit 3.4.1 - June 30, 2016", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md213", [
      [ "Console Runner", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md214", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md215", null ]
    ] ],
    [ "NUnit 3.4 - June 25, 2016", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md216", [
      [ "Framework", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md217", null ],
      [ "Engine", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md218", null ],
      [ "Console Runner", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md219", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md220", null ]
    ] ],
    [ "NUnit 3.2.1 - April 19, 2016", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md221", [
      [ "Framework", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md222", null ],
      [ "Engine", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md223", null ],
      [ "Console Runner", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md224", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md225", null ]
    ] ],
    [ "NUnit 3.2 - March 5, 2016", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md226", [
      [ "Framework", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md227", null ],
      [ "Engine", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md228", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md229", null ]
    ] ],
    [ "NUnit 3.0.1 - December 1, 2015", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md230", [
      [ "Console Runner", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md231", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md232", null ]
    ] ],
    [ "NUnit 3.0.0 Final Release - November 15, 2015", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md233", [
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md234", null ]
    ] ],
    [ "NUnit 3.0.0 Release Candidate 3 - November 13, 2015", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md235", [
      [ "Engine", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md236", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md237", null ]
    ] ],
    [ "NUnit 3.0.0 Release Candidate 2 - November 8, 2015", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md238", [
      [ "Engine", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md239", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md240", null ]
    ] ],
    [ "NUnit 3.0.0 Release Candidate - November 1, 2015", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md241", [
      [ "Framework", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md242", null ],
      [ "NUnitLite", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md243", null ],
      [ "Engine", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md244", null ],
      [ "Console Runner", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md245", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md246", null ]
    ] ],
    [ "NUnit 3.0.0 Beta 5 - October 16, 2015", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md247", [
      [ "Framework", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md248", null ],
      [ "Engine", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md249", null ],
      [ "Console Runner", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md250", [
        [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md251", null ]
      ] ]
    ] ],
    [ "NUnit 3.0.0 Beta 4 - August 25, 2015", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md252", [
      [ "Framework", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md253", null ],
      [ "Engine", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md254", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md255", null ]
    ] ],
    [ "NUnit 3.0.0 Beta 3 - July 15, 2015", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md256", [
      [ "Framework", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md257", null ],
      [ "Engine", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md258", null ],
      [ "Console", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md259", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md260", null ]
    ] ],
    [ "NUnit 3.0.0 Beta 2 - May 12, 2015", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md261", [
      [ "Framework", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md262", null ],
      [ "Engine", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md263", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md264", null ]
    ] ],
    [ "NUnit 3.0.0 Beta 1 - March 25, 2015", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md265", [
      [ "General", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md266", null ],
      [ "Framework", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md267", null ],
      [ "Engine", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md268", null ],
      [ "Console", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md269", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md270", null ]
    ] ],
    [ "NUnit 3.0.0 Alpha 5 - January 30, 2015", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md271", [
      [ "General", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md272", null ],
      [ "Framework", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md273", null ],
      [ "Engine", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md274", null ],
      [ "Console", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md275", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md276", null ]
    ] ],
    [ "NUnit 3.0.0 Alpha 4 - December 30, 2014", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md277", [
      [ "Framework", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md278", null ],
      [ "Engine", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md279", null ],
      [ "Console", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md280", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md281", null ]
    ] ],
    [ "NUnit 3.0.0 Alpha 3 - November 29, 2014", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md282", [
      [ "Breaking Changes", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md283", null ],
      [ "Framework", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md284", null ],
      [ "Engine", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md285", null ],
      [ "Console", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md286", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md287", null ]
    ] ],
    [ "NUnit 3.0.0 Alpha 2 - November 2, 2014", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md288", [
      [ "Breaking Changes", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md289", null ],
      [ "General", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md290", null ],
      [ "New Features", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md291", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md292", null ]
    ] ],
    [ "NUnit 3.0.0 Alpha 1 - September 22, 2014", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md293", [
      [ "Breaking Changes", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md294", null ],
      [ "General", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md295", null ],
      [ "New Features", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md296", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md297", null ],
      [ "Console Issues Resolved (Old nunit-console project, now combined with nunit)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md298", null ]
    ] ],
    [ "NUnit 2.9.7 - August 8, 2014", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md299", [
      [ "Breaking Changes", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md300", null ],
      [ "New Features", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md301", null ],
      [ "Issues Resolved", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md302", null ]
    ] ],
    [ "NUnit 2.9.6 - October 4, 2013", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md303", [
      [ "Main Features", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md304", null ],
      [ "Bug Fixes", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md305", null ],
      [ "Bug Fixes in 2.9.6 But Not Listed Here in the Release", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md306", null ]
    ] ],
    [ "NUnit 2.9.5 - July 30, 2010", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md307", [
      [ "Bug Fixes", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md308", null ]
    ] ],
    [ "NUnit 2.9.4 - May 4, 2010", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md309", [
      [ "Bug Fixes", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md310", null ]
    ] ],
    [ "NUnit 2.9.3 - October 26, 2009", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md311", [
      [ "Main Features", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md312", null ],
      [ "Bug Fixes", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md313", null ]
    ] ],
    [ "NUnit 2.9.2 - September 19, 2009", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md314", [
      [ "Main Features", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md315", null ],
      [ "Bug Fixes", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md316", null ]
    ] ],
    [ "NUnit 2.9.1 - August 27, 2009", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md317", [
      [ "General", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md318", null ],
      [ "Bug Fixes", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html#autotoc_md319", null ]
    ] ],
    [ "PhoneApp", "namespace_phone_app.html", "namespace_phone_app" ]
];