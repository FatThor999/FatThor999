/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "OENIK_Prog3_2020_EAKC9D_1", "index.html", [
    [ "Castle Core Changelog", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html", [
      [ "4.4.0 (2019-04-05)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md1", null ],
      [ "4.3.1 (2018-06-21)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md2", null ],
      [ "4.3.0 (2018-06-07)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md3", null ],
      [ "4.2.1 (2017-10-11)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md4", null ],
      [ "4.2.0 (2017-09-28)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md5", null ],
      [ "4.1.1 (2017-07-12)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md6", null ],
      [ "4.1.0 (2017-06-11)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md7", null ],
      [ "4.0.0 (2017-01-25)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md8", null ],
      [ "4.0.0-beta002 (2016-10-28)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md9", null ],
      [ "4.0.0-beta001 (2016-07-17)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md10", null ],
      [ "4.0.0-alpha001 (2016-04-07)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md11", null ],
      [ "3.3.3 (2014-11-06)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md12", null ],
      [ "3.3.2 (2014-11-03)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md13", null ],
      [ "3.3.1 (2014-09-10)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md14", null ],
      [ "3.3.0 (2014-04-27)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md15", null ],
      [ "3.2.2 (2013-11-30)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md16", null ],
      [ "3.2.1 (2013-10-05)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md17", null ],
      [ "3.2.0 (2013-02-16)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md18", null ],
      [ "3.1.0 (2012-08-05)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md19", null ],
      [ "3.1.0 RC (2012-07-08)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md20", null ],
      [ "3.0.0 (2011-12-13)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md21", null ],
      [ "3.0.0 RC 1 (2011-11-20)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md22", null ],
      [ "3.0.0 beta 1 (2011-08-14)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md23", null ],
      [ "2.5.2 (2010-11-15)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md24", null ],
      [ "2.5.1 (2010-09-21)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md25", null ],
      [ "2.5.0 (2010-08-21)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md26", null ],
      [ "1.2.0 (2010-01-11)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md27", null ],
      [ "1.2.0 beta (2009-12-04)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md28", null ],
      [ "1.1.0 (2009-05-04)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md29", null ],
      [ "Release Candidate 3", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md30", null ],
      [ "0.0.1.0", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md31", null ]
    ] ],
    [ "Analyzer Configuration", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html", [
      [ ".editorconfig format", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md33", null ],
      [ "Enabling .editorconfig based configuration for a project", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md34", null ],
      [ "Supported .editorconfig options", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md35", [
        [ "Analyzed API surface", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md36", null ],
        [ "Analyzed output kinds", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md37", null ],
        [ "Required modifiers for analyzed APIs", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md38", null ],
        [ "Async void methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md39", null ],
        [ "Single letter type parameters", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md40", null ],
        [ "Exclude extension method 'this' parameter", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md41", null ],
        [ "Null check validation methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md42", null ],
        [ "Additional string formatting methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md43", null ],
        [ "Excluded symbol names", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md44", null ],
        [ "Excluded type names with derived types", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md45", null ],
        [ "Unsafe DllImportSearchPath bits when using DefaultDllImportSearchPaths attribute", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md46", null ],
        [ "Exclude ASP.NET Core MVC ControllerBase when considering CSRF", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md47", null ],
        [ "Disallowed symbol names", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md48", null ],
        [ "Dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md49", [
          [ "Interprocedural analysis Kind", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md50", null ],
          [ "Maximum method call chain length to analyze for interprocedural dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md51", null ],
          [ "Maximum lambda or local function call chain length to analyze for interprocedural dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md52", null ],
          [ "Dispose analysis kind for IDisposable rules", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md53", null ],
          [ "Configure dispose ownership transfer for arguments passed to constructor invocation", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md54", null ],
          [ "Configure dispose ownership transfer for disposable objects passed as arguments to method calls", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md55", null ],
          [ "Configure execution of Copy analysis (tracks value and reference copies)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md56", null ],
          [ "Configure sufficient IterationCount when using weak KDF algorithm", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k4df46256299d5e2b6b1b9bf94191004c.html#autotoc_md57", null ]
        ] ]
      ] ]
    ] ],
    [ "Microsoft", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kaca687030bb2454103adab8f16f6c04b.html", null ],
    [ "Analyzer Configuration", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html", [
      [ ".editorconfig format", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md59", null ],
      [ "Enabling .editorconfig based configuration for a project", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md60", null ],
      [ "Supported .editorconfig options", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md61", [
        [ "Analyzed API surface", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md62", null ],
        [ "Analyzed output kinds", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md63", null ],
        [ "Required modifiers for analyzed APIs", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md64", null ],
        [ "Async void methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md65", null ],
        [ "Single letter type parameters", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md66", null ],
        [ "Exclude extension method 'this' parameter", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md67", null ],
        [ "Null check validation methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md68", null ],
        [ "Additional string formatting methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md69", null ],
        [ "Excluded symbol names", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md70", null ],
        [ "Excluded type names with derived types", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md71", null ],
        [ "Unsafe DllImportSearchPath bits when using DefaultDllImportSearchPaths attribute", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md72", null ],
        [ "Exclude ASP.NET Core MVC ControllerBase when considering CSRF", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md73", null ],
        [ "Disallowed symbol names", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md74", null ],
        [ "Dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md75", [
          [ "Interprocedural analysis Kind", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md76", null ],
          [ "Maximum method call chain length to analyze for interprocedural dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md77", null ],
          [ "Maximum lambda or local function call chain length to analyze for interprocedural dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md78", null ],
          [ "Dispose analysis kind for IDisposable rules", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md79", null ],
          [ "Configure dispose ownership transfer for arguments passed to constructor invocation", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md80", null ],
          [ "Configure dispose ownership transfer for disposable objects passed as arguments to method calls", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md81", null ],
          [ "Configure execution of Copy analysis (tracks value and reference copies)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md82", null ],
          [ "Configure sufficient IterationCount when using weak KDF algorithm", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k1f8e826fe92497094dd497b69702f05a.html#autotoc_md83", null ]
        ] ]
      ] ]
    ] ],
    [ "Microsoft", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k6a293fadd5811a113feb9e44a7b22784.html", null ],
    [ "Analyzer Configuration", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html", [
      [ ".editorconfig format", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md85", null ],
      [ "Enabling .editorconfig based configuration for a project", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md86", null ],
      [ "Supported .editorconfig options", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md87", [
        [ "Analyzed API surface", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md88", null ],
        [ "Analyzed output kinds", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md89", null ],
        [ "Required modifiers for analyzed APIs", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md90", null ],
        [ "Async void methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md91", null ],
        [ "Single letter type parameters", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md92", null ],
        [ "Exclude extension method 'this' parameter", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md93", null ],
        [ "Null check validation methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md94", null ],
        [ "Additional string formatting methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md95", null ],
        [ "Excluded symbol names", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md96", null ],
        [ "Excluded type names with derived types", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md97", null ],
        [ "Unsafe DllImportSearchPath bits when using DefaultDllImportSearchPaths attribute", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md98", null ],
        [ "Exclude ASP.NET Core MVC ControllerBase when considering CSRF", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md99", null ],
        [ "Disallowed symbol names", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md100", null ],
        [ "Dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md101", [
          [ "Interprocedural analysis Kind", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md102", null ],
          [ "Maximum method call chain length to analyze for interprocedural dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md103", null ],
          [ "Maximum lambda or local function call chain length to analyze for interprocedural dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md104", null ],
          [ "Dispose analysis kind for IDisposable rules", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md105", null ],
          [ "Configure dispose ownership transfer for arguments passed to constructor invocation", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md106", null ],
          [ "Configure dispose ownership transfer for disposable objects passed as arguments to method calls", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md107", null ],
          [ "Configure execution of Copy analysis (tracks value and reference copies)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md108", null ],
          [ "Configure sufficient IterationCount when using weak KDF algorithm", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc93f78dadb1332ff3f7faca2ef8120b3.html#autotoc_md109", null ]
        ] ]
      ] ]
    ] ],
    [ "Microsoft", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfa66e199b0426761624bef122d93aa9c.html", null ],
    [ "Analyzer Configuration", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html", [
      [ ".editorconfig format", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md111", null ],
      [ "Enabling .editorconfig based configuration for a project", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md112", null ],
      [ "Supported .editorconfig options", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md113", [
        [ "Analyzed API surface", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md114", null ],
        [ "Analyzed output kinds", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md115", null ],
        [ "Required modifiers for analyzed APIs", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md116", null ],
        [ "Async void methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md117", null ],
        [ "Single letter type parameters", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md118", null ],
        [ "Exclude extension method 'this' parameter", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md119", null ],
        [ "Null check validation methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md120", null ],
        [ "Additional string formatting methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md121", null ],
        [ "Excluded symbol names", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md122", null ],
        [ "Excluded type names with derived types", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md123", null ],
        [ "Unsafe DllImportSearchPath bits when using DefaultDllImportSearchPaths attribute", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md124", null ],
        [ "Exclude ASP.NET Core MVC ControllerBase when considering CSRF", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md125", null ],
        [ "Disallowed symbol names", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md126", null ],
        [ "Dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md127", [
          [ "Interprocedural analysis Kind", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md128", null ],
          [ "Maximum method call chain length to analyze for interprocedural dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md129", null ],
          [ "Maximum lambda or local function call chain length to analyze for interprocedural dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md130", null ],
          [ "Dispose analysis kind for IDisposable rules", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md131", null ],
          [ "Configure dispose ownership transfer for arguments passed to constructor invocation", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md132", null ],
          [ "Configure dispose ownership transfer for disposable objects passed as arguments to method calls", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md133", null ],
          [ "Configure execution of Copy analysis (tracks value and reference copies)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md134", null ],
          [ "Configure sufficient IterationCount when using weak KDF algorithm", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kc974445d21bf962e66d8b72b66d9e5a4.html#autotoc_md135", null ]
        ] ]
      ] ]
    ] ],
    [ "Microsoft", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k8214562d71af04667c15ea9472515d53.html", null ],
    [ "Analyzer Configuration", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html", [
      [ ".editorconfig format", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md137", null ],
      [ "Enabling .editorconfig based configuration for a project", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md138", null ],
      [ "Supported .editorconfig options", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md139", [
        [ "Analyzed API surface", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md140", null ],
        [ "Analyzed output kinds", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md141", null ],
        [ "Required modifiers for analyzed APIs", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md142", null ],
        [ "Async void methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md143", null ],
        [ "Single letter type parameters", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md144", null ],
        [ "Exclude extension method 'this' parameter", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md145", null ],
        [ "Null check validation methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md146", null ],
        [ "Additional string formatting methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md147", null ],
        [ "Excluded symbol names", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md148", null ],
        [ "Excluded type names with derived types", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md149", null ],
        [ "Unsafe DllImportSearchPath bits when using DefaultDllImportSearchPaths attribute", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md150", null ],
        [ "Exclude ASP.NET Core MVC ControllerBase when considering CSRF", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md151", null ],
        [ "Disallowed symbol names", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md152", null ],
        [ "Dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md153", [
          [ "Interprocedural analysis Kind", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md154", null ],
          [ "Maximum method call chain length to analyze for interprocedural dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md155", null ],
          [ "Maximum lambda or local function call chain length to analyze for interprocedural dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md156", null ],
          [ "Dispose analysis kind for IDisposable rules", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md157", null ],
          [ "Configure dispose ownership transfer for arguments passed to constructor invocation", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md158", null ],
          [ "Configure dispose ownership transfer for disposable objects passed as arguments to method calls", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md159", null ],
          [ "Configure execution of Copy analysis (tracks value and reference copies)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md160", null ],
          [ "Configure sufficient IterationCount when using weak KDF algorithm", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kfc09d0dae8baa62cc637800bf9dc5db7.html#autotoc_md161", null ]
        ] ]
      ] ]
    ] ],
    [ "Microsoft", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k6be56803d40f26f3ba3fc75ef9dd3cfd.html", null ],
    [ "Analyzer Configuration", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html", [
      [ ".editorconfig format", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md163", null ],
      [ "Enabling .editorconfig based configuration for a project", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md164", null ],
      [ "Supported .editorconfig options", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md165", [
        [ "Analyzed API surface", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md166", null ],
        [ "Analyzed output kinds", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md167", null ],
        [ "Required modifiers for analyzed APIs", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md168", null ],
        [ "Async void methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md169", null ],
        [ "Single letter type parameters", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md170", null ],
        [ "Exclude extension method 'this' parameter", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md171", null ],
        [ "Null check validation methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md172", null ],
        [ "Additional string formatting methods", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md173", null ],
        [ "Excluded symbol names", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md174", null ],
        [ "Excluded type names with derived types", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md175", null ],
        [ "Unsafe DllImportSearchPath bits when using DefaultDllImportSearchPaths attribute", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md176", null ],
        [ "Exclude ASP.NET Core MVC ControllerBase when considering CSRF", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md177", null ],
        [ "Disallowed symbol names", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md178", null ],
        [ "Dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md179", [
          [ "Interprocedural analysis Kind", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md180", null ],
          [ "Maximum method call chain length to analyze for interprocedural dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md181", null ],
          [ "Maximum lambda or local function call chain length to analyze for interprocedural dataflow analysis", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md182", null ],
          [ "Dispose analysis kind for IDisposable rules", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md183", null ],
          [ "Configure dispose ownership transfer for arguments passed to constructor invocation", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md184", null ],
          [ "Configure dispose ownership transfer for disposable objects passed as arguments to method calls", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md185", null ],
          [ "Configure execution of Copy analysis (tracks value and reference copies)", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md186", null ],
          [ "Configure sufficient IterationCount when using weak KDF algorithm", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md187", null ]
        ] ]
      ] ]
    ] ],
    [ "Microsoft", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k66a23d73db046adb2cf67708cfd983e8.html", null ],
    [ "NUnit 3.12 - May 14, 2019", "md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html", null ],
    [ "Packages", "namespaces.html", [
      [ "Packages", "namespaces.html", "namespaces_dup" ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ],
        [ "Properties", "functions_prop.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_b_r_a_n_d_8cs_source.html",
"md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html#autotoc_md19",
"md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_kf6e4c787470a9d71099a896009703457.html#autotoc_md176"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';