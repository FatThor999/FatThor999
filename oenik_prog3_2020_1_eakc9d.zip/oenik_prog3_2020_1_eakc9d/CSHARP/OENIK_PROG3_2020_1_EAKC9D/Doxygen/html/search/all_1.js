var searchData=
[
  ['base_5fprice_6',['Base_Price',['../class_phone_app_1_1_data_1_1_modell.html#a6b3484b9f8f41e2d08b338bd28982bb8',1,'PhoneApp::Data::Modell']]],
  ['brand_7',['BRAND',['../class_phone_app_1_1_data_1_1_b_r_a_n_d.html',1,'PhoneApp.Data.BRAND'],['../class_phone_app_1_1_data_1_1_phone_database_entities.html#a3d716628c84a2b3928f934e106f12219',1,'PhoneApp.Data.PhoneDatabaseEntities.BRAND()'],['../class_phone_app_1_1_data_1_1_modell.html#a4905e448954c8cad88577a0234341f24',1,'PhoneApp.Data.Modell.BRAND()'],['../class_phone_app_1_1_data_1_1_b_r_a_n_d.html#a42c00491169bb6a3210875db913cef29',1,'PhoneApp.Data.BRAND.BRAND()']]],
  ['brand_5fid_8',['Brand_ID',['../class_phone_app_1_1_data_1_1_modell.html#ad7bb08d08ab768463fc038e985204324',1,'PhoneApp::Data::Modell']]],
  ['brandlogic_9',['BrandLogic',['../class_phone_app_1_1logic_1_1_classes_1_1_brand_logic.html',1,'PhoneApp.logic.Classes.BrandLogic'],['../class_phone_app_1_1logic_1_1_classes_1_1_brand_logic.html#a9858227b9c1c33702186845d1b1c8caa',1,'PhoneApp.logic.Classes.BrandLogic.BrandLogic()']]],
  ['brandrepository_10',['BrandRepository',['../class_phone_app_1_1_repository_1_1_repositories_1_1_brand_repository.html',1,'PhoneApp.Repository.Repositories.BrandRepository'],['../class_phone_app_1_1_repository_1_1_repositories_1_1_brand_repository.html#aff22815782a43578a41d7cdcd585aae0',1,'PhoneApp.Repository.Repositories.BrandRepository.BrandRepository()']]],
  ['brandtest_11',['BrandTest',['../class_phone_app_1_1_logic_1_1_tests_1_1_brand_test.html',1,'PhoneApp::Logic::Tests']]]
];
