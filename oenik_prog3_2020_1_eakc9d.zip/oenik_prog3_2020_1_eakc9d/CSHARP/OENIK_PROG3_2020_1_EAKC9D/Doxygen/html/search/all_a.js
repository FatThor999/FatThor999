var searchData=
[
  ['nunit_203_2e12_20_2d_20may_2014_2c_202019_58',['NUnit 3.12 - May 14, 2019',['../md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html',1,'']]],
  ['name_59',['Name',['../class_phone_app_1_1_data_1_1_b_r_a_n_d.html#a8182ba9a97cdf3e6d26fb231bd50ed47',1,'PhoneApp.Data.BRAND.Name()'],['../class_phone_app_1_1_data_1_1_modell.html#acc18889f27932beff333c9f34fbb3c10',1,'PhoneApp.Data.Modell.Name()'],['../class_phone_app_1_1_data_1_1_provider________.html#a5bfa3fe7f69e412ce35a89124d1bb20e',1,'PhoneApp.Data.Provider____.Name()']]],
  ['notcrudtest_60',['NotCrudTest',['../class_phone_app_1_1_logic_1_1_tests_1_1_not_crud_test.html',1,'PhoneApp::Logic::Tests']]]
];
