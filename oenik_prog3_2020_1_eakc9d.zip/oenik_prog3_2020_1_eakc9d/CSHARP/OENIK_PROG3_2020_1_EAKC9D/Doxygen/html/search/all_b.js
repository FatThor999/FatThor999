var searchData=
[
  ['onmodelcreating_61',['OnModelCreating',['../class_phone_app_1_1_data_1_1_phone_database_entities.html#a874574a821b90780bfd27baafdfb0e1d',1,'PhoneApp::Data::PhoneDatabaseEntities']]],
  ['operating_5fsystem_62',['Operating_System',['../class_phone_app_1_1_data_1_1_modell.html#a9044c37b745ed6233aadd6fb540daa40',1,'PhoneApp::Data::Modell']]]
];
