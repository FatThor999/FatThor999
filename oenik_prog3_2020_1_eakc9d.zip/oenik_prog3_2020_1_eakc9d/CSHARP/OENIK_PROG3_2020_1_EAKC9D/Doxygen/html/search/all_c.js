var searchData=
[
  ['classes_63',['Classes',['../namespace_phone_app_1_1logic_1_1_classes.html',1,'PhoneApp::logic']]],
  ['data_64',['Data',['../namespace_phone_app_1_1_data.html',1,'PhoneApp']]],
  ['interfaces_65',['Interfaces',['../namespace_phone_app_1_1logic_1_1_interfaces.html',1,'PhoneApp.logic.Interfaces'],['../namespace_phone_app_1_1_repository_1_1_interfaces.html',1,'PhoneApp.Repository.Interfaces']]],
  ['logic_66',['Logic',['../namespace_phone_app_1_1_logic.html',1,'PhoneApp.Logic'],['../namespace_phone_app_1_1logic.html',1,'PhoneApp.logic']]],
  ['phoneapp_67',['PhoneApp',['../namespace_phone_app.html',1,'']]],
  ['phonedatabaseentities_68',['PhoneDatabaseEntities',['../class_phone_app_1_1_data_1_1_phone_database_entities.html',1,'PhoneApp.Data.PhoneDatabaseEntities'],['../class_phone_app_1_1_data_1_1_phone_database_entities.html#a8a90fdbeae5204feb78988234a9732ac',1,'PhoneApp.Data.PhoneDatabaseEntities.PhoneDatabaseEntities()']]],
  ['program_69',['Program',['../class_phone_app_1_1_program_1_1_program.html',1,'PhoneApp.Program.Program'],['../namespace_phone_app_1_1_program.html',1,'PhoneApp.Program']]],
  ['provider_5f_5f_5f_5f_70',['Provider____',['../class_phone_app_1_1_data_1_1_provider________.html',1,'PhoneApp.Data.Provider____'],['../class_phone_app_1_1_data_1_1_phone_database_entities.html#ab1561bba8fb6c766227f6e607e12a306',1,'PhoneApp.Data.PhoneDatabaseEntities.Provider____()'],['../class_phone_app_1_1_data_1_1_modell.html#a537445b7627b1d20e497fac951fc0216',1,'PhoneApp.Data.Modell.Provider____()'],['../class_phone_app_1_1_data_1_1_provider________.html#a0365e9a1ed0f042b77db401c7203c0d9',1,'PhoneApp.Data.Provider____.Provider____()']]],
  ['provider_5fid_71',['Provider_ID',['../class_phone_app_1_1_data_1_1_modell.html#a59322e3c4ad9e808e0ba913f06b2583b',1,'PhoneApp::Data::Modell']]],
  ['providerlogic_72',['ProviderLogic',['../class_phone_app_1_1logic_1_1_classes_1_1_provider_logic.html',1,'PhoneApp.logic.Classes.ProviderLogic'],['../class_phone_app_1_1logic_1_1_classes_1_1_provider_logic.html#af923a87fd05475c07b5b9f3b71c42ebb',1,'PhoneApp.logic.Classes.ProviderLogic.ProviderLogic()']]],
  ['providerrepository_73',['ProviderRepository',['../class_phone_app_1_1_repository_1_1_repositories_1_1_provider_repository.html',1,'PhoneApp.Repository.Repositories.ProviderRepository'],['../class_phone_app_1_1_repository_1_1_repositories_1_1_provider_repository.html#a3855de81173587c582be8d26aea1b77f',1,'PhoneApp.Repository.Repositories.ProviderRepository.ProviderRepository()']]],
  ['providertest_74',['ProviderTest',['../class_phone_app_1_1_logic_1_1_tests_1_1_provider_test.html',1,'PhoneApp::Logic::Tests']]],
  ['repositories_75',['Repositories',['../namespace_phone_app_1_1_repository_1_1_repositories.html',1,'PhoneApp::Repository']]],
  ['repository_76',['Repository',['../namespace_phone_app_1_1_repository.html',1,'PhoneApp']]],
  ['tests_77',['Tests',['../namespace_phone_app_1_1_logic_1_1_tests.html',1,'PhoneApp::Logic']]]
];
