var searchData=
[
  ['brand_83',['BRAND',['../class_phone_app_1_1_data_1_1_b_r_a_n_d.html',1,'PhoneApp::Data']]],
  ['brandlogic_84',['BrandLogic',['../class_phone_app_1_1logic_1_1_classes_1_1_brand_logic.html',1,'PhoneApp::logic::Classes']]],
  ['brandrepository_85',['BrandRepository',['../class_phone_app_1_1_repository_1_1_repositories_1_1_brand_repository.html',1,'PhoneApp::Repository::Repositories']]],
  ['brandtest_86',['BrandTest',['../class_phone_app_1_1_logic_1_1_tests_1_1_brand_test.html',1,'PhoneApp::Logic::Tests']]]
];
