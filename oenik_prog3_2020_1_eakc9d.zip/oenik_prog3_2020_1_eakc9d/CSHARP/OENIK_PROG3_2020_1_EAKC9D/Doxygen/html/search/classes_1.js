var searchData=
[
  ['extrafunctions_87',['ExtraFunctions',['../class_phone_app_1_1logic_1_1_classes_1_1_extra_functions.html',1,'PhoneApp::logic::Classes']]]
];
