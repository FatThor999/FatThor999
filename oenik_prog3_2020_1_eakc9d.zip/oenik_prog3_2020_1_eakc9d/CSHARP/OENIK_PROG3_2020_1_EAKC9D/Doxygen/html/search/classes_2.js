var searchData=
[
  ['ilogic_88',['ILogic',['../interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic.html',1,'PhoneApp::logic::Interfaces']]],
  ['ilogic_3c_20brand_2c_20string_20_3e_89',['ILogic&lt; BRAND, string &gt;',['../interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic.html',1,'PhoneApp::logic::Interfaces']]],
  ['ilogic_3c_20modell_2c_20string_20_3e_90',['ILogic&lt; Modell, string &gt;',['../interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic.html',1,'PhoneApp::logic::Interfaces']]],
  ['ilogic_3c_20provider_5f_5f_5f_5f_2c_20string_20_3e_91',['ILogic&lt; Provider____, string &gt;',['../interface_phone_app_1_1logic_1_1_interfaces_1_1_i_logic.html',1,'PhoneApp::logic::Interfaces']]],
  ['irepository_92',['IRepository',['../interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html',1,'PhoneApp::Repository::Interfaces']]],
  ['irepository_3c_20brand_2c_20string_20_3e_93',['IRepository&lt; BRAND, string &gt;',['../interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html',1,'PhoneApp::Repository::Interfaces']]],
  ['irepository_3c_20modell_2c_20string_20_3e_94',['IRepository&lt; Modell, string &gt;',['../interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html',1,'PhoneApp::Repository::Interfaces']]],
  ['irepository_3c_20phoneapp_3a_3adata_3a_3abrand_2c_20string_20_3e_95',['IRepository&lt; PhoneApp::Data::BRAND, string &gt;',['../interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html',1,'PhoneApp::Repository::Interfaces']]],
  ['irepository_3c_20phoneapp_3a_3adata_3a_3amodell_2c_20string_20_3e_96',['IRepository&lt; PhoneApp::Data::Modell, string &gt;',['../interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html',1,'PhoneApp::Repository::Interfaces']]],
  ['irepository_3c_20phoneapp_3a_3adata_3a_3aprovider_5f_5f_5f_5f_2c_20string_20_3e_97',['IRepository&lt; PhoneApp::Data::Provider____, string &gt;',['../interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html',1,'PhoneApp::Repository::Interfaces']]],
  ['irepository_3c_20provider_5f_5f_5f_5f_2c_20string_20_3e_98',['IRepository&lt; Provider____, string &gt;',['../interface_phone_app_1_1_repository_1_1_interfaces_1_1_i_repository.html',1,'PhoneApp::Repository::Interfaces']]]
];
