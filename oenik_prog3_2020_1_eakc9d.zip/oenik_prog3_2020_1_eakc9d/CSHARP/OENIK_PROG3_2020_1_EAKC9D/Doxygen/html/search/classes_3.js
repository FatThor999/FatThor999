var searchData=
[
  ['modell_99',['Modell',['../class_phone_app_1_1_data_1_1_modell.html',1,'PhoneApp::Data']]],
  ['modelllogic_100',['ModellLogic',['../class_phone_app_1_1logic_1_1_classes_1_1_modell_logic.html',1,'PhoneApp::logic::Classes']]],
  ['modellrepository_101',['ModellRepository',['../class_phone_app_1_1_repository_1_1_repositories_1_1_modell_repository.html',1,'PhoneApp::Repository::Repositories']]],
  ['modelltest_102',['ModellTest',['../class_phone_app_1_1_logic_1_1_tests_1_1_modell_test.html',1,'PhoneApp::Logic::Tests']]]
];
