var searchData=
[
  ['notcrudtest_103',['NotCrudTest',['../class_phone_app_1_1_logic_1_1_tests_1_1_not_crud_test.html',1,'PhoneApp::Logic::Tests']]]
];
