var searchData=
[
  ['brand_119',['BRAND',['../class_phone_app_1_1_data_1_1_b_r_a_n_d.html#a42c00491169bb6a3210875db913cef29',1,'PhoneApp::Data::BRAND']]],
  ['brandlogic_120',['BrandLogic',['../class_phone_app_1_1logic_1_1_classes_1_1_brand_logic.html#a9858227b9c1c33702186845d1b1c8caa',1,'PhoneApp::logic::Classes::BrandLogic']]],
  ['brandrepository_121',['BrandRepository',['../class_phone_app_1_1_repository_1_1_repositories_1_1_brand_repository.html#aff22815782a43578a41d7cdcd585aae0',1,'PhoneApp::Repository::Repositories::BrandRepository']]]
];
