var searchData=
[
  ['extrafunctions_127',['ExtraFunctions',['../class_phone_app_1_1logic_1_1_classes_1_1_extra_functions.html#ae783f716ef6839a25f57478902b7fef5',1,'PhoneApp::logic::Classes::ExtraFunctions']]]
];
