var searchData=
[
  ['init_131',['Init',['../class_phone_app_1_1_logic_1_1_tests_1_1_brand_test.html#adf35dc623db551698210788e836a010d',1,'PhoneApp.Logic.Tests.BrandTest.Init()'],['../class_phone_app_1_1_logic_1_1_tests_1_1_modell_test.html#a2d354f09a679501a162f85c1cc112045',1,'PhoneApp.Logic.Tests.ModellTest.Init()'],['../class_phone_app_1_1_logic_1_1_tests_1_1_not_crud_test.html#a6e1f6a9a103eb17db634e492fe72cfa1',1,'PhoneApp.Logic.Tests.NotCrudTest.Init()'],['../class_phone_app_1_1_logic_1_1_tests_1_1_provider_test.html#afff3d0549234a55157cb29685dc873d0',1,'PhoneApp.Logic.Tests.ProviderTest.Init()']]]
];
