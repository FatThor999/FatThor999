var searchData=
[
  ['longestavaregeguarantee_132',['LongestAvaregeGuarantee',['../class_phone_app_1_1logic_1_1_classes_1_1_extra_functions.html#a15460dcecb206ef846e9a763328ad528',1,'PhoneApp::logic::Classes::ExtraFunctions']]],
  ['longestavaregeguaranteetest_133',['LongestAvaregeGuaranteeTest',['../class_phone_app_1_1_logic_1_1_tests_1_1_not_crud_test.html#a38b6eb59c9b762ebcb4d5273774d762a',1,'PhoneApp::Logic::Tests::NotCrudTest']]]
];
