var searchData=
[
  ['readtest_146',['ReadTest',['../class_phone_app_1_1_logic_1_1_tests_1_1_brand_test.html#a4f80ebd7729a4aff77278139c3961920',1,'PhoneApp.Logic.Tests.BrandTest.ReadTest()'],['../class_phone_app_1_1_logic_1_1_tests_1_1_modell_test.html#a880a2c8884d2158230a2d2974408ee24',1,'PhoneApp.Logic.Tests.ModellTest.ReadTest()'],['../class_phone_app_1_1_logic_1_1_tests_1_1_provider_test.html#a99bdb639883e72ac0f8b7712c539c7b4',1,'PhoneApp.Logic.Tests.ProviderTest.ReadTest()']]]
];
