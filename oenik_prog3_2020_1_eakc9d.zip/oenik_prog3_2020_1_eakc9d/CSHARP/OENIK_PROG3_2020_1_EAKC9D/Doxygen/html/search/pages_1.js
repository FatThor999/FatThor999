var searchData=
[
  ['castle_20core_20changelog_172',['Castle Core Changelog',['../md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k22ac094a2534b6cf83b5b70a6dd1f4ef.html',1,'']]]
];
