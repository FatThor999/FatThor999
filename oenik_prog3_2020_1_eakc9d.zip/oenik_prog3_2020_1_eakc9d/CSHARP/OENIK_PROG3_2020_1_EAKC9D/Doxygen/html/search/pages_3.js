var searchData=
[
  ['nunit_203_2e12_20_2d_20may_2014_2c_202019_179',['NUnit 3.12 - May 14, 2019',['../md__c_1__users__patai__p_xC3_xA9ter__documents_oenik_prog3_2020_1_eakc9d__c_s_h_a_r_p__o_e_n_i_k9fb664a22cfe65ed1a747aa7f746d31e.html',1,'']]]
];
