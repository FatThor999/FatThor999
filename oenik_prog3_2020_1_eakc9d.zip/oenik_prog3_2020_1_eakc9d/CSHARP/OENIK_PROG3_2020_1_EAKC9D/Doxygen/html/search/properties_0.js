var searchData=
[
  ['base_5fprice_149',['Base_Price',['../class_phone_app_1_1_data_1_1_modell.html#a6b3484b9f8f41e2d08b338bd28982bb8',1,'PhoneApp::Data::Modell']]],
  ['brand_150',['BRAND',['../class_phone_app_1_1_data_1_1_phone_database_entities.html#a3d716628c84a2b3928f934e106f12219',1,'PhoneApp.Data.PhoneDatabaseEntities.BRAND()'],['../class_phone_app_1_1_data_1_1_modell.html#a4905e448954c8cad88577a0234341f24',1,'PhoneApp.Data.Modell.BRAND()']]],
  ['brand_5fid_151',['Brand_ID',['../class_phone_app_1_1_data_1_1_modell.html#ad7bb08d08ab768463fc038e985204324',1,'PhoneApp::Data::Modell']]]
];
