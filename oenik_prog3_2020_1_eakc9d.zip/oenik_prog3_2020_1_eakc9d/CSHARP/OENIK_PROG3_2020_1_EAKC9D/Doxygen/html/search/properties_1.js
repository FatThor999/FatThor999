var searchData=
[
  ['country_152',['Country',['../class_phone_app_1_1_data_1_1_provider________.html#a4848cc069d7daa0741fccf6db354a11e',1,'PhoneApp::Data::Provider____']]],
  ['country_5fname_153',['Country_Name',['../class_phone_app_1_1_data_1_1_b_r_a_n_d.html#ac172d3dde1c832ac8e5543e4d29f8355',1,'PhoneApp::Data::BRAND']]],
  ['coverage_154',['Coverage',['../class_phone_app_1_1_data_1_1_provider________.html#ad1fa0a55a09d5bd7950de0be4212eb4d',1,'PhoneApp::Data::Provider____']]]
];
