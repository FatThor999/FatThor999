var searchData=
[
  ['display_5fsize_155',['Display_Size',['../class_phone_app_1_1_data_1_1_modell.html#a32f78d0a8541d0570c5362b3d838b469',1,'PhoneApp::Data::Modell']]]
];
