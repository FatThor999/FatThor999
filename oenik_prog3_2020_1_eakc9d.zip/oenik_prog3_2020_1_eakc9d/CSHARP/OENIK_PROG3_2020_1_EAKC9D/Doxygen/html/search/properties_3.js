var searchData=
[
  ['factory_5finhungary_156',['Factory_inHungary',['../class_phone_app_1_1_data_1_1_b_r_a_n_d.html#aa4d803f1a6838a406db42bafd80eb5bc',1,'PhoneApp::Data::BRAND']]]
];
