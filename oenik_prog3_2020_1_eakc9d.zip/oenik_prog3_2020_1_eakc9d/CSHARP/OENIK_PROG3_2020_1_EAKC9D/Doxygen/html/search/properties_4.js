var searchData=
[
  ['guarantee_157',['Guarantee',['../class_phone_app_1_1_data_1_1_modell.html#a42ec0da5d2b87752a92d158612679324',1,'PhoneApp::Data::Modell']]]
];
