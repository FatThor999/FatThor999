var searchData=
[
  ['id_158',['Id',['../class_phone_app_1_1_data_1_1_b_r_a_n_d.html#abff9913a9f3bc66d67bc9ca253ed8560',1,'PhoneApp.Data.BRAND.Id()'],['../class_phone_app_1_1_data_1_1_modell.html#a4cf78afcd4b30ff7bb9c067264013e5f',1,'PhoneApp.Data.Modell.Id()'],['../class_phone_app_1_1_data_1_1_provider________.html#aacb33a23bdb4fc6dbd034985dabd21d0',1,'PhoneApp.Data.Provider____.Id()']]]
];
