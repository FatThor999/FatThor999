var searchData=
[
  ['modell_159',['Modell',['../class_phone_app_1_1_data_1_1_b_r_a_n_d.html#a1b53a0cd8e9be4f452803377d69df124',1,'PhoneApp.Data.BRAND.Modell()'],['../class_phone_app_1_1_data_1_1_phone_database_entities.html#a164e92679f95a18cca934d32a72446d1',1,'PhoneApp.Data.PhoneDatabaseEntities.Modell()'],['../class_phone_app_1_1_data_1_1_provider________.html#aee69fa1666b0462198b52c9e17f9bc00',1,'PhoneApp.Data.Provider____.Modell()']]]
];
