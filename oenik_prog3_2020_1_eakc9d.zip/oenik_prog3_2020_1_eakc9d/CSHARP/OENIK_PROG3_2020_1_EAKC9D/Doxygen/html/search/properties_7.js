var searchData=
[
  ['name_160',['Name',['../class_phone_app_1_1_data_1_1_b_r_a_n_d.html#a8182ba9a97cdf3e6d26fb231bd50ed47',1,'PhoneApp.Data.BRAND.Name()'],['../class_phone_app_1_1_data_1_1_modell.html#acc18889f27932beff333c9f34fbb3c10',1,'PhoneApp.Data.Modell.Name()'],['../class_phone_app_1_1_data_1_1_provider________.html#a5bfa3fe7f69e412ce35a89124d1bb20e',1,'PhoneApp.Data.Provider____.Name()']]]
];
