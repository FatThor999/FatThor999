var searchData=
[
  ['operating_5fsystem_161',['Operating_System',['../class_phone_app_1_1_data_1_1_modell.html#a9044c37b745ed6233aadd6fb540daa40',1,'PhoneApp::Data::Modell']]]
];
