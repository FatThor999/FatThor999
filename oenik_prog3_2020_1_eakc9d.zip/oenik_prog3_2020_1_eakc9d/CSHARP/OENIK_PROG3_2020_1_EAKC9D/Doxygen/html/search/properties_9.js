var searchData=
[
  ['provider_5f_5f_5f_5f_162',['Provider____',['../class_phone_app_1_1_data_1_1_phone_database_entities.html#ab1561bba8fb6c766227f6e607e12a306',1,'PhoneApp.Data.PhoneDatabaseEntities.Provider____()'],['../class_phone_app_1_1_data_1_1_modell.html#a537445b7627b1d20e497fac951fc0216',1,'PhoneApp.Data.Modell.Provider____()']]],
  ['provider_5fid_163',['Provider_ID',['../class_phone_app_1_1_data_1_1_modell.html#a59322e3c4ad9e808e0ba913f06b2583b',1,'PhoneApp::Data::Modell']]]
];
