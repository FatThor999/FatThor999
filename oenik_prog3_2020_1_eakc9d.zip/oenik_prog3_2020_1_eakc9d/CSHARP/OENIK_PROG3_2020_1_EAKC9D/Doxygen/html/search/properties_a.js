var searchData=
[
  ['reliability_164',['Reliability',['../class_phone_app_1_1_data_1_1_b_r_a_n_d.html#a48910cf0df2ef9653b016a3a1b6ff2d9',1,'PhoneApp.Data.BRAND.Reliability()'],['../class_phone_app_1_1_data_1_1_provider________.html#a5afa6a96afef264f869c651e40013501',1,'PhoneApp.Data.Provider____.Reliability()']]]
];
