var searchData=
[
  ['year_5fof_5ffoundation_165',['Year_of_Foundation',['../class_phone_app_1_1_data_1_1_b_r_a_n_d.html#aef3b6bc3ab80bfc47e31f47b4060605d',1,'PhoneApp.Data.BRAND.Year_of_Foundation()'],['../class_phone_app_1_1_data_1_1_provider________.html#a4745f38ee801e65bd24def934b67c9cc',1,'PhoneApp.Data.Provider____.Year_of_Foundation()']]]
];
