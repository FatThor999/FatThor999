﻿// <copyright file="BrandTest.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace PhoneApp.Logic.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Moq;
    using NUnit.Framework;
    using PhoneApp.Data;
    using PhoneApp.logic.Classes;
    using PhoneApp.Repository.Interfaces;

    /// <summary>
    /// Brand Test Class.
    /// </summary>
    [TestFixture]
    public class BrandTest
    {
        private Mock<IRepository<BRAND, string>> mockedBrandRepository;
        private BrandLogic bLogic;

        /// <summary>
        /// Mocked repo set up.
        /// </summary>
        [SetUp]
        public void Init()
        {
            this.mockedBrandRepository = new Mock<IRepository<BRAND, string>>();

            List<BRAND> brandTestList = new List<BRAND>();

            var test1 = new BRAND()
            { Id = "VF", Name = "Apple", Year_of_Foundation = 1950, Country_Name = "Hungary", Reliability = 5, Factory_inHungary = true };

            var test2 = new BRAND()
            { Id = "AS", Name = "LG", Year_of_Foundation = 1554, Country_Name = "NetherLands", Reliability = 6, Factory_inHungary = false };

            var test3 = new BRAND()
            { Id = "SS", Name = "Nokia", Year_of_Foundation = 2010, Country_Name = "Germany", Reliability = 7, Factory_inHungary = false };

            var test4 = new BRAND()
            { Id = "BB", Name = "Samsung", Year_of_Foundation = 1878, Country_Name = "Hunululu", Reliability = 10, Factory_inHungary = false };

            var test5 = new BRAND()
            { Id = "TT", Name = "Sony", Year_of_Foundation = 1900, Country_Name = "Kukutyin", Reliability = 3, Factory_inHungary = true };
            brandTestList.Add(test1);
            brandTestList.Add(test2);
            brandTestList.Add(test3);
            brandTestList.Add(test4);
            brandTestList.Add(test5);

            this.mockedBrandRepository.Setup(x => x.GetAll()).Returns(brandTestList.AsQueryable());
            this.mockedBrandRepository.Setup(x => x.GetById(It.IsAny<string>())).Returns(test4); // for read test
            this.mockedBrandRepository.Setup(x => x.Delete(It.IsAny<string>()))
               .Callback((string ID) =>
               {
                   brandTestList.RemoveAll(x => x.Id == ID);
               });
            this.mockedBrandRepository.Setup(x => x.Create(It.IsAny<BRAND>())).Returns(new BRAND()
            { Id = "AA", Name = "Test", Year_of_Foundation = 51040, Country_Name = "Spain", Reliability = 5, Factory_inHungary = true }); // for create test
            this.mockedBrandRepository.Setup(x => x.Update(It.IsAny<BRAND>())).Returns(test4);

            this.bLogic = new BrandLogic(this.mockedBrandRepository.Object);
        }

        /// <summary>
        /// GetAll test.
        /// </summary>
        [Test]
        public void GetAllTest()
        {
            var getAllBrand = this.bLogic.GetAll();

            Assert.That(getAllBrand, Is.EqualTo(this.bLogic.GetAll()));
            Assert.That(getAllBrand.Count, Is.EqualTo(5));
            this.mockedBrandRepository.Verify(x => x.GetAll(), Times.Exactly(2));
        }

        /// <summary>
        /// Create test.
        /// </summary>
        [Test]
        public void CreateTest()
        {
            var brand = this.bLogic.Create(new BRAND() { Id = "AA", Name = "Test", Year_of_Foundation = 51040, Country_Name = "Spain", Reliability = 5, Factory_inHungary = true });
            var getAll = this.bLogic.GetAll();
            getAll.Add(brand);

            // list count: 5+1
            Assert.That(getAll.Count, Is.EqualTo(6));
            Assert.That(brand.Name, Is.EqualTo("Test"));
            this.mockedBrandRepository.Verify(x => x.GetAll(), Times.Once);

            Assert.That(
                 () =>
              this.bLogic.Create(new BRAND() { Id = "AA", Name = "Test", Year_of_Foundation = 1987, Country_Name = "Hungary", Reliability = -7, Factory_inHungary = true }),
                 Throws.TypeOf<ApplicationException>());
        }

        /// <summary>
        /// Read test.
        /// </summary>
        [Test]
        public void ReadTest()
        {
            var brand = this.bLogic.GetById("BB");
            Assert.That(brand.Name, Is.EqualTo("Samsung"));
            Assert.That(brand.Factory_inHungary, Is.False);
            Assert.That(brand.Reliability, Is.EqualTo(10));
            this.mockedBrandRepository.Verify(x => x.GetById("BB"), Times.Once);
            Assert.That(
                () =>
                this.bLogic.GetById(string.Empty), Throws.TypeOf<ApplicationException>());
        }

        /// <summary>
        /// Delete test.
        /// </summary>
        [Test]
        public void DeleteTest()
        {
            this.bLogic.Delete("VF");
            var getAll = this.bLogic.GetAll();

            // count: 5-1
            Assert.That(getAll.Count, Is.EqualTo(4));
            Assert.That(
                () =>
                this.bLogic.Delete(string.Empty), Throws.TypeOf<ApplicationException>());
            this.mockedBrandRepository.Verify(x => x.Delete("VF"), Times.Once);
        }

        /// <summary>
        /// Update test.
        /// </summary>
        [Test]
        public void UpdateTest()
        {
            var up = this.bLogic.Update(new BRAND() { Id = "BB", Name = "Új", Year_of_Foundation = 1900, Country_Name = "AlmaOrszág", Reliability = 10, Factory_inHungary = false });

            Assert.That(up.Name, Is.EqualTo("Új"));
            Assert.That(this.bLogic.GetById("BB").Name, Is.Not.EqualTo("Samsung"));
            Assert.That(up.Name, Is.EqualTo(this.bLogic.GetById("BB").Name));
            this.mockedBrandRepository.Verify(x => x.Update(this.bLogic.GetById("BB")), Times.Once);
        }
    }
}
