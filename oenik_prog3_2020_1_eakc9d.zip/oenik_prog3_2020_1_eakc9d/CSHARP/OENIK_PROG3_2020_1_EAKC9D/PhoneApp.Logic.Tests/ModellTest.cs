﻿// <copyright file="ModellTest.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace PhoneApp.Logic.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Moq;
    using NUnit.Framework;
    using PhoneApp.Data;
    using PhoneApp.logic.Classes;
    using PhoneApp.Repository.Interfaces;

    /// <summary>
    /// Modell Test Class.
    /// </summary>
    [TestFixture]
    public class ModellTest
    {
       private Mock<IRepository<Modell, string>> mockedModellRepository;
       private ModellLogic mLogic;

        /// <summary>
        /// Mocked repo set up.
        /// </summary>
       [SetUp]
       public void Init()
        {
            this.mockedModellRepository = new Mock<IRepository<Modell, string>>();

            List<Modell> modellTestList = new List<Modell>();

            var test1 = new Modell()
            { Id = "VF", Name = "NokiaMini", Base_Price = 55000, Display_Size = 5.6, Operating_System = "Android", Brand_ID = "SA", Provider_ID = "VO", Guarantee = 1 };

            var test2 = new Modell()
            { Id = "AS", Name = "Iphone99", Base_Price = 50040, Display_Size = 6.6, Operating_System = "iOS", Brand_ID = "AP", Provider_ID = "TE", Guarantee = 5 };

            var test3 = new Modell()
            { Id = "SS", Name = "XiaomiS", Base_Price = 85010, Display_Size = 4.7, Operating_System = "Android", Brand_ID = "XI", Provider_ID = "T", Guarantee = 3 };

            var test4 = new Modell()
            { Id = "BB", Name = "GalaxyJ6", Base_Price = 45000, Display_Size = 4.9, Operating_System = "Android", Brand_ID = "SA", Provider_ID = "VO", Guarantee = 2 };

            var test5 = new Modell()
            { Id = "TT", Name = "TestMobil", Base_Price = 105000, Display_Size = 3.6, Operating_System = "IOS", Brand_ID = "SA", Provider_ID = "DI", Guarantee = 3 };
            modellTestList.Add(test1);
            modellTestList.Add(test2);
            modellTestList.Add(test3);
            modellTestList.Add(test4);
            modellTestList.Add(test5);

            this.mockedModellRepository.Setup(x => x.GetAll()).Returns(modellTestList.AsQueryable);
            this.mockedModellRepository.Setup(x => x.GetById(It.IsAny<string>())).Returns(test4); // for read test
            this.mockedModellRepository.Setup(x => x.Delete(It.IsAny<string>()))
               .Callback((string ID) =>
               {
                   modellTestList.RemoveAll(x => x.Id == ID);
               });
            this.mockedModellRepository.Setup(x => x.Create(It.IsAny<Modell>())).Returns(new Modell()
            { Id = "AA", Name = "Test", Base_Price = 51040, Display_Size = 4.6, Operating_System = "Android", Brand_ID = "HU", Provider_ID = "TT", Guarantee = 2 }); // for create test
            this.mockedModellRepository.Setup(x => x.Update(It.IsAny<Modell>())).Returns(test4);

            this.mLogic = new ModellLogic(this.mockedModellRepository.Object);
        }

        /// <summary>
        /// GetAll test.
        /// </summary>
       [Test]
       public void GetAllTest()
        {
            var getAllModell = this.mLogic.GetAll();

            Assert.That(getAllModell, Is.EqualTo(this.mLogic.GetAll()));
            Assert.That(getAllModell.Count, Is.EqualTo(5));
            this.mockedModellRepository.Verify(x => x.GetAll(), Times.Exactly(2));
        }

        /// <summary>
        /// Create test.
        /// </summary>
       [Test]
       public void CreateTest()
        {
            var modell = this.mLogic.Create(new Modell() { Id = "AA", Name = "Test", Base_Price = 51040, Display_Size = 4.6, Operating_System = "Android", Brand_ID = "HU", Provider_ID = "TT", Guarantee = 2 });
            var getAll = this.mLogic.GetAll();
            getAll.Add(modell);

            // list count: 5+1
            Assert.That(getAll.Count, Is.EqualTo(6));
            Assert.That(modell.Name, Is.EqualTo("Test"));
            this.mockedModellRepository.Verify(x => x.GetAll(), Times.Once);

            Assert.That(
                 () =>
              this.mLogic.Create(new Modell() { Id = "AA", Name = "Test", Base_Price = 51040, Display_Size = 0, Operating_System = "Android", Brand_ID = "HU", Provider_ID = "TT", Guarantee = -1 }),
                 Throws.TypeOf<ApplicationException>());
        }

        /// <summary>
        /// Read test.
        /// </summary>
       [Test]
       public void ReadTest()
        {
            string id = "BB";

            var modell = this.mLogic.GetById(id);

            Assert.That(modell, Is.Not.Null);
            Assert.That(modell.Name, Is.EqualTo("GalaxyJ6"));
            Assert.That(modell.Display_Size, Is.EqualTo(4.9));
            Assert.That(modell.Provider_ID, Is.EqualTo("VO"));
            this.mockedModellRepository.Verify(x => x.GetById("BB"), Times.Once);
            Assert.That(
                () =>
                this.mLogic.GetById(string.Empty), Throws.TypeOf<ApplicationException>());
        }

        /// <summary>
        /// Delete test.
        /// </summary>
       [Test]
       public void DeleteTest()
        {
            this.mLogic.Delete("VF");
            var getAll = this.mLogic.GetAll();

            // count: 5-1
            Assert.That(getAll.Count, Is.EqualTo(4));
            Assert.That(
                () =>
                this.mLogic.Delete(string.Empty), Throws.TypeOf<ApplicationException>());
            this.mockedModellRepository.Verify(x => x.Delete("VF"), Times.Once);
        }

        /// <summary>
        /// Update tets.
        /// </summary>
       [Test]
       public void UpdateTest()
        {
           var up = this.mLogic.Update(new Modell() { Id = "BB", Name = "Új", Base_Price = 45000, Display_Size = 4.9, Operating_System = "Android", Brand_ID = "SA", Provider_ID = "VO", Guarantee = 2 });

           Assert.That(up.Name, Is.EqualTo("Új"));
           Assert.That(this.mLogic.GetById("BB").Name, Is.Not.EqualTo("GalaxyJ6"));
           Assert.That(up.Name, Is.EqualTo(this.mLogic.GetById("BB").Name));

           this.mockedModellRepository.Verify(x => x.Update(this.mLogic.GetById("BB")), Times.Once);
        }
    }
}
