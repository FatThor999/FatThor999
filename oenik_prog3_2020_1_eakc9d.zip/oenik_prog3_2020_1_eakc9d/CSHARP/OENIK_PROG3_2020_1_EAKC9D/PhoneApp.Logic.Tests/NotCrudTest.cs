﻿// <copyright file="NotCrudTest.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace PhoneApp.Logic.Tests
{
    using System.Collections.Generic;
    using System.Linq;
    using Moq;
    using NUnit.Framework;
    using PhoneApp.Data;
    using PhoneApp.logic.Classes;
    using PhoneApp.Repository.Interfaces;

    /// <summary>
    /// Not Crud test class with moq.
    /// </summary>
    [TestFixture]
    public class NotCrudTest
    {
        private ExtraFunctions mExtra;

        /// <summary>
        /// Mocked repo set up.
        /// </summary>
        [SetUp]
        public void Init()
        {
            Mock<IRepository<Modell, string>> mockedModellRepository =
                new Mock<IRepository<Modell, string>>();

            Mock<IRepository<BRAND, string>> mockedBrandRepository =
                new Mock<IRepository<BRAND, string>>();

            Mock<IRepository<Provider____, string>> mockedProviderRepository
                = new Mock<IRepository<Provider____, string>>();

            List<Modell> modellTestList = new List<Modell>();

            var test1 = new Modell()
            { Id = "AS", Name = "NokiaMini", Base_Price = 55000, Display_Size = 5.6, Operating_System = "Android", Brand_ID = "VF", Provider_ID = "VO", Guarantee = 1 }; // 11

            var test2 = new Modell()
            { Id = "AT", Name = "Iphone99", Base_Price = 90000, Display_Size = 6.6, Operating_System = "iOS", Brand_ID = "VF", Provider_ID = "TE", Guarantee = 2 }; // 11

            var test3 = new Modell()
            { Id = "SS", Name = "XiaomiS", Base_Price = 85010, Display_Size = 4.7, Operating_System = "Android", Brand_ID = "VF", Provider_ID = "TE", Guarantee = 3 }; // 11

            var test4 = new Modell()
            { Id = "BB", Name = "GalaxyJ6", Base_Price = 45000, Display_Size = 4.9, Operating_System = "Android", Brand_ID = "SS", Provider_ID = "VO", Guarantee = 2 }; // 13

            var test5 = new Modell()
            { Id = "ZZ", Name = "TestMobil", Base_Price = 105000, Display_Size = 3.6, Operating_System = "IOS", Brand_ID = "SS", Provider_ID = "TE", Guarantee = 3 }; // 13
            modellTestList.Add(test1);
            modellTestList.Add(test2);
            modellTestList.Add(test3);
            modellTestList.Add(test4);
            modellTestList.Add(test5);

            List<BRAND> brandTestList = new List<BRAND>();

            var test11 = new BRAND()
            { Id = "VF", Name = "Apple", Year_of_Foundation = 1950, Country_Name = "Hungary", Reliability = 5, Factory_inHungary = true };

            var test22 = new BRAND()
            { Id = "AS", Name = "LG", Year_of_Foundation = 1554, Country_Name = "NetherLands", Reliability = 6, Factory_inHungary = false };

            var test33 = new BRAND()
            { Id = "SS", Name = "Nokia", Year_of_Foundation = 2010, Country_Name = "Germany", Reliability = 7, Factory_inHungary = false };

            var test44 = new BRAND()
            { Id = "BB", Name = "Samsung", Year_of_Foundation = 1878, Country_Name = "Hunululu", Reliability = 10, Factory_inHungary = false };

            var test55 = new BRAND()
            { Id = "TT", Name = "Sony", Year_of_Foundation = 1900, Country_Name = "Kukutyin", Reliability = 3, Factory_inHungary = true };
            brandTestList.Add(test11);
            brandTestList.Add(test22);
            brandTestList.Add(test33);
            brandTestList.Add(test44);
            brandTestList.Add(test55);

            List<Provider____> providerTestList = new List<Provider____>();

            var test111 = new Provider____()
            { Id = "VO", Name = "Apple", Year_of_Foundation = 1950,  Reliability = 6, Coverage = 60, Country = "10" };

            var test222 = new Provider____()
            { Id = "TE", Name = "LG", Year_of_Foundation = 1554,  Reliability = 6, Coverage = 90, Country = "11" };

            var test333 = new Provider____()
            { Id = "AY", Name = "Nokia", Year_of_Foundation = 2010,  Reliability = 7, Coverage = 100, Country = "12" };

            var test444 = new Provider____()
            { Id = "AX", Name = "Samsung", Year_of_Foundation = 1878,  Reliability = 10, Coverage = 20, Country = "13" };

            var test555 = new Provider____()
            { Id = "BX", Name = "Sony", Year_of_Foundation = 1900,  Reliability = 3, Coverage = 10, Country = "14" };
            providerTestList.Add(test111);
            providerTestList.Add(test222);
            providerTestList.Add(test333);
            providerTestList.Add(test444);
            providerTestList.Add(test555);
            mockedBrandRepository.Setup(x => x.GetById(It.IsAny<string>())).Returns(test33);
            mockedModellRepository.Setup(x => x.GetAll()).Returns(modellTestList.AsQueryable());
            mockedBrandRepository.Setup(x => x.GetAll()).Returns(brandTestList.AsQueryable());
            mockedProviderRepository.Setup(x => x.GetAll()).Returns(providerTestList.AsQueryable());
            this.mExtra = new ExtraFunctions(mockedModellRepository.Object, mockedBrandRepository.Object, mockedProviderRepository.Object);
        }

        /// <summary>
        /// Most expensive model test.
        /// </summary>
        [Test]
        public void MostExpensiveModellTest()
        {
           var expectedModell = new Modell() { Id = "AT", Name = "Iphone99", Base_Price = 90000, Display_Size = 6.6, Operating_System = "iOS", Brand_ID = "AP", Provider_ID = "TE", Guarantee = 5 };

           var mostExpensiveModell = this.mExtra.MostExpensiveModell("VF");

           Assert.That(mostExpensiveModell.Id, Is.EqualTo(expectedModell.Id));
        }

        /// <summary>
        /// Most famous provider's models test.
        /// </summary>
        [Test]
        public void MostFamousProviderModells()
        {
            var famous = this.mExtra.MostFamousProviderModells();

            Assert.That(famous.Count, Is.EqualTo(3));
        }

        /// <summary>
        /// Brand with the longest avarage guarantee test.
        /// </summary>
        [Test]
        public void LongestAvaregeGuaranteeTest()
        {
            var guarentee = this.mExtra.LongestAvaregeGuarantee();

            Assert.That(guarentee.Id, Is.EqualTo("SS"));
            Assert.That(guarentee.Name, Is.EqualTo("Nokia"));
        }

        /// <summary>
        /// The most reliable models test.
        /// </summary>
        [Test]
        public void MostReliableModellTest()
        {
            var reli = this.mExtra.MostReliableModells();

            Assert.That(reli, Is.Not.Null);
            Assert.That(reli.Count, Is.EqualTo(2));
        }
    }
}
