﻿// <copyright file="ProviderTest.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace PhoneApp.Logic.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Moq;
    using NUnit.Framework;
    using PhoneApp.Data;
    using PhoneApp.logic.Classes;
    using PhoneApp.Repository.Interfaces;

    /// <summary>
    /// Provider Test Class.
    /// </summary>
    public class ProviderTest
    {
        private Mock<IRepository<Provider____, string>> mockedProviderRepository;
        private ProviderLogic pLogic;

        /// <summary>
        /// Mocked repo set up.
        /// </summary>
        [SetUp]
        public void Init()
        {
            this.mockedProviderRepository = new Mock<IRepository<Provider____, string>>();

            List<Provider____> providerTestList = new List<Provider____>();

            var test1 = new Provider____()
            { Id = "AA", Name = "test1", Year_of_Foundation = 1950, Reliability = 5, Coverage = 90, Country = "1" };

            var test2 = new Provider____()
            { Id = "BB", Name = "test2", Year_of_Foundation = 1987, Reliability = 8, Coverage = 80, Country = "2" };

            var test3 = new Provider____()
            { Id = "CC", Name = "test3", Year_of_Foundation = 2000, Reliability = 7, Coverage = 87, Country = "3" };

            var test4 = new Provider____()
            { Id = "SAS", Name = "test4", Year_of_Foundation = 1978, Reliability = 10, Coverage = 81, Country = "4" };

            var test5 = new Provider____()
            { Id = "VF", Name = "test5", Year_of_Foundation = 1899, Reliability = 9, Coverage = 100, Country = "5" };
            providerTestList.Add(test1);
            providerTestList.Add(test2);
            providerTestList.Add(test3);
            providerTestList.Add(test4);
            providerTestList.Add(test5);

            this.mockedProviderRepository.Setup(x => x.GetAll()).Returns(providerTestList.AsQueryable());
            this.mockedProviderRepository.Setup(x => x.GetById(It.IsAny<string>())).Returns(test5); // for read test
            this.mockedProviderRepository.Setup(x => x.Delete(It.IsAny<string>()))
               .Callback((string ID) =>
               {
                   providerTestList.RemoveAll(x => x.Id == ID);
               });
            this.mockedProviderRepository.Setup(x => x.Create(It.IsAny<Provider____>())).Returns(new Provider____()
            { Id = "AA", Name = "valami", Year_of_Foundation = 1000, Reliability = 1, Coverage = 50 , Country = "6" }); // for create test
            this.mockedProviderRepository.Setup(x => x.Update(It.IsAny<Provider____>())).Returns(test5);

            this.pLogic = new ProviderLogic(this.mockedProviderRepository.Object);
        }

        /// <summary>
        /// GetAll test.
        /// </summary>
        [Test]
        public void GetAllTest()
        {
            var getAllProvider = this.pLogic.GetAll();

            Assert.That(getAllProvider, Is.EqualTo(this.pLogic.GetAll()));
            Assert.That(getAllProvider.Count, Is.EqualTo(5));
            this.mockedProviderRepository.Verify(x => x.GetAll(), Times.Exactly(2));
        }

        /// <summary>
        /// Create test.
        /// </summary>
        [Test]
        public void CreateTest()
        {
            var provider = this.pLogic.Create(new Provider____() { Id = "AA", Name = "valami", Year_of_Foundation = 1000, Reliability = 1, Coverage = 50, Country = "6" });
            var getAll = this.pLogic.GetAll();
            getAll.Add(provider);

            // list count: 5+1
            Assert.That(getAll.Count, Is.EqualTo(6));
            Assert.That(provider.Name, Is.EqualTo("valami"));
            this.mockedProviderRepository.Verify(x => x.GetAll(), Times.Once);

            Assert.That(
                 () =>
              this.pLogic.Create(new Provider____() { Id = " ", Name = "Test", Year_of_Foundation = 1987, Reliability = -7, Coverage = 40, Country = "6" }),
                 Throws.TypeOf<ApplicationException>());
        }

        /// <summary>
        /// Read test.
        /// </summary>
        [Test]
        public void ReadTest()
        {
            var provider = this.pLogic.GetById("VF");
            Assert.That(provider.Name, Is.EqualTo("test5"));
            Assert.That(provider.Reliability, Is.EqualTo(9));
            this.mockedProviderRepository.Verify(x => x.GetById("VF"), Times.Once);
            Assert.That(
                () =>
                this.pLogic.GetById(string.Empty), Throws.TypeOf<ApplicationException>());
        }

        /// <summary>
        /// Delete test.
        /// </summary>
        [Test]
        public void DeleteTest()
        {
            this.pLogic.Delete("VF");
            var getAll = this.pLogic.GetAll();

            // count: 5-1
            Assert.That(getAll.Count, Is.EqualTo(4));
            Assert.That(
                () =>
                this.pLogic.Delete(string.Empty), Throws.TypeOf<ApplicationException>());
            this.mockedProviderRepository.Verify(x => x.Delete("VF"), Times.Once);
        }

        /// <summary>
        /// Update test.
        /// </summary>
        [Test]
        public void UpdateTest()
        {
            var up = this.pLogic.Update(new Provider____() { Id = "VF", Name = "Új", Year_of_Foundation = 1900, Reliability = 5, Coverage = 100, Country = "7" });

            Assert.That(up.Name, Is.EqualTo("Új"));
            Assert.That(this.pLogic.GetById("VF").Name, Is.Not.EqualTo("test5"));
            Assert.That(up.Name, Is.EqualTo(this.pLogic.GetById("VF").Name));
            this.mockedProviderRepository.Verify(x => x.Update(this.pLogic.GetById("VF")), Times.Once);
        }
    }
}
