﻿// <copyright file="Program.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace PhoneApp.Program
{
    using System;
    using System.Xml.Linq;
    using PhoneApp.Data;
    using PhoneApp.logic.Classes;

    /// <summary>
    /// Main program.
    /// </summary>
    internal class Program
    {
        private static void Main()
        {
            do
            {
                Start();
            }
            while (true);
        }

        private static void Start()
        {
                Functions();
                Console.WriteLine();
                Console.WriteLine("Do you want to continue running the program? y/n");
                string ans = Console.ReadLine();
                if (ans == "n")
            {
                Environment.Exit(1);
            }

                Console.Clear();
        }

        private static void Functions()
        {
            var modellService = ModellLogic.Creates();
            var brandService = BrandLogic.Creates();
            var providerService = ProviderLogic.Creates();

            var extraFunctions = ExtraFunctions.Creates();
            Console.WriteLine("Chose table or the extra functions\n Model: 1\n Brand: 2\nProvider: 3\n ExtraFunctions: 4 ");

            int tableAnswer = int.Parse(Console.ReadLine());
            Console.Clear();

            if (tableAnswer == 1 || tableAnswer == 2 || tableAnswer == 3)
            {
                Console.WriteLine("0: Get All");
                Console.WriteLine("1: Add");
                Console.WriteLine("2: Delete");
                Console.WriteLine("3: Read");
                Console.WriteLine("4: Update\n");
            }
            else
            {
                Console.WriteLine("6: Most expensive modell in the brand.");

                Console.WriteLine("7: Modell list of the most famous provider .");

                Console.WriteLine("8: Brand name which have the longest warranty period on avarage");

                Console.WriteLine("9: Most reliable modell ");

                Console.WriteLine("10: Java endpoint using\n");
            }

            Console.Write("A: ");
            var answer = Console.ReadLine();

            Console.Clear();
            if (tableAnswer == 1)
            {
                switch (int.Parse(answer))
                {
                    case 0:
                        var modells = modellService.GetAll();
                        foreach (var model in modells)
                        {
                            Console.WriteLine("{0}--{1}--{2}", model.Id, model.Name, model.Base_Price);
                        }

                        break;
                    case 1:
                        Console.WriteLine("1: Add:");
                        var createEntity = new Modell()
                        {
                            Id = "Po",
                            Name = "Petimobil",
                            Base_Price = 550000,
                            Display_Size = 5.5,
                            Operating_System = "Android",
                            Guarantee = 4,
                            Brand_ID = "SA",
                            Provider_ID = "VO",
                        };

                        var newMobile = modellService.Create(createEntity);
                        Console.WriteLine(newMobile.Name);
                        break;
                    case 2:
                        Console.WriteLine("2: Delete:");
                        modellService.Delete("Po");
                        Console.WriteLine("Completed!");
                        break;

                    case 3:
                        Console.WriteLine("3: Read:");
                        var mobil = modellService.GetById("Lg6");
                        Console.WriteLine("Mobile name: {0} Mobile's brand faactory in Hungary: {1}", mobil.Name, mobil.BRAND.Factory_inHungary);
                        break;
                    case 4:
                        Console.WriteLine("4: Update:");

                        modellService.GetById("BL5").Name = "ÚJ";
                        modellService.GetById("BL5").Guarantee = 1;
                        modellService.GetById("BL5").Display_Size = 4.2;
                        modellService.GetById("BL5").Operating_System = "MAC";

                        modellService.Update(modellService.GetById("BL5"));

                        Console.WriteLine("Completed!");

                        break;
                    default:
                        break;
                }
            }

            if (tableAnswer == 2)
            {
                switch (int.Parse(answer))
                {
                    case 0:
                        var brands = brandService.GetAll();
                        foreach (var brandd in brands)
                        {
                            Console.WriteLine("{0}--{1}--{2}", brandd.Id, brandd.Name, brandd.Country_Name, brandd.Year_of_Foundation);
                        }

                        break;
                    case 1:
                        Console.WriteLine("1: Add:");
                        var createEntity = new BRAND()
                        {
                            Id = "PP",
                            Name = "PetiBrand",
                            Country_Name = "Hungary",
                            Factory_inHungary = true,
                            Year_of_Foundation = 1945,
                            Reliability = 7,
                        };

                        var newBrand = brandService.Create(createEntity);
                        Console.WriteLine("Az új márka neve: {0} Alapaításának éve : {1} Megbízhatósága: {2}", newBrand.Name, newBrand.Year_of_Foundation, newBrand.Reliability);
                        break;
                    case 2:
                        Console.WriteLine("2: Delete:");
                        brandService.Delete("PP");
                        Console.WriteLine("Completed!");
                        break;

                    case 3:
                        Console.WriteLine("3: Read:");
                        var brand = brandService.GetById("SA");
                        Console.WriteLine("Márka neve: {0} Alapításának éve: {1} Ország neve: {2} ", brand.Name, brand.Year_of_Foundation, brand.Country_Name);
                        break;
                    case 4:
                        Console.WriteLine("4: Update:");

                        brandService.GetById("NO").Name = "ÚJ";
                        brandService.GetById("NO").Country_Name = "Malajzia";
                        brandService.GetById("NO").Factory_inHungary = false;
                        brandService.GetById("NO").Reliability = 6;

                        brandService.Update(brandService.GetById("NO"));

                        Console.WriteLine("Completed!");

                        break;
                    default:
                        break;
                }
            }

            if (tableAnswer == 3)
            {
                switch (int.Parse(answer))
                {
                    case 0:
                        var providers = providerService.GetAll();
                        foreach (var providerr in providers)
                        {
                            Console.WriteLine("{0}--{1}--{2}--{3}", providerr.Id, providerr.Name, providerr.Country, providerr.Year_of_Foundation);
                        }

                        break;
                    case 1:
                        Console.WriteLine("1: Add:");
                        var createEntity = new Provider____()
                        {
                            Id = "PT",
                            Name = "PetiProvider",
                            Country = "Hungary",
                            Coverage = 80,
                            Year_of_Foundation = 1965,
                            Reliability = 5,
                        };

                        var newProvider = providerService.Create(createEntity);
                        Console.WriteLine("The added provider name: {0}  : {1} Reliability: {2}", newProvider.Name, newProvider.Coverage, newProvider.Reliability);
                        break;
                    case 2:
                        Console.WriteLine("2: Delete:");
                        providerService.Delete("PT");
                        Console.WriteLine("Completed!");
                        break;

                    case 3:
                        Console.WriteLine("3: Read:");
                        var provider = providerService.GetById("VO");
                        Console.WriteLine("Szolgáltató neve: {0}  Alapításának éve: {1}  Ország neve: {2} ", provider.Name, provider.Year_of_Foundation, provider.Country);
                        break;
                    case 4:
                        Console.WriteLine("4: Update:");

                        providerService.GetById("TE").Name = "ÚJ";
                        providerService.GetById("TE").Country = "Malajzia";
                        providerService.GetById("TE").Coverage = 74;
                        providerService.GetById("TE").Reliability = 9;

                        providerService.Update(providerService.GetById("TE"));

                        Console.WriteLine("Completed!");

                        break;
                    default:
                        break;
                }
            }

            if (tableAnswer == 4)
            {
                switch (int.Parse(answer))
                {
                    case 6:

                        var mostExpensiveModell = extraFunctions.MostExpensiveModell("BL");
                        Console.WriteLine("6: A legdrágább modell a márkában: " + mostExpensiveModell.Name);
                        break;
                    case 7:
                        var famousProviderModells = extraFunctions.MostFamousProviderModells();

                        Console.WriteLine("7: A legelterjetebb szolgáltatók telefonjainak neve: \n");
                        foreach (var modell in famousProviderModells)
                        {
                            Console.WriteLine(modell.Name + "Szolgáltató neve: " + modell.Provider____.Name);
                        }

                        break;
                    case 8:
                        var longestAvaregeGuaranteeBrand = extraFunctions.LongestAvaregeGuarantee();

                        Console.WriteLine("8: Átlagosan a leghosszabb garanciaidővel rendelkező márka neve: {0}", longestAvaregeGuaranteeBrand.Name);

                        break;
                    case 9:
                        Console.WriteLine("9:");
                        var reliable = extraFunctions.MostReliableModells();
                        Console.WriteLine("A legmegbízhatóbb modellek listái: ");
                        int szamlalo = 0;
                        foreach (var model in reliable)
                        {
                            Console.WriteLine("Telefon neve: " + model.Name);
                            szamlalo++;
                        }

                        Console.WriteLine("Össz: " + szamlalo);
                        break;
                    case 10:
                        Console.WriteLine("10:");

                        Console.WriteLine("Üss egy entert");
                        Console.ReadLine();

                        Modell mobile = modellService.GetById("HM20");
                        int ar = mobile.Base_Price.Value;
                        int guar = mobile.Guarantee.Value;
                        double size = mobile.Display_Size.Value;

                        string a = size.ToString().Replace(',', '.');

                        var reli = mobile.Provider____.Reliability + mobile.BRAND.Reliability;
                        string url = $"http://localhost:8084/oenik_prog3_2020_1_eakc9d/PhoneServlet?ar={ar}&megbiz={reli}&kijelzo={a}&garancia={guar}";
                        Console.ReadLine();
                        XDocument xDoc = XDocument.Load(url);

                        Console.WriteLine("Az adott kategória neve:" + xDoc.Root.Element("result").Value + "Ár: " + ar + " Garancia: " + guar + " Méret: " + size);

                        break;
                    default:
                        break;
                }
            }
        }
    }
}
