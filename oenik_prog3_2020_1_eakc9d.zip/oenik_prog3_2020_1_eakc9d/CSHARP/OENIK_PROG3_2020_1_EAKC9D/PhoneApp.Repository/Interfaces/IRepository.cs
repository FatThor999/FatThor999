﻿// <copyright file="IRepository.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace PhoneApp.Repository.Interfaces
{
    using System.Linq;

    /// <summary>
    /// IRepository interface(Contain CRUDs).
    /// </summary>
    /// <typeparam name="T">Types like Model/BRAND/Provider.</typeparam>
    /// <typeparam name="TK">Now strings.</typeparam>
    public interface IRepository<T, TK>
    {
        /// <summary>
        /// GetAll() Get all method.
        /// </summary>
        /// <returns>IQuarable types.</returns>
        IQueryable<T> GetAll();

        /// <summary>
        /// FirstCRUD Read method.
        /// </summary>
        /// <param name="id">Selected row ID.</param>
        /// <returns>Specific type.</returns>
        T GetById(TK id);

        /// <summary>
        /// SecondCRUD Create method.
        /// </summary>
        /// <param name="newtype">Specific new type.</param>
        /// <returns>Specific type.</returns>
        T Create(T newtype);

        /// <summary>
        /// ThirdCRUD Update method.
        /// </summary>
        /// <param name="change">New specific type.</param>
        /// <returns>Specific type.</returns>
        T Update(T change);

        /// <summary>
        /// FourthCRUD Delete method.
        /// </summary>
        /// <param name="id">Selected row ID.</param>
        void Delete(TK id);
    }
}
