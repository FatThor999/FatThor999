﻿// <copyright file="BrandRepository.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace PhoneApp.Repository.Repositories
{
    using System;
    using System.Linq;
    using PhoneApp.Data;
    using PhoneApp.Repository.Interfaces;

    /// <summary>
    /// Provider repository class with IRepositoryT interface.
    /// </summary>
    public class BrandRepository : IRepository<BRAND, string>
    {
        private readonly PhoneDatabaseEntities dbContext;

        /// <summary>
        /// Initializes a new instance of the <see cref="BrandRepository"/> class.
        /// BrandRepository ctor create dbContext.
        /// </summary>
        /// <param name="dbContext">Produce Database.</param>
        public BrandRepository(PhoneDatabaseEntities dbContext)
        {
            this.dbContext = dbContext;
        }

        /// <summary>
        /// Brand repository Read method.
        /// </summary>
        /// <param name="id">Selected Brand ID.</param>
        /// <returns>Specific Brand type.</returns>
        public BRAND GetById(string id)
        {
            var getbyid = this.dbContext.BRAND.SingleOrDefault(x => x.Id == id);

            if (getbyid == null)
            {
                throw new ApplicationException($"Nem található ilyen ID alatt márka {id}");
            }

            return getbyid;
        }

        /// <summary>
        /// Barnd repository create method.
        /// </summary>
        /// <param name="brand">Create this type.</param>
        /// <returns>Specific Brand type.</returns>
        public BRAND Create(BRAND brand)
        {
            var create = this.dbContext.BRAND.Add(brand);
            this.dbContext.SaveChanges();

            return create;
        }

        /// <summary>
        /// Brand repository delete method.
        /// </summary>
        /// <param name="id">Delete row id.</param>
        public void Delete(string id)
        {
            this.dbContext.BRAND.Remove(this.GetById(id));

            this.dbContext.SaveChanges();
        }

        /// <summary>
        /// Brand repository GetAll method.
        /// </summary>
        /// <returns>IQuaruable Brand type.</returns>
        public IQueryable<BRAND> GetAll()
        {
            return this.dbContext.BRAND;
        }

        /// <summary>
        /// Brand repository update method.
        /// </summary>
        /// <param name="brand">Selected new brand.</param>
        /// <returns>Specific Brand type.</returns>
        public BRAND Update(BRAND brand)
        {
            var entry = this.dbContext.Entry(this.GetById(brand.Id));

            entry.CurrentValues.SetValues(brand);
            this.dbContext.SaveChanges();
            return entry.Entity;
        }
    }
}
