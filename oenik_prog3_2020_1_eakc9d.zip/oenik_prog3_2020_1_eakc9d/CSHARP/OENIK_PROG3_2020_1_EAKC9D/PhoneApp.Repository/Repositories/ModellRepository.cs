﻿// <copyright file="ModellRepository.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace PhoneApp.Repository.Repositories
{
    using System;
    using System.Linq;
    using PhoneApp.Data;
    using PhoneApp.Repository.Interfaces;

    /// <summary>
    /// Model repository class with IRepositoryT interface.
    /// </summary>
    public class ModellRepository : IRepository<Modell, string>
    {
        private PhoneDatabaseEntities dbContext;

        /// <summary>
        /// Initializes a new instance of the <see cref="ModellRepository"/> class.
        /// ModelRepository ctor create dbContext.
        /// </summary>
        /// <param name="dbContext">Produce Database.</param>
        public ModellRepository(PhoneDatabaseEntities dbContext)
        {
            this.dbContext = dbContext;
        }

        /// <summary>
        /// Model repository Read method.
        /// </summary>
        /// <param name="id">Selected Model ID.</param>
        /// <returns>Specific Model type.</returns>
        public Modell GetById(string id)
        {
            var getbyid = this.dbContext.Modell.SingleOrDefault(x => x.Id == id);

            if (getbyid == null)
            {
                throw new ApplicationException($"Nem található ilyen ID alatt telefon {id}");
            }

            return getbyid;
        }

        /// <summary>
        /// Model repository create method.
        /// </summary>
        /// <param name="modell">Create this type.</param>
        /// <returns>Specific model type.</returns>
        public Modell Create(Modell modell)
        {
            var create = this.dbContext.Modell.Add(modell);
            this.dbContext.SaveChanges();

            return create;
        }

        /// <summary>
        /// Model repository delete method.
        /// </summary>
        /// <param name="id">Delete row id.</param>
        public void Delete(string id)
        {
            this.dbContext.Modell.Remove(this.GetById(id));

            this.dbContext.SaveChanges();
        }

        /// <summary>
        /// Model repository GetAll method.
        /// </summary>
        /// <returns>IQuaruable Model type.</returns>
        public IQueryable<Modell> GetAll()
        {
            return this.dbContext.Modell;
        }

        /// <summary>
        /// Model repository update method.
        /// </summary>
        /// <param name="modell">Selected new model.</param>
        /// <returns>Specific Model type.</returns>
        public Modell Update(Modell modell)
        {
            var entry = this.dbContext.Entry(this.GetById(modell.Id));

            entry.CurrentValues.SetValues(modell);
            this.dbContext.SaveChanges();
            return entry.Entity;
        }
    }
}
