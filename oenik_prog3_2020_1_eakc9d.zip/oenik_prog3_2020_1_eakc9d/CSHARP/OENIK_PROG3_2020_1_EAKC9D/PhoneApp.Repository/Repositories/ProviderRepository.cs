﻿// <copyright file="ProviderRepository.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace PhoneApp.Repository.Repositories
{
    using System;
    using System.Linq;
    using PhoneApp.Data;
    using PhoneApp.Repository.Interfaces;

    /// <summary>
    /// Provider repository class with IRepositoryT interface.
    /// </summary>
    public class ProviderRepository : IRepository<Provider____, string>
   {
        private readonly PhoneDatabaseEntities dbContext;

        /// <summary>
        /// Initializes a new instance of the <see cref="ProviderRepository"/> class.
        /// ProviderRepository ctor create dbContext.
        /// </summary>
        /// <param name="dbContext">Produce Database.</param>
        public ProviderRepository(PhoneDatabaseEntities dbContext)
        {
            this.dbContext = dbContext;
        }

        /// <summary>
        /// Provider repository Read method.
        /// </summary>
        /// <param name="id">Selected Provider ID.</param>
        /// <returns>Specific Provider type.</returns>
        public Provider____ GetById(string id)
        {
            var getbyid = this.dbContext.Provider____.SingleOrDefault(x => x.Id == id);

            if (getbyid == null)
            {
                throw new ApplicationException($"Nem található ilyen ID alatt szolgáltató {id}");
            }

            return getbyid;
        }

        /// <summary>
        /// Provider repository create method.
        /// </summary>
        /// <param name="provider">Create this type.</param>
        /// <returns>Specific provider type.</returns>
        public Provider____ Create(Provider____ provider)
        {
            var create = this.dbContext.Provider____.Add(provider);
            this.dbContext.SaveChanges();

            return create;
        }

        /// <summary>
        /// Provider repository delete method.
        /// </summary>
        /// <param name="id">Delete row id.</param>
        public void Delete(string id)
        {
            this.dbContext.Provider____.Remove(this.GetById(id));

            this.dbContext.SaveChanges();
        }

        /// <summary>
        /// Provider repository GetAll method.
        /// </summary>
        /// <returns>IQuaruable Provider type.</returns>
        public IQueryable<Provider____> GetAll()
        {
            return this.dbContext.Provider____;
        }

        /// <summary>
        /// Provider repository update method.
        /// </summary>
        /// <param name="provider">Selected new provider.</param>
        /// <returns>Specific Provider type.</returns>
        public Provider____ Update(Provider____ provider)
        {
            if (provider == null)
            {
                throw new ArgumentNullException(nameof(provider));
            }

            var entry = this.dbContext.Entry(this.GetById(provider.Id));

            entry.CurrentValues.SetValues(provider);
            this.dbContext.SaveChanges();
            return entry.Entity;
        }
    }
}
