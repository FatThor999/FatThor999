﻿// <copyright file="ExtraFunctions.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace PhoneApp.logic.Classes
{
    using System.Collections.Generic;
    using System.Linq;
    using PhoneApp.Data;
    using PhoneApp.Repository.Interfaces;
    using PhoneApp.Repository.Repositories;

    /// <summary>
    /// Extra functions class.
    /// </summary>
    public class ExtraFunctions
    {
        private IRepository<Modell, string> modellRepository;
        private IRepository<BRAND, string> brandRepository;
        private IRepository<Provider____, string> providerRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExtraFunctions"/> class.
        /// Extra functions ctor.
        /// </summary>
        /// <param name="modellRepository">Model repository.</param>
        /// <param name="brandRepository">Brand repository.</param>
        /// <param name="providerRepository">Provider repository.</param>
        public ExtraFunctions(
            IRepository<Modell, string> modellRepository,
            IRepository<BRAND, string> brandRepository,
            IRepository<Provider____, string> providerRepository)
           {
            this.modellRepository = modellRepository;
            this.brandRepository = brandRepository;
            this.providerRepository = providerRepository;
            }

        /// <summary>
        /// Create new Database Entities.
        /// </summary>
        /// <returns>New ExtraFunctions with new ModellRepository new BrandRepository new ProviderRepository.</returns>
        public static ExtraFunctions Creates()
        {
            var rep = new PhoneDatabaseEntities();

            return new ExtraFunctions(new ModellRepository(rep), new BrandRepository(rep), new ProviderRepository(rep));
        }

        /// <summary>
        /// First extra function.
        /// </summary>
        /// <param name="id">Brand id.</param>
        /// <returns>Most expensive model in the brand.</returns>
        public Modell MostExpensiveModell(string id)
        {
            var result = this.modellRepository.GetAll().Where(x => x.Brand_ID == id).
                OrderByDescending(x => x.Base_Price).FirstOrDefault();

            return result;
        }

        /// <summary>
        /// Second extra function.
        /// </summary>
        /// <returns>List of the models of the most famous provider.</returns>
        public List<Modell> MostFamousProviderModells()
        {
          var result = this.modellRepository.GetAll().GroupBy(x => x.Provider_ID).
                OrderByDescending(x => x.Count()).FirstOrDefault().ToList();

          return result;
        }

        /// <summary>
        /// Third extra function.
        /// </summary>
        /// <returns>Brand with the longest avg warranty period.</returns>
        public BRAND LongestAvaregeGuarantee()
        {
            var query = this.modellRepository.GetAll().GroupBy(x => x.Brand_ID).
                OrderByDescending(x => x.Average(y => y.Guarantee))
                .FirstOrDefault().ToList();

            var result = this.brandRepository.GetById(query.FirstOrDefault().Brand_ID);
            return result;
        }

        /// <summary>
        /// Fourth extra function.
        /// </summary>
        /// <returns>List of the most reliable Modells.</returns>
        public List<Modell> MostReliableModells()
        {
            var query = from modell in this.modellRepository.GetAll()
                         join brand in this.brandRepository.GetAll() on modell.Brand_ID equals brand.Id
                         join provider in this.providerRepository.GetAll() on modell.Provider_ID equals provider.Id
                         select new
                         {
                             Reli = brand.Reliability + provider.Reliability,
                             Id = modell.Id,
                             Name = modell.Name,
                             Display_Size = modell.Display_Size,
                             Operating_System = modell.Operating_System,
                             Base_Price = modell.Base_Price,
                             Guarantee = modell.Guarantee,
                             Brand_ID = modell.Brand_ID,
                             Provider_ID = modell.Provider_ID,
                         };

            var result = query.GroupBy(x => x.Reli).OrderByDescending(y => y.Key).FirstOrDefault().
                Select(x => new Modell()
                {
                    Id = x.Id,
                    Name = x.Name,
                    Display_Size = x.Display_Size,
                    Operating_System = x.Operating_System,
                    Base_Price = x.Base_Price,
                    Guarantee = x.Guarantee,
                    Brand_ID = x.Brand_ID,
                    Provider_ID = x.Provider_ID,
                });

            return result.ToList();
        }
    }
}
