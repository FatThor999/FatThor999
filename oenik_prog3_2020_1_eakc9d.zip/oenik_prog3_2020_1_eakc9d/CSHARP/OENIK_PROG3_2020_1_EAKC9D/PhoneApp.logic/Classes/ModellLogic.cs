﻿// <copyright file="ModellLogic.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace PhoneApp.logic.Classes
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using PhoneApp.Data;
    using PhoneApp.logic.Interfaces;
    using PhoneApp.Repository.Interfaces;
    using PhoneApp.Repository.Repositories;

    /// <summary>
    /// Model Logic class with ILogicT interface.
    /// </summary>
    public class ModellLogic : ILogic<Modell, string>
    {
        private readonly IRepository<Modell, string> modellRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="ModellLogic"/> class.
        /// Model Logic ctor create repo.
        /// </summary>
        /// <param name="modellRepository">Produce Repository.</param>
        public ModellLogic(IRepository<Modell, string> modellRepository)
        {
            this.modellRepository = modellRepository;
        }

        /// <summary>
        /// Create new Database Entities.
        /// </summary>
        /// <returns>New ModellLogic with new ModellRepository.</returns>
        public static ILogic<Modell, string> Creates()
        {
            var rep = new PhoneDatabaseEntities();
            return new ModellLogic(new ModellRepository(rep));
        }

        /// <summary>
        /// Model Logic crud Delete method.
        /// ID is null or empty throw exeption.
        /// </summary>
        /// <param name="id">Selected row ID.</param>
        public void Delete(string id)
        {
            if (id == null || string.IsNullOrEmpty(id))
            {
                throw new ApplicationException("Invalid identity");
            }

            this.modellRepository.Delete(id);
        }

        /// <summary>
        /// Model Logic crud get all method.
        /// </summary>
        /// <returns>List type.</returns>
        public List<Modell> GetAll()
        {
            return this.modellRepository.GetAll().ToList();
        }

        /// <summary>
        /// Model Logic Read method.
        /// ID is null or empty throws exeption.
        /// </summary>
        /// <param name="id">Selected row ID.</param>
        /// <returns>Specific Model type.</returns>
        public Modell GetById(string id)
        {
            if (id == null || string.IsNullOrEmpty(id))
            {
                throw new ApplicationException("Invalid identity");
            }

            return this.modellRepository.GetById(id);
        }

        /// <summary>
        /// Model Logic crud Update method.
        /// </summary>
        /// <param name="modell">New type datas.</param>
        /// <returns>Specific Model type.</returns>
        public Modell Update(Modell modell)
        {
            var entityFromDb = this.modellRepository.GetById(modell.Id);

            entityFromDb.Name = modell.Name;

            entityFromDb.Guarantee = modell.Guarantee;
            entityFromDb.Display_Size = modell.Display_Size;
            entityFromDb.Operating_System = modell.Operating_System;

            var result = this.modellRepository.Update(entityFromDb);

            return result;
        }

        /// <summary>
        /// Model Logic crud Create method.
        /// If displaysize is null or negative or price is negative or guarantee is negative it throw exeption.
        /// </summary>
        /// <param name="modell">New type.</param>
        /// <returns>Specific Model type.</returns>
        public Modell Create(Modell modell)
        {
            var result = this.modellRepository.Create(modell);

            if (modell.Display_Size <= 0 || modell.Base_Price < 0 || modell.Guarantee < 0)
            {
                throw new ApplicationException("Wrong data");
            }

            return result;
        }
    }
}
