﻿// <copyright file="ProviderLogic.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace PhoneApp.logic.Classes
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using PhoneApp.Data;
    using PhoneApp.logic.Interfaces;
    using PhoneApp.Repository.Interfaces;
    using PhoneApp.Repository.Repositories;

    /// <summary>
    /// Provider Logic class with ILogicT interface.
    /// </summary>
    public class ProviderLogic : ILogic<Provider____, string>
    {
        private readonly IRepository<Provider____, string> providerRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="ProviderLogic"/> class.
        /// Provider Logic ctor create repo.
        /// </summary>
        /// <param name="providerRepository">Produce Repository.</param>
        public ProviderLogic(IRepository<Provider____, string> providerRepository)
        {
           this.providerRepository = providerRepository;
        }

        /// <summary>
        /// Create new Database Entities.
        /// </summary>
        /// <returns>New ProviderLogic with new ProviderRepository.</returns>
        public static ILogic<Provider____, string> Creates()
        {
            var rep = new PhoneDatabaseEntities();
            return new ProviderLogic(new ProviderRepository(rep));
        }

        /// <summary>
        /// Provider Logic crud Delete method.
        /// ID is null or empty throw exeption.
        /// </summary>
        /// <param name="id">Selected row ID.</param>
        public void Delete(string id)
        {
            if (id == null || string.IsNullOrEmpty(id))
            {
                throw new ApplicationException("Wrong identitation");
            }

            this.providerRepository.Delete(id);
        }

        /// <summary>
        /// Provider Logic crud get all method.
        /// </summary>
        /// <returns>List type.</returns>
        public List<Provider____> GetAll()
        {
            return this.providerRepository.GetAll().ToList();
        }

        /// <summary>
        /// Provider Logic Read method.
        /// ID is null or empty throws exeption.
        /// </summary>
        /// <param name="id">Selected row ID.</param>
        /// <returns>Specific Provider type.</returns>
        public Provider____ GetById(string id)
        {
            if (id == null || string.IsNullOrEmpty(id))
            {
                throw new ApplicationException("Wrong identitation");
            }

            return this.providerRepository.GetById(id);
        }

        /// <summary>
        /// Provider Logic crud Update method.
        /// </summary>
        /// <param name="provider">New type datas.</param>
        /// <returns>Specific Provider type.</returns>
        public Provider____ Update(Provider____ provider)
        {
            var entityFromDb = this.providerRepository.GetById(provider.Id);

            entityFromDb.Name = provider.Name;

            entityFromDb.Year_of_Foundation = provider.Year_of_Foundation;
            entityFromDb.Country = provider.Country;
            entityFromDb.Reliability = provider.Reliability;
            entityFromDb.Coverage = provider.Coverage;
            entityFromDb.Id = provider.Id;
            var result = this.providerRepository.Update(entityFromDb
                );

            return result;
        }

        /// <summary>
        /// Provider Logic crud Create method.
        /// If Id is null or empty or reliability is negative it throw exeption.
        /// </summary>
        /// <param name="provider">New type.</param>
        /// <returns>Specific Provider type.</returns>
        public Provider____ Create(Provider____ provider)
        {
            if (provider.Id == null || provider.Id == " " || provider.Reliability < 0)
            {
                throw new ApplicationException("Wrong data");
            }

            var result = this.providerRepository.Create(provider);

            return result;
        }
    }
}
