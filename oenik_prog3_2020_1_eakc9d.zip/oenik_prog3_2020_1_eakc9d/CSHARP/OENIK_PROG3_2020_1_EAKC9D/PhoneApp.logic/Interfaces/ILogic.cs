﻿// <copyright file="ILogic.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace PhoneApp.logic.Interfaces
{
    using System.Collections.Generic;

    /// <summary>
    /// ILogic interface.
    /// </summary>
    /// <typeparam name="T">Specific type.(Model/Brand/Provider).</typeparam>
    /// <typeparam name="TK">String now.</typeparam>
    public interface ILogic<T, TK>
    {
        /// <summary>
        /// CRUD Get all.
        /// </summary>
        /// <returns>List type.</returns>
        List<T> GetAll();

        /// <summary>
        /// CRUD Read.
        /// </summary>
        /// <param name="id">Selected row ID.</param>
        /// <returns>Specific type.</returns>
        T GetById(TK id);

        /// <summary>
        /// CRUD Create.
        /// </summary>
        /// <param name="newtype">New type datas.</param>
        /// <returns>Specific type.</returns>
        T Create(T newtype);

        /// <summary>
        /// CRUD Update.
        /// </summary>
        /// <param name="change">New type datas.</param>
        /// <returns>Specific type.</returns>
        T Update(T change);

        /// <summary>
        /// CRUD Delete.
        /// </summary>
        /// <param name="id">Selected row ID.</param>
        void Delete(TK id);
    }
}
