CREATE TABLE [dbo].[Modell] (
    [Id]               CHAR (30)  NOT NULL,
    [Name]             CHAR (30)  NULL,
    [Base_Price]       INT        NULL,
    [Display_Size]     FLOAT (53) NULL,
    [Operating_System] CHAR (30)  NULL,
    [Brand_ID]         CHAR (30)  NULL,
    [Provider_ID]      CHAR (30)  NULL,
    [Guarantee]        INT        NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [ModellForeignKey] FOREIGN KEY ([Brand_ID]) REFERENCES [dbo].[BRAND] ([Id]),
    CONSTRAINT [ProviderForeignKey] FOREIGN KEY ([Provider_ID]) REFERENCES [dbo].[Provider

] ([Id])
);


CREATE TABLE [dbo].[BRAND] (
    [Id]                 CHAR (30) NOT NULL,
    [Name]               CHAR (30) NULL,
    [Year_of_Foundation] INT       NULL,
    [Country_Name]       CHAR (30) NULL,
    [Reliability]        INT       NULL,
    [Factory_inHungary]  BIT       NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE TABLE [dbo].[Provider

] (
    [Id]                 CHAR (30) NOT NULL,
    [Country]            CHAR (30) NULL,
    [Name]               CHAR (30) NULL,
    [Year_of_Foundation] INT       NULL,
    [Reliability]        INT       NULL,
    [Coverage]           INT       NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);


INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'BL10                          ', N'BlackBerry_Z10                ', 22000, 4.2, N'BlackBerry_OS                 ', N'BL                            ', N'DI                            ', 1)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'BL5                           ', N'BlackBerry_Q5                 ', 20000, 3.1, N'BlackBerry_OS                 ', N'BL                            ', N'VO                            ', 2)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'BLk                           ', N'BlackBerry_KeyOne             ', 10000, 4.5, N'BlackBerry_OS                 ', N'BL                            ', N'IN                            ', 1)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'H10                           ', N'Honor10                       ', 92000, 5.8, N'Oreo                          ', N'HU                            ', N'TK                            ', 3)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'HJ5                           ', N'Huawei_J5_2019                ', 40000, 5.71, N'EMUI                          ', N'HU                            ', N'VO                            ', 2)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'HM20                          ', N'Huawei_Mate20_Lite            ', 68000, 6.3, N'EMUI                          ', N'HU                            ', N'VO                            ', 2)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'I11                           ', N'iPhone_11                     ', 290000, 6.1, N'iOS                           ', N'Ap                            ', N'TE                            ', 2)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'I5                            ', N'iPhone_5S                     ', 80000, 4, N'iOS                           ', N'Ap                            ', N'TK                            ', 3)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'IX                            ', N'iPhone_XS                     ', 270000, 5.8, N'iOS                           ', N'Ap                            ', N'DI                            ', 2)


INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'Lg20                          ', N'LG_K20                        ', 38000, 5.45, N'Android                       ', N'L                             ', N'DI                            ', 3)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'Lg6                           ', N'LG_Q6                         ', 48000, 5.5, N'Nougat                        ', N'L                             ', N'IN                            ', 3)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'Lg70                          ', N'LG_L70                        ', 33000, 4.5, N'KitKat                        ', N'L                             ', N'DI                            ', 3)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'LK6                           ', N'LenovoK6                      ', 50000, 5, N'Android                       ', N'LE                            ', N'TK                            ', 4)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'LP90                          ', N'Lenovo_P90                    ', 83000, 5.5, N'Android                       ', N'LE                            ', N'TE                            ', 2)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'LVA                           ', N'Lenovo_Vibe_A                 ', 49000, 5.3, N'Android                       ', N'LE                            ', N'VO                            ', 2)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'NO9                           ', N'Nokia_PureView9               ', 165000, 5.99, N'Android                       ', N'NO                            ', N'TE                            ', 1)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'NOa           NO6             ', N'Nokia6                        ', 53000, 5.5, N'Nougat                        ', N'NO                            ', N'DI                            ', 2)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'NOx                           ', N'Nokia_X                       ', 30000, 4, N'Jelly_Bean                    ', N'NO                            ', N'VO                            ', 1)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'S10E                          ', N'Samsung_Galaxy_S10e           ', 173000, 5.8, N'Android                       ', N'SA                            ', N'DI                            ', 2)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'S40                           ', N'Samsung_Galaxy_A40            ', 66000, 5.9, N'Android                       ', N'SA                            ', N'IN                            ', 3)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'SJ6                           ', N'Samsung_Galaxy_J6_2018        ', 64000, 5.6, N'Android                       ', N'SA                            ', N'TK                            ', 1)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'SO10                          ', N'Sony_Xperia10                 ', 80000, 6, N'Android                       ', N'SO                            ', N'TK                            ', 2)
INSERT INTO [dbo].[Modell] ([Id], [Name], [Base_Price], [Display_Size], [Operating_System], [Brand_ID], [Provider_ID], [Guarantee]) VALUES (N'SOS                           ', N'Sony_XperiaSp                 ', 36000, 4.6, N'Jelly_Bean                    ', N'SO                            ', N'TE                            ', 1)

INSERT INTO [dbo].[Provider

] ([Id], [Country], [Name], [Year_of_Foundation], [Reliability], [Coverage]) VALUES (N'DI                            ', N'NetherLands                   ', N'Digi                          ', 1996, 10, 55)
INSERT INTO [dbo].[Provider

] ([Id], [Country], [Name], [Year_of_Foundation], [Reliability], [Coverage]) VALUES (N'IN                            ', N'Hungary                       ', N'Invitel                       ', 1995, 8, 40)
INSERT INTO [dbo].[Provider

] ([Id], [Country], [Name], [Year_of_Foundation], [Reliability], [Coverage]) VALUES (N'TE                            ', N'Czech_Republic                ', N'Telenor                       ', 1994, 7, 98)
INSERT INTO [dbo].[Provider

] ([Id], [Country], [Name], [Year_of_Foundation], [Reliability], [Coverage]) VALUES (N'TK                            ', N'Hungary                       ', N'Telekom                       ', 2005, 9, 98)
INSERT INTO [dbo].[Provider

] ([Id], [Country], [Name], [Year_of_Foundation], [Reliability], [Coverage]) VALUES (N'VO                            ', N'England                       ', N'Vodafone                      ', 1982, 10, 95)




INSERT INTO [dbo].[BRAND] ([Id], [Name], [Year_of_Foundation], [Country_Name], [Reliability], [Factory_inHungary]) VALUES (N'Ap                            ', N'Apple                         ', 1976, N'USA                           ', 9, 1)
INSERT INTO [dbo].[BRAND] ([Id], [Name], [Year_of_Foundation], [Country_Name], [Reliability], [Factory_inHungary]) VALUES (N'BL                            ', N'BlackBerry                    ', 1984, N'Kanada                        ', 7, 0)
INSERT INTO [dbo].[BRAND] ([Id], [Name], [Year_of_Foundation], [Country_Name], [Reliability], [Factory_inHungary]) VALUES (N'HU                            ', N'           Huawei             ', 1987, N'China                         ', 5, 0)
INSERT INTO [dbo].[BRAND] ([Id], [Name], [Year_of_Foundation], [Country_Name], [Reliability], [Factory_inHungary]) VALUES (N'L                             ', N'LG                            ', 1958, N'South-Korea                   ', 8, 1)
INSERT INTO [dbo].[BRAND] ([Id], [Name], [Year_of_Foundation], [Country_Name], [Reliability], [Factory_inHungary]) VALUES (N'LE                            ', N'Lenovo                        ', 1984, N'China                         ', 6, 1)
INSERT INTO [dbo].[BRAND] ([Id], [Name], [Year_of_Foundation], [Country_Name], [Reliability], [Factory_inHungary]) VALUES (N'NO                            ', N'Nokia                         ', 1865, N'Finnland                      ', 9, 0)
INSERT INTO [dbo].[BRAND] ([Id], [Name], [Year_of_Foundation], [Country_Name], [Reliability], [Factory_inHungary]) VALUES (N'SA                            ', N'Samsung                       ', 1938, N'South-Korea                   ', 10, 1)
INSERT INTO [dbo].[BRAND] ([Id], [Name], [Year_of_Foundation], [Country_Name], [Reliability], [Factory_inHungary]) VALUES (N'SO                            ', N'Sony                          ', 1946, N'Japan                         ', 5, 0)
