package servlet;


import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Patai Péter
 */
public class PhoneDataFields {
    
   public enum Kategoriak {Low, Normal, Hight, VIP};
          
    private int price;
    
    private int reliability;
    
    private Kategoriak kategoriak;

    public Kategoriak getKategoriak() {
       return kategoriak;
    }

    public int getReliability() {
        return reliability;
    }
    
    private double displaysize;

    public double getDisplaysize() {
        return displaysize;
    }
     
    private int guarantee;
    
    Random r = new Random();

    /*public PhoneDataFields() {
      
       this.price= r.nextInt(100000)+10000;
        this.guarantee = r.nextInt(4);
       this.displaysize = r.nextInt(3)+ 4 + r.nextDouble();
        this.reliability = r.nextInt(20);
    }*/

    public PhoneDataFields(int price, int reliability,  double displaysize, int guarantee) {
        this.price = price;
        this.reliability = reliability;
        this.displaysize = displaysize;
        this.guarantee = guarantee;
    }

    
   

 
    public int getPrice() {
        return price;
    }

    

    public int getGuarantee() {
        return guarantee;
    }
    
    public int SummPoint()
    {
        int summ=0;
       if( getPrice()<35000)
       {
           summ++;
       }
       else if(getPrice()<60000)
       {
           summ+=2;
       }
       else if(getPrice()<85000)
       {
          summ+=3;
       }
         else if(getPrice()<110000)
       {
           summ+=4;
       }
     if(getReliability()<=5)
     {
         summ++;
     }
     else  if(getReliability()<=10)
     {
         summ+=2;
     }
     else  if(getReliability()<=15)
     {
         summ+=3;
     }
     else  if(getReliability()<=20)
     {
        summ+=4;
     }
     
     if(getDisplaysize()<=4.75)
     {
         summ++;
     }
     else if(getDisplaysize()<=5.25)
     {
         summ+=2;
     }
       
     else if(getDisplaysize()<=5.8)
     {
         summ+=3;
     }
     
     else if(getDisplaysize()<=6.3) 
     {
         summ+=4;
     }
     
     
    switch (getGuarantee()) {
            case 1: summ++; break;
            case 2: summ+=2; break;
            case 3: summ+=3; break;
            case 4: summ+=4; break;
        }
    return summ;
    }
    
    public Kategoriak megfeleloKategoria()
    {
       Kategoriak category = getKategoriak().VIP;
        int categoryPoint= SummPoint();
       if(categoryPoint<=4)
       {
           category = getKategoriak().Low;
       }
      else if(categoryPoint<=8)
       {
           category = getKategoriak().Normal;
       }
       
      else if (categoryPoint<=12)
      {
          category = getKategoriak().Hight;
      }
       return category;
    }
    
    
}
