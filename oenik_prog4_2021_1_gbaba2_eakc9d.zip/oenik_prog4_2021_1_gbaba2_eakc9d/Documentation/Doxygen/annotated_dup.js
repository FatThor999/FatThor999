var annotated_dup =
[
    [ "GameRenderer", "namespace_game_renderer.html", [
      [ "MoneyheistGameRenderer", "class_game_renderer_1_1_moneyheist_game_renderer.html", "class_game_renderer_1_1_moneyheist_game_renderer" ]
    ] ],
    [ "MoneyHeist", "namespace_money_heist.html", [
      [ "Logic", "namespace_money_heist_1_1_logic.html", [
        [ "Interfaces", "namespace_money_heist_1_1_logic_1_1_interfaces.html", [
          [ "IGameLogic", "interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_game_logic.html", "interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_game_logic" ],
          [ "IRepoLogic", "interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_repo_logic.html", "interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_repo_logic" ]
        ] ],
        [ "MoneyHeistLogic", "class_money_heist_1_1_logic_1_1_money_heist_logic.html", "class_money_heist_1_1_logic_1_1_money_heist_logic" ],
        [ "RepoLogic", "class_money_heist_1_1_logic_1_1_repo_logic.html", "class_money_heist_1_1_logic_1_1_repo_logic" ]
      ] ],
      [ "Model", "namespace_money_heist_1_1_model.html", [
        [ "Character", "class_money_heist_1_1_model_1_1_character.html", "class_money_heist_1_1_model_1_1_character" ],
        [ "Config", "class_money_heist_1_1_model_1_1_config.html", "class_money_heist_1_1_model_1_1_config" ],
        [ "GameModel", "class_money_heist_1_1_model_1_1_game_model.html", "class_money_heist_1_1_model_1_1_game_model" ],
        [ "IGameModel", "interface_money_heist_1_1_model_1_1_i_game_model.html", "interface_money_heist_1_1_model_1_1_i_game_model" ],
        [ "MyImage", "class_money_heist_1_1_model_1_1_my_image.html", "class_money_heist_1_1_model_1_1_my_image" ],
        [ "Police", "class_money_heist_1_1_model_1_1_police.html", "class_money_heist_1_1_model_1_1_police" ],
        [ "SavedGame", "class_money_heist_1_1_model_1_1_saved_game.html", "class_money_heist_1_1_model_1_1_saved_game" ]
      ] ],
      [ "Pages", "namespace_money_heist_1_1_pages.html", [
        [ "HighScores", "class_money_heist_1_1_pages_1_1_high_scores.html", "class_money_heist_1_1_pages_1_1_high_scores" ],
        [ "LoadGame", "class_money_heist_1_1_pages_1_1_load_game.html", "class_money_heist_1_1_pages_1_1_load_game" ],
        [ "Login", "class_money_heist_1_1_pages_1_1_login.html", "class_money_heist_1_1_pages_1_1_login" ],
        [ "MainMenu", "class_money_heist_1_1_pages_1_1_main_menu.html", "class_money_heist_1_1_pages_1_1_main_menu" ],
        [ "PauseWindow", "class_money_heist_1_1_pages_1_1_pause_window.html", "class_money_heist_1_1_pages_1_1_pause_window" ]
      ] ],
      [ "Repository", "namespace_money_heist_1_1_repository.html", [
        [ "IRepository", "interface_money_heist_1_1_repository_1_1_i_repository.html", "interface_money_heist_1_1_repository_1_1_i_repository" ],
        [ "MoneyHeistRepository", "class_money_heist_1_1_repository_1_1_money_heist_repository.html", "class_money_heist_1_1_repository_1_1_money_heist_repository" ]
      ] ],
      [ "Tests", "namespace_money_heist_1_1_tests.html", [
        [ "GameLogicTest", "class_money_heist_1_1_tests_1_1_game_logic_test.html", "class_money_heist_1_1_tests_1_1_game_logic_test" ]
      ] ],
      [ "App", "class_money_heist_1_1_app.html", "class_money_heist_1_1_app" ],
      [ "MainWindow", "class_money_heist_1_1_main_window.html", "class_money_heist_1_1_main_window" ],
      [ "MoneyHeistControl", "class_money_heist_1_1_money_heist_control.html", "class_money_heist_1_1_money_heist_control" ],
      [ "GameEndWindow", "class_money_heist_1_1_game_end_window.html", "class_money_heist_1_1_game_end_window" ],
      [ "SaveGame", "class_money_heist_1_1_save_game.html", "class_money_heist_1_1_save_game" ]
    ] ],
    [ "XamlGeneratedNamespace", "namespace_xaml_generated_namespace.html", [
      [ "GeneratedInternalTypeHelper", "class_xaml_generated_namespace_1_1_generated_internal_type_helper.html", "class_xaml_generated_namespace_1_1_generated_internal_type_helper" ]
    ] ]
];