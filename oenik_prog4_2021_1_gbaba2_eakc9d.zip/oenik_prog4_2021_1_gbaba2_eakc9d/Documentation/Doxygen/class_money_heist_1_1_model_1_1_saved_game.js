var class_money_heist_1_1_model_1_1_saved_game =
[
    [ "Date", "class_money_heist_1_1_model_1_1_saved_game.html#a540adb6037d55edc4cbc91514c7efb37", null ],
    [ "Name", "class_money_heist_1_1_model_1_1_saved_game.html#a2d3fa39cef7705ffd9a537e3feef6b77", null ],
    [ "Score", "class_money_heist_1_1_model_1_1_saved_game.html#abdb0a89ccedd5eb29474c72d409f1ee9", null ],
    [ "Time", "class_money_heist_1_1_model_1_1_saved_game.html#afb5df2df277808795ecabda7ae95fca3", null ]
];