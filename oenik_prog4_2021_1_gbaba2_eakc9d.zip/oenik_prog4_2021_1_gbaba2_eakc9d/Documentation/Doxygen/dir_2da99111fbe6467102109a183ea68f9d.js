var dir_2da99111fbe6467102109a183ea68f9d =
[
    [ "net5.0-windows", "dir_99bb67f15e2fdeb8f0b176a07f2479a9.html", "dir_99bb67f15e2fdeb8f0b176a07f2479a9" ]
];