var dir_361573e21b810f38290345d5ffadcbb1 =
[
    [ "net5.0-windows", "dir_0dd099fa1b717e999552c59e3251c898.html", "dir_0dd099fa1b717e999552c59e3251c898" ]
];