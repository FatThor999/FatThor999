var dir_5bb6f5360a7192dc50eb4f7eed41865f =
[
    [ "IGameLogic.cs", "_i_game_logic_8cs_source.html", null ],
    [ "IRepoLogic.cs", "_i_repo_logic_8cs_source.html", null ]
];