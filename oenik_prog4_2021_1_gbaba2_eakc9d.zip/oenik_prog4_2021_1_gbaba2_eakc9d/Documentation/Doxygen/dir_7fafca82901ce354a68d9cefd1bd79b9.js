var dir_7fafca82901ce354a68d9cefd1bd79b9 =
[
    [ ".NETCoreApp,Version=v5.0.AssemblyAttributes.cs", "_money_heist_8_logic_2obj_2_debug_2net5_80-windows_2_8_n_e_t_core_app_00_version_0av5_80_8_assembly_attributes_8cs_source.html", null ],
    [ "MoneyHeist.Logic.AssemblyInfo.cs", "_money_heist_8_logic_8_assembly_info_8cs_source.html", null ]
];