var dir_bac5acf845a521e92ee61683a9ef99c8 =
[
    [ ".NETCoreApp,Version=v5.0.AssemblyAttributes.cs", "_game_renderer_2obj_2_debug_2net5_80-windows_2_8_n_e_t_core_app_00_version_0av5_80_8_assembly_attributes_8cs_source.html", null ],
    [ "GameRenderer.AssemblyInfo.cs", "_game_renderer_8_assembly_info_8cs_source.html", null ],
    [ "MoneyHeist.GameRenderer.AssemblyInfo.cs", "_money_heist_8_game_renderer_8_assembly_info_8cs_source.html", null ]
];