var dir_c41d64f158997332b6ddc9930ae09ec2 =
[
    [ "net5.0-windows", "dir_bac5acf845a521e92ee61683a9ef99c8.html", "dir_bac5acf845a521e92ee61683a9ef99c8" ]
];