var dir_db65501c36e667d3db19db2797185005 =
[
    [ "net5.0-windows", "dir_6dc305adace7c2673f33323688dc0506.html", "dir_6dc305adace7c2673f33323688dc0506" ]
];