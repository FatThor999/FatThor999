var dir_f63260d0612c28e3aa6193c857501dba =
[
    [ "net5.0-windows", "dir_7fafca82901ce354a68d9cefd1bd79b9.html", "dir_7fafca82901ce354a68d9cefd1bd79b9" ]
];