var hierarchy =
[
    [ "Application", null, [
      [ "MoneyHeist.App", "class_money_heist_1_1_app.html", null ]
    ] ],
    [ "System.Windows.Application", null, [
      [ "MoneyHeist.App", "class_money_heist_1_1_app.html", null ],
      [ "MoneyHeist.App", "class_money_heist_1_1_app.html", null ]
    ] ],
    [ "MoneyHeist.Model.Character", "class_money_heist_1_1_model_1_1_character.html", null ],
    [ "MoneyHeist.Model.Config", "class_money_heist_1_1_model_1_1_config.html", null ],
    [ "FrameworkElement", null, [
      [ "MoneyHeist.MoneyHeistControl", "class_money_heist_1_1_money_heist_control.html", null ]
    ] ],
    [ "MoneyHeist.Tests.GameLogicTest", "class_money_heist_1_1_tests_1_1_game_logic_test.html", null ],
    [ "System.Windows.Markup.IComponentConnector", null, [
      [ "MoneyHeist.GameEndWindow", "class_money_heist_1_1_game_end_window.html", null ],
      [ "MoneyHeist.MainWindow", "class_money_heist_1_1_main_window.html", null ],
      [ "MoneyHeist.MainWindow", "class_money_heist_1_1_main_window.html", null ],
      [ "MoneyHeist.Pages.HighScores", "class_money_heist_1_1_pages_1_1_high_scores.html", null ],
      [ "MoneyHeist.Pages.HighScores", "class_money_heist_1_1_pages_1_1_high_scores.html", null ],
      [ "MoneyHeist.Pages.LoadGame", "class_money_heist_1_1_pages_1_1_load_game.html", null ],
      [ "MoneyHeist.Pages.LoadGame", "class_money_heist_1_1_pages_1_1_load_game.html", null ],
      [ "MoneyHeist.Pages.Login", "class_money_heist_1_1_pages_1_1_login.html", null ],
      [ "MoneyHeist.Pages.MainMenu", "class_money_heist_1_1_pages_1_1_main_menu.html", null ],
      [ "MoneyHeist.Pages.MainMenu", "class_money_heist_1_1_pages_1_1_main_menu.html", null ],
      [ "MoneyHeist.Pages.PauseWindow", "class_money_heist_1_1_pages_1_1_pause_window.html", null ],
      [ "MoneyHeist.SaveGame", "class_money_heist_1_1_save_game.html", null ],
      [ "MoneyHeist.SaveGame", "class_money_heist_1_1_save_game.html", null ]
    ] ],
    [ "MoneyHeist.Logic.Interfaces.IGameLogic< T, TK >", "interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_game_logic.html", null ],
    [ "MoneyHeist.Logic.Interfaces.IGameLogic< Direction, Rect >", "interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_game_logic.html", [
      [ "MoneyHeist.Logic.MoneyHeistLogic", "class_money_heist_1_1_logic_1_1_money_heist_logic.html", null ]
    ] ],
    [ "MoneyHeist.Model.IGameModel", "interface_money_heist_1_1_model_1_1_i_game_model.html", [
      [ "MoneyHeist.Model.GameModel", "class_money_heist_1_1_model_1_1_game_model.html", null ]
    ] ],
    [ "System.Windows.Markup.InternalTypeHelper", null, [
      [ "XamlGeneratedNamespace.GeneratedInternalTypeHelper", "class_xaml_generated_namespace_1_1_generated_internal_type_helper.html", null ]
    ] ],
    [ "MoneyHeist.Logic.Interfaces.IRepoLogic", "interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_repo_logic.html", [
      [ "MoneyHeist.Logic.RepoLogic", "class_money_heist_1_1_logic_1_1_repo_logic.html", null ]
    ] ],
    [ "MoneyHeist.Repository.IRepository< TGameModel, THighScore >", "interface_money_heist_1_1_repository_1_1_i_repository.html", null ],
    [ "MoneyHeist.Repository.IRepository< IGameModel, SavedGame >", "interface_money_heist_1_1_repository_1_1_i_repository.html", [
      [ "MoneyHeist.Repository.MoneyHeistRepository", "class_money_heist_1_1_repository_1_1_money_heist_repository.html", null ]
    ] ],
    [ "MoneyHeist.Repository.IRepository< MoneyHeist.Model.IGameModel, MoneyHeist.Model.SavedGame >", "interface_money_heist_1_1_repository_1_1_i_repository.html", null ],
    [ "GameRenderer.MoneyheistGameRenderer", "class_game_renderer_1_1_moneyheist_game_renderer.html", null ],
    [ "MoneyHeist.Model.MyImage", "class_money_heist_1_1_model_1_1_my_image.html", null ],
    [ "System.Windows.Controls.Page", null, [
      [ "MoneyHeist.Pages.Login", "class_money_heist_1_1_pages_1_1_login.html", null ]
    ] ],
    [ "MoneyHeist.Model.Police", "class_money_heist_1_1_model_1_1_police.html", null ],
    [ "MoneyHeist.Model.SavedGame", "class_money_heist_1_1_model_1_1_saved_game.html", null ],
    [ "System.Windows.Window", null, [
      [ "MoneyHeist.GameEndWindow", "class_money_heist_1_1_game_end_window.html", null ],
      [ "MoneyHeist.MainWindow", "class_money_heist_1_1_main_window.html", null ],
      [ "MoneyHeist.MainWindow", "class_money_heist_1_1_main_window.html", null ],
      [ "MoneyHeist.MainWindow", "class_money_heist_1_1_main_window.html", null ],
      [ "MoneyHeist.Pages.HighScores", "class_money_heist_1_1_pages_1_1_high_scores.html", null ],
      [ "MoneyHeist.Pages.HighScores", "class_money_heist_1_1_pages_1_1_high_scores.html", null ],
      [ "MoneyHeist.Pages.HighScores", "class_money_heist_1_1_pages_1_1_high_scores.html", null ],
      [ "MoneyHeist.Pages.LoadGame", "class_money_heist_1_1_pages_1_1_load_game.html", null ],
      [ "MoneyHeist.Pages.LoadGame", "class_money_heist_1_1_pages_1_1_load_game.html", null ],
      [ "MoneyHeist.Pages.LoadGame", "class_money_heist_1_1_pages_1_1_load_game.html", null ],
      [ "MoneyHeist.Pages.MainMenu", "class_money_heist_1_1_pages_1_1_main_menu.html", null ],
      [ "MoneyHeist.Pages.MainMenu", "class_money_heist_1_1_pages_1_1_main_menu.html", null ],
      [ "MoneyHeist.Pages.MainMenu", "class_money_heist_1_1_pages_1_1_main_menu.html", null ],
      [ "MoneyHeist.Pages.PauseWindow", "class_money_heist_1_1_pages_1_1_pause_window.html", null ],
      [ "MoneyHeist.SaveGame", "class_money_heist_1_1_save_game.html", null ],
      [ "MoneyHeist.SaveGame", "class_money_heist_1_1_save_game.html", null ],
      [ "MoneyHeist.SaveGame", "class_money_heist_1_1_save_game.html", null ]
    ] ]
];