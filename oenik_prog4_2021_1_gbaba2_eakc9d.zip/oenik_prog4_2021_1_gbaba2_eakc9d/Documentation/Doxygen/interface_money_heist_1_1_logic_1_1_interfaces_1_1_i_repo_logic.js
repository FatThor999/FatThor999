var interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_repo_logic =
[
    [ "LoadGameModel", "interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_repo_logic.html#a0acfe252ada6d1751eaa6487ff23c66d", null ],
    [ "LoadHighScores", "interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_repo_logic.html#a5672fc728366c704135d9de3ad2122a8", null ],
    [ "SaveGameModel", "interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_repo_logic.html#a6a9e09a4ae97b81bf42df253ae9719e9", null ],
    [ "SaveHighScore", "interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_repo_logic.html#a9d741596add99e5d0200bf8d072d7dec", null ]
];