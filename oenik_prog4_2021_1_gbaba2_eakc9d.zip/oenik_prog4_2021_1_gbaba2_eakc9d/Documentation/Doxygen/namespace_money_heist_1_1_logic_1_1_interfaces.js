var namespace_money_heist_1_1_logic_1_1_interfaces =
[
    [ "IGameLogic", "interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_game_logic.html", "interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_game_logic" ],
    [ "IRepoLogic", "interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_repo_logic.html", "interface_money_heist_1_1_logic_1_1_interfaces_1_1_i_repo_logic" ]
];