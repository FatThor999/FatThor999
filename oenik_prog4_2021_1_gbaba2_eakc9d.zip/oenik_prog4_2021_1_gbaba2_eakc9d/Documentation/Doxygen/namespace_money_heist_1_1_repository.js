var namespace_money_heist_1_1_repository =
[
    [ "IRepository", "interface_money_heist_1_1_repository_1_1_i_repository.html", "interface_money_heist_1_1_repository_1_1_i_repository" ],
    [ "MoneyHeistRepository", "class_money_heist_1_1_repository_1_1_money_heist_repository.html", "class_money_heist_1_1_repository_1_1_money_heist_repository" ]
];