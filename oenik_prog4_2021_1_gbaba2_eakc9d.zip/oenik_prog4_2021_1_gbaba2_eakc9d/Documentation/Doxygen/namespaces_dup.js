var namespaces_dup =
[
    [ "GameRenderer", "namespace_game_renderer.html", "namespace_game_renderer" ],
    [ "MoneyHeist", "namespace_money_heist.html", "namespace_money_heist" ],
    [ "XamlGeneratedNamespace", "namespace_xaml_generated_namespace.html", "namespace_xaml_generated_namespace" ]
];