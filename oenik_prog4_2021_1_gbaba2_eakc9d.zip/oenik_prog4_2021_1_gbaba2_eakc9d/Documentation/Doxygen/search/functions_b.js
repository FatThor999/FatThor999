var searchData=
[
  ['repologic_229',['RepoLogic',['../class_money_heist_1_1_logic_1_1_repo_logic.html#ab527955e6ce25886bd153bc92320eea3',1,'MoneyHeist.Logic.RepoLogic.RepoLogic()'],['../class_money_heist_1_1_logic_1_1_repo_logic.html#af71087f92c0d86bc42a4d71965608574',1,'MoneyHeist.Logic.RepoLogic.RepoLogic(IRepository&lt; IGameModel, SavedGame &gt; repo)']]]
];
