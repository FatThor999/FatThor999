var indexSectionsWithContent =
{
  0: "abcdeghilmnoprstuwx",
  1: "acghilmprs",
  2: "gmx",
  3: "abceghilmoprs",
  4: "d",
  5: "dlnru",
  6: "abdeghnpstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "enums",
  5: "enumvalues",
  6: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Enumerations",
  5: "Enumerator",
  6: "Properties"
};

