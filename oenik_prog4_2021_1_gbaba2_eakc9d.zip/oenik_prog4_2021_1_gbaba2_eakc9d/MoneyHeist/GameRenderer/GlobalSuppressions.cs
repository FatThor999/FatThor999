﻿// <copyright file="GlobalSuppressions.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage("Globalization", "CA1305:Specify IFormatProvider", Justification = "<NikGitStats>", Scope = "member", Target = "~M:GameRenderer.MoneyheistGameRenderer.AmmoCounter~System.Windows.Media.Drawing")]
[assembly: SuppressMessage("Globalization", "CA1305:Specify IFormatProvider", Justification = "<NikGitStats>", Scope = "member", Target = "~M:GameRenderer.MoneyheistGameRenderer.MoneyCounter~System.Windows.Media.Drawing")]
[assembly: SuppressMessage("Globalization", "CA1305:Specify IFormatProvider", Justification = "<NikGitStats>", Scope = "member", Target = "~M:GameRenderer.MoneyheistGameRenderer.HealthCounter~System.Windows.Media.Drawing")]
