// <copyright file="MoneyheistGameRenderer.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

using System;

[assembly: CLSCompliant(false)]

namespace GameRenderer
{
    using System.Collections.Generic;
    using System.Reflection;
    using System.Windows;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using MoneyHeist.Model;

    /// <summary>
    /// Gamerenderer class.
    /// </summary>
    public class MoneyheistGameRenderer
    {
        /// <summary>
        /// mybrushes.
        /// </summary>
        private Dictionary<string, Brush> brushes = new Dictionary<string, Brush>();
        private IGameModel model;

        /// <summary>
        /// Initializes a new instance of the <see cref="MoneyheistGameRenderer"/> class.
        /// </summary>
        /// <param name="model">model.</param>
        public MoneyheistGameRenderer(IGameModel model)
        {
            this.model = model;
        }

        private Brush BackgroundBrush
        {
            get { return this.GetBrush("MoneyHeist.GameRenderer.Images.backround.jpg"); }
        }

        private Brush WallBrush
        {
            get { return this.GetBrush("MoneyHeist.GameRenderer.Images.wall.jpg"); }
        }

        private Brush BulletBrush
        {
            get { return this.GetBrush("MoneyHeist.GameRenderer.Images.bullet.png"); }
        }

        private Brush PlayerBrush
        {
            get { return this.GetBrush("MoneyHeist.GameRenderer.Images.Nairobi.png"); }
        }

        private Brush PlayerReverseBrush
        {
            get { return this.GetBrush("MoneyHeist.GameRenderer.Images.NairobiReverse.png"); }
        }

        private Brush PoliceBrush
        {
            get { return this.GetBrush("MoneyHeist.GameRenderer.Images.PoliceOfficer.png"); }
        }

        private Brush PoliceReverseBrush
        {
            get { return this.GetBrush("MoneyHeist.GameRenderer.Images.PoliceOfficerReverse.png"); }
        }

        private Brush MoneyBrush
        {
            get { return this.GetBrush("MoneyHeist.GameRenderer.Images.Money.png"); }
        }

        private Brush GoldBrush
        {
            get { return this.GetBrush("MoneyHeist.GameRenderer.Images.bag_of_gold.png"); }
        }

        private Brush AmmoBrush
        {
            get { return this.GetBrush("MoneyHeist.GameRenderer.Images.ammo-Image.png"); }
        }

        private Brush HealthBrush
        {
            get { return this.GetBrush("MoneyHeist.GameRenderer.Images.health.png"); }
        }

        private Brush ProfessorBrush
        {
            get { return this.GetBrush("MoneyHeist.GameRenderer.Images.professor.png"); }
        }

        /// <summary>
        /// Adding brushes.
        /// </summary>
        /// <returns>drawingroup.</returns>
        public Drawing BuildDrawing()
        {
            DrawingGroup dg = new DrawingGroup();
            dg.Children.Add(this.GetBg());
            dg.Children.Add(this.GetPlayer());
            dg.Children.Add(this.GetMoney());
            dg.Children.Add(this.GetGold());
            dg.Children.Add(this.GetAmmo());
            dg.Children.Add(this.GetHealth());
            dg.Children.Add(this.GetProfessor());
            dg.Children.Add(this.AmmoCounter());
            dg.Children.Add(this.MoneyCounter());
            dg.Children.Add(this.HealthCounter());

            foreach (var police in this.model.Polices)
            {
                dg.Children.Add(this.GetPolice(police));
            }

            foreach (var bullet in this.model.PoliceBullets)
            {
                dg.Children.Add(this.GetBullet(bullet));
            }

            foreach (var bullet in this.model.Bullets)
            {
                dg.Children.Add(this.GetBullet(bullet));
            }

            foreach (var wall in this.model.Walls)
            {
                dg.Children.Add(this.GetWalls(wall));
            }

            return dg;
        }

        private Drawing GetBullet(MyImage bullet)
        {
            Geometry g = new RectangleGeometry(bullet.Area);
            GeometryDrawing getBullet = new GeometryDrawing(this.BulletBrush, null, g);
            return getBullet;
        }

        /// <summary>
        /// Initialize bitmapimages.
        /// </summary>
        /// <param name="fname">filename.</param>
        /// <returns>brushes.</returns>
        private Brush GetBrush(string fname)
        {
            if (!this.brushes.ContainsKey(fname))
            {
                BitmapImage bmp = new BitmapImage();
                bmp.BeginInit();
                bmp.StreamSource = Assembly.GetExecutingAssembly().GetManifestResourceStream(fname);
                bmp.EndInit();
                ImageBrush ib = new ImageBrush(bmp);
                this.brushes[fname] = ib;
            }

            return this.brushes[fname];
        }

        private Drawing GetProfessor()
        {
            GeometryDrawing professor = new GeometryDrawing(this.ProfessorBrush, null, new RectangleGeometry(this.model.Professor.Area));
            return professor;
        }

        private Drawing GetHealth()
        {
            GeometryDrawing health = new GeometryDrawing(this.HealthBrush, null, new RectangleGeometry(this.model.HealthBar.Area));
            return health;
        }

        private Drawing GetAmmo()
        {
            GeometryDrawing ammo = new GeometryDrawing(this.AmmoBrush, null, new RectangleGeometry(this.model.Ammo.Area));
            return ammo;
        }

        private Drawing GetGold()
        {
            GeometryDrawing gold = new GeometryDrawing(this.GoldBrush, null, new RectangleGeometry(this.model.Gold.Area));
            return gold;
        }

        private Drawing GetBg()
        {
            Geometry backgroundGeometry = new RectangleGeometry(new Rect(0, 0, Config.Width, Config.Height));
            GeometryDrawing gd = new GeometryDrawing(this.BackgroundBrush, null, backgroundGeometry);
            return gd;
        }

        private Drawing GetMoney()
        {
            GeometryDrawing money = new GeometryDrawing(this.MoneyBrush, null, new RectangleGeometry(this.model.Euro.Area));
            return money;
        }

        private Drawing GetPolice(Police police)
        {
            GeometryDrawing getpolice;
            getpolice = new GeometryDrawing(this.PoliceBrush, null, new RectangleGeometry(police.Area));

            if (police.Area.X > this.model.Player.Area.X)
            {
              getpolice = new GeometryDrawing(this.PoliceReverseBrush, null, new RectangleGeometry(police.Area));
            }

            return getpolice;
        }

        private Drawing GetWalls(MyImage wall)
        {
            GeometryDrawing getwalls = new GeometryDrawing(this.WallBrush, null, new RectangleGeometry(wall.Area));
            return getwalls;
        }

        private Drawing GetPlayer()
        {
            GeometryDrawing player;
            player = new GeometryDrawing(this.PlayerBrush, null, new RectangleGeometry(this.model.Player.Area));

            return player;
        }

        private Drawing AmmoCounter()
        {
            FormattedText formattedText = new FormattedText(
                this.model.SumAmmo.ToString(),
                System.Globalization.CultureInfo.CurrentCulture,
                FlowDirection.LeftToRight,
                new Typeface("Arial"),
                16,
                Brushes.Black,
                1);
            GeometryDrawing text = new GeometryDrawing(null, new Pen(Brushes.Red, 2), formattedText.BuildGeometry(new Point(5, 5)));

            return text;
        }

        private Drawing MoneyCounter()
        {
            FormattedText formattedText = new FormattedText(
              this.model.SumMoney.ToString(),
              System.Globalization.CultureInfo.CurrentCulture,
              FlowDirection.LeftToRight,
              new Typeface("Arial"),
              16,
              Brushes.Black,
              1);
            GeometryDrawing text = new GeometryDrawing(null, new Pen(Brushes.Red, 2), formattedText.BuildGeometry(new Point(Config.Width - 100, 5)));

            return text;
        }

        private Drawing HealthCounter()
        {
            FormattedText formattedText = new FormattedText(
              this.model.SumHealth.ToString(),
              System.Globalization.CultureInfo.CurrentCulture,
              FlowDirection.LeftToRight,
              new Typeface("Arial"),
              16,
              Brushes.Black,
              1);
            GeometryDrawing text = new GeometryDrawing(null, new Pen(Brushes.Red, 2), formattedText.BuildGeometry(new Point(Config.Width / 2, 5)));
            return text;
        }
    }
}
