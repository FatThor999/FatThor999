﻿// <copyright file="GlobalSuppressions.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage("Design", "CA1002:Do not expose generic lists", Justification = "<NikGitStats>", Scope = "member", Target = "~M:MoneyHeist.Logic.Interfaces.IRepoLogic.LoadHighScores~System.Collections.Generic.List{MoneyHeist.Model.SavedGame}")]
[assembly: SuppressMessage("Design", "CA1062:Validate arguments of public methods", Justification = "<NikGitStats>", Scope = "member", Target = "~M:MoneyHeist.Logic.RepoLogic.SaveHighScore(MoneyHeist.Model.IGameModel,System.String)")]
[assembly: SuppressMessage("Security", "CA5394:Do not use insecure randomness", Justification = "<NikGitStats>", Scope = "member", Target = "~M:MoneyHeist.Logic.MoneyHeistLogic.AmmoMaker")]
[assembly: SuppressMessage("Security", "CA5394:Do not use insecure randomness", Justification = "<NikGitStats>", Scope = "member", Target = "~M:MoneyHeist.Logic.MoneyHeistLogic.GoldMaker")]
[assembly: SuppressMessage("Security", "CA5394:Do not use insecure randomness", Justification = "<NikGitStats>", Scope = "member", Target = "~M:MoneyHeist.Logic.MoneyHeistLogic.EuroMaker")]
[assembly: SuppressMessage("Security", "CA5394:Do not use insecure randomness", Justification = "<NikGitStats>", Scope = "member", Target = "~M:MoneyHeist.Logic.MoneyHeistLogic.HealthBoxMaker")]
[assembly: SuppressMessage("Security", "CA5394:Do not use insecure randomness", Justification = "<NikGitStats>", Scope = "member", Target = "~M:MoneyHeist.Logic.MoneyHeistLogic.ProfessorEvent")]
