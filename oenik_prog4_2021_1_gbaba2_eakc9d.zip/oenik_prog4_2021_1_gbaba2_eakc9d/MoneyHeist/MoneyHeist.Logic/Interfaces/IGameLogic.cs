﻿// <copyright file="IGameLogic.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace MoneyHeist.Logic.Interfaces
{
    /// <summary>
    /// IGamelogic interface.
    /// </summary>
    /// <typeparam name="T"> T.</typeparam>
    /// <typeparam name="TK"> K.</typeparam>
    public interface IGameLogic<T, TK>
    {
        /// <summary>
        /// Moveplayer method.
        /// </summary>
        /// <param name="d"> d.</param>
        /// <returns>T.</returns>
        T MovePlayer(T d);

        /// <summary>
        /// Move enemy method.
        /// </summary>
        void MoveEnemy();

        /// <summary>
        /// Player shoot method.
        /// </summary>
        /// <param name="d"> d.</param>
        void PlayerShoot(T d);

        /// <summary>
        /// Enemy shoot method.
        /// </summary>
        void EnemyShoot();

        /// <summary>
        /// Game is end?.
        /// </summary>
        /// <returns> true or false.</returns>
        bool GameEnd();

        /// <summary>
        /// Professor event.
        /// </summary>
        void ProfessorEvent();

        /// <summary>
        /// Is ammo picked method.
        /// </summary>
        /// <returns> ispicked..</returns>
        bool IsAmmoPicked();

        /// <summary>
        /// Is gold picked method.
        /// </summary>
        /// <returns> ispicked.</returns>
        bool IsGoldPicked();

        /// <summary>
        /// Is money picked method.
        /// </summary>
        /// <returns>ispicked.</returns>
        bool IsMoneyPicked();

        /// <summary>
        /// Is health picked method.
        /// </summary>
        /// <returns>ispicked.</returns>
        bool IsHealthPicked();
    }
}
