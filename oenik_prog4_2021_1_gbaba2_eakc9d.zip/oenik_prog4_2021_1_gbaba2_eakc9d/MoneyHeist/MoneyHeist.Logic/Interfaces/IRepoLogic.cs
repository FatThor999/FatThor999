﻿// <copyright file="IRepoLogic.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace MoneyHeist.Logic.Interfaces
{
    using System.Collections.Generic;
    using MoneyHeist.Model;

    /// <summary>
    /// Login logic.
    /// </summary>
    public interface IRepoLogic
    {
        /// <summary>
        /// Loads the game.
        /// </summary>
        /// <param name="fileName">The saved file name.</param>
        /// <returns>Gamemodel.</returns>
        IGameModel LoadGameModel(string fileName);

        /// <summary>
        /// Saves the game model.
        /// </summary>
        /// <param name="model">Gamemodel to save.</param>
        /// <param name="text">Filename.</param>
        void SaveGameModel(IGameModel model, string text);

        /// <summary>
        /// Saves the highscore.
        /// </summary>
        /// <param name="model">Gamemodel.</param>
        /// <param name="text">Filename.</param>
        void SaveHighScore(IGameModel model, string text);

        /// <summary>
        /// Loads the highscore.
        /// </summary>
        /// <returns>List of saved games.</returns>
        List<SavedGame> LoadHighScores();
    }
}
