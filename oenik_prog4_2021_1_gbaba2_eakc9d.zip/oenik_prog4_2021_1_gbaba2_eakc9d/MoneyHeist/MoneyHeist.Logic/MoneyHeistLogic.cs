// <copyright file="MoneyHeistLogic.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

using System;

[assembly: CLSCompliant(false)]

namespace MoneyHeist.Logic
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Windows;
    using MoneyHeist.Logic.Interfaces;
    using MoneyHeist.Model;

    /// <summary>
    /// Directions.
    /// </summary>
    public enum Direction
    {
        /// <summary>
        /// Left.
        /// </summary>
        Left,

        /// <summary>
        /// Right.
        /// </summary>
        Right,

        /// <summary>
        /// Up.
        /// </summary>
        Up,

        /// <summary>
        /// Down.
        /// </summary>
        Down,

        /// <summary>
        /// Nothing.
        /// </summary>
        Nothing,
    }

    /// <summary>
    /// Main logic class.
    /// </summary>
    public class MoneyHeistLogic : IGameLogic<Direction, Rect>
    {
        private readonly Random r;

        /// <summary>
        /// Model param.
        /// </summary>
        private IGameModel model;

        /// <summary>
        /// Timer for gold.
        /// </summary>
        private Stopwatch goldTimer;
        private Stopwatch euroTimer;
        private Stopwatch ammoTimer;
        private Stopwatch healthTimer;
        private Stopwatch professorSpawnTimer;
        private Stopwatch professorExistTimer;

        /// <summary>
        /// Initializes a new instance of the <see cref="MoneyHeistLogic"/> class.
        /// </summary>
        /// <param name="model">gamemodel.</param>
        public MoneyHeistLogic(IGameModel model)
        {
            this.model = model;
            this.goldTimer = new Stopwatch();
            this.euroTimer = new Stopwatch();
            this.ammoTimer = new Stopwatch();
            this.healthTimer = new Stopwatch();
            this.professorSpawnTimer = new Stopwatch();
            this.professorExistTimer = new Stopwatch();
            this.r = new Random();
        }

        /// <summary>
        /// Game is ended logic.
        /// </summary>
        /// <returns>gameisend.</returns>
        public bool GameEnd()
        {
            bool gameIsEnd = false;

            if ((this.model.SumHealth <= 0) || (this.model.SumMoney >= 10000000))
            {
                gameIsEnd = true;
            }

            return gameIsEnd;
        }

        /// <summary>
        /// Enemy moving logic.
        /// </summary>
        public void MoveEnemy()
        {
            foreach (var police in this.model.Polices)
            {
                police.Dx = this.model.Player.Area.X - police.Area.X;
                police.Dy = this.model.Player.Area.Y - police.Area.Y;
                if (police.Dx > 0)
                {
                foreach (var wall in this.model.Walls)
                {
                if (police.Area.IntersectsWith(wall.Area) && police.Area.Right <= wall.Area.Left)
                {
                police.ChangeX(-Config.PoliceSpeed);
                }
                }

                police.ChangeX(Config.PoliceSpeed);
                }

                if (police.Dy < 0)
                {
            foreach (var wall in this.model.Walls)
            {
                if (police.Area.IntersectsWith(wall.Area) && police.Area.Top >= wall.Area.Bottom)
                {
                police.ChangeY(Config.PoliceSpeed);
                }
                }

            police.ChangeY(-Config.PoliceSpeed);
            }

                if (police.Dx < 0)
                    {
                           foreach (var wall in this.model.Walls)
                            {
                             if (police.Area.IntersectsWith(wall.Area) && police.Area.Left >= wall.Area.Right)
                             {
                            police.ChangeX(Config.PoliceSpeed);
                           }
                           }

                           police.ChangeX(-Config.PoliceSpeed);
                    }

                if (police.Dy > 0)
                    {
                          foreach (var wall in this.model.Walls)
                         {
                        if (police.Area.IntersectsWith(wall.Area) && police.Area.Bottom <= wall.Area.Top)
                        {
                            police.ChangeY(-Config.PoliceSpeed);
                        }
                        }

                          police.ChangeY(Config.PoliceSpeed);
                    }
            }
        }

        /// <summary>
        /// Player moving logic.
        /// </summary>
        /// <param name="d">direction.</param>
        /// <returns>Direction.</returns>
        public Direction MovePlayer(Direction d)
        {
            Direction direction = Direction.Nothing;
            if (d == Direction.Left)
            {
                foreach (var wall in this.model.Walls)
                {
                    if ((this.model.Player.Area.IntersectsWith(wall.Area) && this.model.Player.Area.Left >= wall.Area.Right) || this.model.Player.Area.Left <= 0)
                    {
                        this.model.Player.ChangeX(Config.Speed);
                        direction = Direction.Left;
                    }
                }

                this.model.Player.ChangeX(-Config.Speed);
            }
            else if (d == Direction.Right)
            {
                foreach (var wall in this.model.Walls)
                {
                    if ((this.model.Player.Area.IntersectsWith(wall.Area) && this.model.Player.Area.Right <= wall.Area.Left) || this.model.Player.Area.Right >= Config.Width)
                    {
                        this.model.Player.ChangeX(-Config.Speed);
                        direction = Direction.Right;
                    }
                }

                this.model.Player.ChangeX(Config.Speed);
            }
            else if (d == Direction.Up)
            {
                foreach (var wall in this.model.Walls)
                {
                    if ((this.model.Player.Area.IntersectsWith(wall.Area) && this.model.Player.Area.Top >= wall.Area.Bottom) || this.model.Player.Area.Top <= 0)
                    {
                        this.model.Player.ChangeY(Config.Speed);
                        direction = Direction.Up;
                    }
                }

                this.model.Player.ChangeY(-Config.Speed);
            }
            else if (d == Direction.Down)
            {
                foreach (var wall in this.model.Walls)
                {
                    if ((this.model.Player.Area.IntersectsWith(wall.Area) && this.model.Player.Area.Bottom <= wall.Area.Top) || this.model.Player.Area.Bottom >= Config.Height)
                    {
                        this.model.Player.ChangeY(-Config.Speed);
                        direction = Direction.Down;
                    }
                }

                this.model.Player.ChangeY(Config.Speed);
            }

            return direction;
        }

        /// <summary>
        /// Enemy shooting logic.
        /// </summary>
        public void EnemyShoot()
        {
            foreach (var police in this.model.Polices)
            {
                if (police.Area.X >= this.model.Player.Area.X &&
                   police.Area.Y > this.model.Player.Area.Y)
                {
                    this.model.PoliceBullets.Add(new MyImage(police.Area.X + 10, police.Area.Y + 30, 5, 5));
                    this.model.PoliceBullets.Last().BulletIsShotedUp = true;
                }
                else if (police.Area.X <= this.model.Player.Area.X &&
                    police.Area.Y < this.model.Player.Area.Y)
                {
                    this.model.PoliceBullets.Add(new MyImage(police.Area.X + 10, police.Area.Y + 30, 5, 5));
                    this.model.PoliceBullets.Last().BulletIsShotedDown = true;
                }
                else if (/*police.Area.Y >= this.model.Player.Area.Y &&*/
                    police.Area.X > this.model.Player.Area.X)
                {
                    this.model.PoliceBullets.Add(new MyImage(police.Area.X + 10, police.Area.Y + 30, 5, 5));
                    this.model.PoliceBullets.Last().BulletIsShotedLeft = true;
                }
                else if (/*police.Area.Y <= this.model.Player.Area.Y &&*/
                    police.Area.X < this.model.Player.Area.X)
                {
                    this.model.PoliceBullets.Add(new MyImage(police.Area.X + 10, police.Area.Y + 30, 5, 5));
                    this.model.PoliceBullets.Last().BulletIsShotedRight = true;
                }
            }
        }

        /// <summary>
        /// Player shooting logic.
        /// </summary>
        /// <param name="d">direction.</param>
        public void PlayerShoot(Direction d)
        {
            if (this.model.SumAmmo > 0)
            {
                if (d == Direction.Left)
                {
                    this.model.Bullets.Add(new MyImage(this.model.Player.Area.X + 10, this.model.Player.Area.Y + 30, 5, 5));
                    this.model.Bullets.Last().BulletIsShotedLeft = true;
                }
                else if (d == Direction.Right)
                {
                    this.model.Bullets.Add(new MyImage(this.model.Player.Area.X + 10, this.model.Player.Area.Y + 30, 5, 5));
                    this.model.Bullets.Last().BulletIsShotedRight = true;
                }
                else if (d == Direction.Up)
                {
                    this.model.Bullets.Add(new MyImage(this.model.Player.Area.X + 20, this.model.Player.Area.Y - 10, 5, 5));
                    this.model.Bullets.Last().BulletIsShotedUp = true;
                }
                else if (d == Direction.Down)
                {
                    this.model.Bullets.Add(new MyImage(this.model.Player.Area.X + 20, this.model.Player.Area.Y + 30, 5, 5));
                    this.model.Bullets.Last().BulletIsShotedDown = true;
                }

                this.model.SumAmmo--;
            }
        }

        /// <summary>
        /// Moves the police bullets.
        /// </summary>
        public void PoliceBulletMove()
        {
            List<MyImage> bulletsHelp = new List<MyImage>();

            foreach (var bullet in this.model.PoliceBullets)
            {
                bulletsHelp.Add(bullet);
            }

            foreach (var bullet in bulletsHelp)
            {
                if (bullet.BulletIsShotedUp == true)
                {
                    bullet.ChangeY(-Config.PoliceBulletSpeed);
                }
                else if (bullet.BulletIsShotedDown == true)
                {
                    bullet.ChangeY(Config.PoliceBulletSpeed);
                }
                else if (bullet.BulletIsShotedLeft == true)
                {
                    bullet.ChangeX(-Config.PoliceBulletSpeed);
                }
                else if (bullet.BulletIsShotedRight == true)
                {
                    bullet.ChangeX(Config.PoliceBulletSpeed);
                }

                foreach (var wall in this.model.Walls)
                {
                    if (bullet.Area.Top < 0
                  || bullet.Area.IntersectsWith(wall.Area) || bullet.Area.Left < 0 || bullet.Area.Right
                  > Config.Width || bullet.Area.Bottom > Config.Height)
                    {
                        bullet.BulletIsShotedUp = false;
                        bullet.BulletIsShotedRight = false;
                        bullet.BulletIsShotedLeft = false;
                        bullet.BulletIsShotedDown = false;
                        this.model.PoliceBullets.Remove(bullet);
                    }
                }
            }

            bulletsHelp.Clear();
        }

        /// <summary>
        /// Moves the bullets.
        /// </summary>
        public void BulletMove()
        {
            List<MyImage> bulletsHelp = new List<MyImage>();

            foreach (var bullet in this.model.Bullets)
            {
                bulletsHelp.Add(bullet);
            }

            foreach (var bullet in bulletsHelp)
            {
                if (bullet.BulletIsShotedUp == true)
                {
                    bullet.ChangeY(-Config.BulletSpeed);
                }
                else if (bullet.BulletIsShotedDown == true)
                {
                    bullet.ChangeY(Config.BulletSpeed);
                }
                else if (bullet.BulletIsShotedLeft == true)
                {
                    bullet.ChangeX(-Config.BulletSpeed);
                }
                else if (bullet.BulletIsShotedRight == true)
                {
                    bullet.ChangeX(Config.BulletSpeed);
                }

                foreach (var wall in this.model.Walls)
                {
                    if (bullet.Area.Top < 0
                  || bullet.Area.IntersectsWith(wall.Area) || bullet.Area.Left < 0 || bullet.Area.Right > Config.Width ||
                   bullet.Area.Bottom > Config.Height)
                    {
                        bullet.BulletIsShotedUp = false;
                        bullet.BulletIsShotedRight = false;
                        bullet.BulletIsShotedLeft = false;
                        bullet.BulletIsShotedDown = false;
                        this.model.Bullets.Remove(bullet);
                    }
                }
            }

            bulletsHelp.Clear();
        }

        /// <summary>
        /// Player damage logic.
        /// </summary>
        public void PlayerGetsShot()
        {
            List<MyImage> bulletsHelp = new List<MyImage>();

            foreach (var bullet in this.model.PoliceBullets)
            {
                bulletsHelp.Add(bullet);
            }

            var polices = this.model.Polices;

            foreach (var bullet in bulletsHelp)
            {
                if (bullet.Area.IntersectsWith(this.model.Player.Area))
                {
                    this.model.SumHealth -= 20;
                    this.model.PoliceBullets.Remove(bullet);
                }
            }

            bulletsHelp.Clear();

            foreach (var police in polices)
            {
                if (this.model.Player.Area.IntersectsWith(police.Area))
                {
                    this.model.SumHealth -= 25;
                    police.GetShot = true;
                }
            }
        }

        /// <summary>
        /// Police damage logic.
        /// </summary>
        public void PoliceGetsShot()
        {
            List<MyImage> bulletsHelp = new List<MyImage>();

            foreach (var bullet in this.model.Bullets)
            {
                bulletsHelp.Add(bullet);
            }

            var policies = this.model.Polices;

            foreach (var police in policies)
            {
                foreach (var bullet in bulletsHelp)
                {
                    if (police.Area.IntersectsWith(bullet.Area))
                    {
                        police.GetShot = true;
                        this.model.Bullets.Remove(bullet);
                    }
                }
            }

            bulletsHelp.Clear();
        }

        /// <summary>
        /// Add or remove Police.
        /// </summary>
        public void PoliceDeath()
        {
            List<Police> policeList = new List<Police>();

            foreach (var police in this.model.Polices)
            {
                policeList.Add(police);
            }

            foreach (var police in policeList)
            {
                if (police.GetShot == true)
                {
                    this.model.Polices.Remove(police);
                }
            }

            policeList.Clear();
        }

        /// <summary>
        /// Spawn the polices.
        /// </summary>
        public void PoliceSpawn()
        {
            if (this.model.Polices.Count < 3)
            {
                this.model.Polices.Add(this.model.PoliceMaker());
            }
        }

        /// <summary>
        /// Ammo picking logic.
        /// </summary>
        /// <returns>ispicked.</returns>
        public bool IsAmmoPicked()
        {
            bool ispicked = false;
            if (this.model.Player.Area.IntersectsWith(this.model.Ammo.Area))
            {
                if (this.model.SumAmmo == 20)
                {
                    return ispicked;
                }

                if (this.model.SumAmmo >= 15 && this.model.SumAmmo < 20)
                {
                    this.model.SumAmmo = 20;
                }
                else
                {
                    this.model.SumAmmo += Config.AmmoPickingValue;
                }

                this.model.Ammo.ChangeX(-50000);
                this.model.Ammo.ChangeY(-50000);

                ispicked = true;

                this.ammoTimer.Start();
            }

            return ispicked;
        }

        /// <summary>
        /// Creates ammos.
        /// </summary>
        public void AmmoMaker()
        {
            double x;
            double y;
            if (this.ammoTimer.ElapsedMilliseconds > 20000)
            {
                x = this.r.Next(10, Config.Width - 50);
                y = this.r.Next(10, Config.Height - 50);

                foreach (var wall in this.model.Walls)
                {
                    if (!wall.Area.Contains(x - 25, y - 25))
                    {
                        this.model.Ammo = new MyImage(
                        x, y, 30, 30);
                        this.ammoTimer.Stop();
                        this.ammoTimer.Reset();
                    }
                }
            }
        }

        /// <summary>
        /// Gold picking logic.
        /// </summary>
        /// <returns>ispicked.</returns>
        public bool IsGoldPicked()
        {
            bool ispicked = false;
            if (this.model.Gold.Area.IntersectsWith(this.model.Player.Area))
            {
                this.model.SumMoney += Config.GoldPickingValue;
                this.model.Gold.ChangeX(-50000);
                this.model.Gold.ChangeY(-50000);
                ispicked = true;
                this.goldTimer.Start();
            }

            return ispicked;
        }

        /// <summary>
        /// Gold maker logic.
        /// </summary>
        public void GoldMaker()
        {
            double x;
            double y;
            if (this.goldTimer.ElapsedMilliseconds > 8000)
            {
              x = this.r.Next(10, Config.Width - 50);
              y = this.r.Next(10, Config.Height - 50);

              foreach (var wall in this.model.Walls)
              {
                    if (!wall.Area.IntersectsWith(this.model.Gold.Area))
                    {
                        this.model.Gold = new MyImage(
                        x, y, 50, 50);
                        this.goldTimer.Stop();
                        this.goldTimer.Reset();
                    }
              }
            }
        }

        /// <summary>
        /// Money picking logic.
        /// </summary>
        /// <returns>ispicked.</returns>
        public bool IsMoneyPicked()
        {
            bool ispicked = false;
            if (this.model.Player.Area.IntersectsWith(this.model.Euro.Area))
            {
                this.model.SumMoney += Config.EuroPickingValue;
                ispicked = true;
                this.model.Euro.ChangeX(-50000);
                this.model.Euro.ChangeY(-50000);

                this.euroTimer.Start();
            }

            return ispicked;
        }

        /// <summary>
        /// Creates moneys.
        /// </summary>
        public void EuroMaker()
        {
            double x;
            double y;
            if (this.euroTimer.ElapsedMilliseconds > 8000)
            {
                x = this.r.Next(10, Config.Width - 50);
                y = this.r.Next(10, Config.Height - 50);

                foreach (var wall in this.model.Walls)
                {
                    if (!wall.Area.Contains(x - 25, y - 25))
                    {
                        this.model.Euro = new MyImage(
                        x, y, 50, 50);
                        this.euroTimer.Stop();
                        this.euroTimer.Reset();
                    }
                }
            }
        }

        /// <summary>
        /// Health picking logic.
        /// </summary>
        /// <returns>ispicked.</returns>
        public bool IsHealthPicked()
        {
            bool ispicked = false;
            if (this.model.Player.Area.IntersectsWith(this.model.HealthBar.Area))
            {
                if (this.model.SumHealth == 100)
                {
                    return ispicked;
                }

                if (this.model.SumHealth >= 75 && this.model.SumHealth < 100)
                {
                    this.model.SumHealth = 100;
                }
                else
                {
                    this.model.SumHealth += Config.HealthPickingUp;
                }

                this.model.HealthBar.ChangeX(-50000);
                this.model.HealthBar.ChangeY(-50000);
                ispicked = true;
                this.healthTimer.Start();
            }

            return ispicked;
        }

        /// <summary>
        /// Creates healths.
        /// </summary>
        public void HealthBoxMaker()
        {
            double x;
            double y;
            if (this.healthTimer.ElapsedMilliseconds > 20000)
            {
                x = this.r.Next(10, Config.Width - 50);
                y = this.r.Next(10, Config.Height - 50);

                foreach (var wall in this.model.Walls)
                {
                    if (!wall.Area.Contains(x - 25, y - 25))
                    {
                        this.model.HealthBar = new MyImage(
                        x, y, 25, 25);
                        this.healthTimer.Stop();
                        this.healthTimer.Reset();
                    }
                }
            }
        }

        /// <summary>
        /// Professor event logic.
        /// </summary>
        public void ProfessorEvent()
        {
            int numbers;

            if (!this.professorSpawnTimer.IsRunning)
            {
                this.professorSpawnTimer.Start();
            }

            if (this.professorSpawnTimer.ElapsedMilliseconds >= 60000)
            {
                this.professorSpawnTimer.Stop();
                this.professorSpawnTimer.Reset();
                this.model.ProfessorMaker();
                this.professorExistTimer.Start();
            }

            if (this.professorExistTimer.ElapsedMilliseconds < 30000 && this.professorExistTimer.ElapsedMilliseconds > 0)
            {
                if (this.model.Player.Area.IntersectsWith(this.model.Professor.Area))
                {
                    numbers = this.r.Next(1, 4);

                    switch (numbers)
                    {
                        case 1:
                            this.model.SumAmmo += 20;
                            break;
                        case 2:
                            this.model.SumHealth = 100;
                            break;
                        case 3:
                            this.model.Polices.Clear();
                            break;
                    }

                    this.model.Professor.ChangeX(70000);
                    this.model.Professor.ChangeY(70000);
                }
            }

            if (this.professorExistTimer.ElapsedMilliseconds >= 30000)
            {
                this.professorExistTimer.Stop();
                this.professorExistTimer.Reset();
                this.model.Professor.ChangeX(70000);
                this.model.Professor.ChangeY(70000);
                this.professorSpawnTimer.Start();
            }
        }
    }
}
