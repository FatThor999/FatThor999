﻿// <copyright file="RepoLogic.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace MoneyHeist.Logic
{
    using System;
    using System.Collections.Generic;
    using MoneyHeist.Logic.Interfaces;
    using MoneyHeist.Model;
    using MoneyHeist.Repository;

    /// <summary>
    /// Repologic.
    /// </summary>
    public class RepoLogic : IRepoLogic
    {
        private readonly IRepository<IGameModel, SavedGame> repo;

        /// <summary>
        /// Initializes a new instance of the <see cref="RepoLogic"/> class.
        /// </summary>
        public RepoLogic()
        {
            this.repo = new MoneyHeistRepository();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RepoLogic"/> class.
        /// </summary>
        /// <param name="repo">Repository.</param>
        public RepoLogic(IRepository<IGameModel, SavedGame> repo)
        {
            this.repo = repo;
        }

        /// <summary>
        /// Loads the game.
        /// </summary>
        /// <param name="fileName">Filename.</param>
        /// <returns>Selected game model.</returns>
        public IGameModel LoadGameModel(string fileName)
        {
            return this.repo.LoadGame(fileName);
        }

        /// <summary>
        /// Loads the highscore.
        /// </summary>
        /// <returns>List of highscores.</returns>
        public List<SavedGame> LoadHighScores()
        {
            return this.repo.LoadHighScore();
        }

        /// <summary>
        /// Saves the game model.
        /// </summary>
        /// <param name="model">Current model.</param>
        /// <param name="text">Saved filename.</param>
        public void SaveGameModel(IGameModel model, string text)
        {
            this.repo.SaveGame(model, text);
        }

        /// <summary>
        /// Saves the highscore.
        /// </summary>
        /// <param name="model">Current model.</param>
        /// <param name="text">Saved filename.</param>
        public void SaveHighScore(IGameModel model, string text)
        {
            SavedGame savedGame = new SavedGame { Name = text, Score = model.SumMoney, Time = model.Time, Date = DateTime.Now };
            this.repo.SaveHighScore(savedGame);
        }
    }
}
