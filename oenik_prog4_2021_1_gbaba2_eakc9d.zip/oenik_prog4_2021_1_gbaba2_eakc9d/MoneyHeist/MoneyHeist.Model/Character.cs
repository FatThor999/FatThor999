﻿// <copyright file="Character.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace MoneyHeist.Model
{
    using System.Windows;

    /// <summary>
    /// Character class.
    /// </summary>
    public class Character
    {
        private Rect area;

        /// <summary>
        /// Gets area.
        /// </summary>
        public Rect Area
        {
            get { return this.area; }
        }

        /// <summary>
        /// Gets or sets Dx coordinate.
        /// </summary>
        public double Dx { get; set; }

        /// <summary>
        /// Gets or sets Dy coordinate.
        /// </summary>
        public double Dy { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Character"/> class.
        /// </summary>
        /// <param name="x">x.</param>
        /// <param name="y">y.</param>
        /// <param name="w">width.</param>
        /// <param name="h">height.</param>
        public Character(double x, double y, double w, double h)
        {
            this.area = new Rect(x, y, w, h);
            this.Dx = x;
            this.Dy = y;
        }

       /// <summary>
       /// Change x.
       /// </summary>
       /// <param name="diff">difference.</param>
        public void ChangeX(double diff)
            {
                this.area.X += diff;
            }

        /// <summary>
        /// Change y.
        /// </summary>
        /// <param name="diff">difference.</param>
        public void ChangeY(double diff)
            {
                this.area.Y += diff;
            }
    }
}
