// <copyright file="Config.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace MoneyHeist.Model
{
    using System.Windows;

    /// <summary>
    /// Config class.
    /// </summary>
    public static class Config
    {
        private static int speed = 10;

        private static double policeSpeed = 1;

        private static double bulletSpeed = 10;

        private static int policeShootingDamage = 20;

        private static int policeHitDamage = 20;

        private static int ammoPickingValue = 5;

        private static int goldPickingValue = 400000;

        private static int euroPickingValue = 200000;

        private static int healthPickingUp = 25;

        private static int width = 800;

        private static int height = 600;

        private static double policeBulletSpeed = 4;

        /// <summary>
        /// Gets or sets Speed.
        /// </summary>
        public static int Speed { get => speed; set => speed = value; }

        /// <summary>
        /// Gets or sets PoliceSpeed.
        /// </summary>
        public static double PoliceSpeed { get => policeSpeed; set => policeSpeed = value; }

        /// <summary>
        /// Gets or sets PoliceShootingDamage.
        /// </summary>
        public static int PoliceShootingDamage { get => policeShootingDamage; set => policeShootingDamage = value; }

        /// <summary>
        /// Gets or sets PoliceHitDamage.
        /// </summary>
        public static int PoliceHitDamage { get => policeHitDamage; set => policeHitDamage = value; }

        /// <summary>
        /// Gets or sets AmmoPickingValue.
        /// </summary>
        public static int AmmoPickingValue { get => ammoPickingValue; set => ammoPickingValue = value; }

        /// <summary>
        /// Gets or sets GoldPickingValue.
        /// </summary>
        public static int GoldPickingValue { get => goldPickingValue; set => goldPickingValue = value; }

        /// <summary>
        /// Gets or sets EuroPickingValue.
        /// </summary>
        public static int EuroPickingValue { get => euroPickingValue; set => euroPickingValue = value; }

        /// <summary>
        /// Gets or sets HealthPickingUp.
        /// </summary>
        public static int HealthPickingUp { get => healthPickingUp; set => healthPickingUp = value; }

        /// <summary>
        /// Gets or sets Height.
        /// </summary>
        public static int Height { get => height; set => height = value; }

        /// <summary>
        ///  Gets or sets BulletSpeed.
        /// </summary>
        public static double BulletSpeed { get => bulletSpeed; set => bulletSpeed = value; }

        /// <summary>
        /// Gets or sets Width.
        /// </summary>
        public static int Width { get => width; set => width = value; }

        /// <summary>
        /// Gets or sets policeBulletSpeed.
        /// </summary>
        public static double PoliceBulletSpeed { get => policeBulletSpeed; set => policeBulletSpeed = value; }
    }
}
