﻿// <copyright file="GameModel.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

using System;

[assembly: CLSCompliant(false)]

namespace MoneyHeist.Model
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Gamemodel class.
    /// </summary>
    public class GameModel : IGameModel
    {
        private int sumHealth;

        private int sumAmmo;

        private List<MyImage> bullets;

        private List<MyImage> policeBullets;

        private List<Police> polices;

        private List<MyImage> walls;

        private double width;

        private double height;

        private MyImage wall;

        private MyImage euro;

        private MyImage gold;

        private MyImage ammo;

        private MyImage healthBar;

        private MyImage bullet;

        private MyImage professor;

        private Character player;

        private Police policeOfficer;
        private Random r = new Random();

        /// <summary>
        /// Gets or sets sumHealth.
        /// </summary>
        public int SumHealth { get => this.sumHealth; set => this.sumHealth = value; }

        /// <summary>
        /// Gets or sets sumAmmo.
        /// </summary>
        public int SumAmmo { get => this.sumAmmo; set => this.sumAmmo = value; }

        /// <summary>
        /// Gets or sets sumMoney.
        /// </summary>
        public int SumMoney { get; set; }

        /// <summary>
        /// Gets or sets game time.
        /// </summary>
        public int Time { get; set; }

        /// <summary>
        /// Gets or sets Wall.
        /// </summary>
        public MyImage Wall { get => this.wall; set => this.wall = value; }

        /// <summary>
        /// Gets or sets Euro.
        /// </summary>
        public MyImage Euro { get => this.euro; set => this.euro = value; }

        /// <summary>
        /// Gets or sets Gold..
        /// </summary>
        public MyImage Gold { get => this.gold; set => this.gold = value; }

        /// <summary>
        /// Gets or sets Ammo..
        /// </summary>
        public MyImage Ammo { get => this.ammo; set => this.ammo = value; }

        /// <summary>
        /// Gets or sets HealthBar.
        /// </summary>
        public MyImage HealthBar { get => this.healthBar; set => this.healthBar = value; }

        /// <summary>
        /// Gets or sets Player.
        /// </summary>
        public Character Player { get => this.player; set => this.player = value; }

        /// <summary>
        /// Gets or sets PoliceOfficer.
        /// </summary>
        public Police PoliceOfficer { get => this.policeOfficer; set => this.policeOfficer = value; }

        /// <summary>
        /// Gets or sets Bullet.
        /// </summary>
        public MyImage Bullet { get => this.bullet; set => this.bullet = value; }

        /// <summary>
        /// Gets or sets Professor.
        /// </summary>
        public MyImage Professor { get => this.professor; set => this.professor = value; }

        /// <summary>
        /// Gets or sets Width.
        /// </summary>
        public double Width { get => this.width; set => this.width = value; }

        /// <summary>
        /// Gets or sets Height.
        /// </summary>
        public double Height { get => this.height; set => this.height = value; }

        /// <summary>
        /// Gets Bullets.
        /// </summary>
        public List<MyImage> Bullets { get => this.bullets; }

        /// <summary>
        /// Gets PoliceBullets.
        /// </summary>
        public List<MyImage> PoliceBullets { get => this.policeBullets; }

        /// <summary>
        /// Gets Polices.
        /// </summary>
        public List<Police> Polices
        {
            get => this.polices;
        }

        /// <summary>
        /// Gets Walls.
        /// </summary>
        public List<MyImage> Walls { get => this.walls;  }

        /// <summary>
        /// Initializes a new instance of the <see cref="GameModel"/> class.
        /// </summary>
        public GameModel()
        {
            this.height = Config.Height;
            this.width = Config.Width;
            this.player = new Character(300, 300, 50, 50);
            this.healthBar = new MyImage(this.r.Next(1, Config.Width - 20), this.r.Next(1, Config.Height - 20), 25, 25);
            this.ammo = new MyImage(this.r.Next(1, Config.Width - 50), this.r.Next(1, Config.Height - 50), 30, 30);
            this.gold = new MyImage(this.r.Next(1, Config.Width - 50), this.r.Next(1, Config.Height - 50), 50, 50);
            this.euro = new MyImage(this.r.Next(1, Config.Width - 50), this.r.Next(1, Config.Height - 50), 50, 50);
            this.wall = new MyImage(Config.Width / 2, Config.Height / 2, 30, 30);
            this.PoliceOfficer = new Police(this.r.Next(1, Config.Width - 50), this.r.Next(1, Config.Height - 50), 50, 50);
            this.professor = new MyImage(5000, 5000, 50, 50);
            this.bullet = new MyImage(0, 0, 5, 5);
            this.sumHealth = 100;
            this.sumAmmo = 20;
            this.bullet = new MyImage(0, 0, 5, 5);

            this.policeBullets = new List<MyImage>();

            this.bullets = new List<MyImage>();
            this.polices = new List<Police>()
            {
                this.policeOfficer,
                new Police(this.r.Next(1, Config.Width - 10), this.r.Next(1, Config.Height - 10), 50, 50),
                new Police(this.r.Next(1, Config.Width - 10), this.r.Next(1, Config.Height - 10), 50, 50),
            };

            this.walls = new List<MyImage>()
            {
                new MyImage(0, 500, 250, 20),
                new MyImage(260, 130, 400, 20),
                new MyImage(260, 150, 20, 250),
                new MyImage(280, 380, 200, 20),
                new MyImage(640, 150, 20, 350),
            };
        }

        /// <summary>
        /// Makes bullet.
        /// </summary>
        /// <param name="x">x.</param>
        /// <param name="y">y.</param>
        /// <returns>bullet.</returns>
        public MyImage BulletMaker(double x, double y)
        {
            MyImage bullet = new MyImage(x, y, 5, 5);

            return bullet;
        }

        /// <summary>
        /// Makes police.
        /// </summary>
        /// <returns>policeofficer.</returns>
        public Police PoliceMaker()
        {
            double x = this.r.Next(1, Config.Width - 50);
            double y = this.r.Next(1, Config.Height - 50);

            foreach (var wall in this.Walls)
            {
               if (wall.Area.Contains(x - 20, y - 20))
                {
                    x = Config.Width / 2;
                    y = Config.Height / 2;
                }
            }

            Police policeOfficer = new Police(x, y, 50, 50);
            return policeOfficer;
        }

        /// <summary>
        /// Makes professor.
        /// </summary>
        public void ProfessorMaker()
        {
            this.professor = new MyImage(50, 540, 50, 50);
        }
    }
}
