﻿// <copyright file="GlobalSuppressions.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage("StyleCop.CSharp.OrderingRules", "SA1201:Elements should appear in the correct order", Justification = "<NikGitstats.>", Scope = "member", Target = "~M:MoneyHeist.Model.Character.#ctor(System.Double,System.Double,System.Double,System.Double)")]
[assembly: SuppressMessage("StyleCop.CSharp.OrderingRules", "SA1201:Elements should appear in the correct order", Justification = "<NikGitstats.>", Scope = "member", Target = "~M:MoneyHeist.Model.Police.#ctor(System.Double,System.Double,System.Double,System.Double)")]
[assembly: SuppressMessage("StyleCop.CSharp.OrderingRules", "SA1201:Elements should appear in the correct order", Justification = "<NikGitstats.>", Scope = "member", Target = "~M:MoneyHeist.Model.MyImage.#ctor(System.Double,System.Double,System.Double,System.Double)")]
[assembly: SuppressMessage("Design", "CA1002:Do not expose generic lists", Justification = "<NikGitstats>", Scope = "member", Target = "~P:MoneyHeist.Model.IGameModel.Polices")]
[assembly: SuppressMessage("Design", "CA1002:Do not expose generic lists", Justification = "<NikGitstats>", Scope = "member", Target = "~P:MoneyHeist.Model.IGameModel.PoliceBullets")]
[assembly: SuppressMessage("Design", "CA1002:Do not expose generic lists", Justification = "<NikGitstats>", Scope = "member", Target = "~P:MoneyHeist.Model.IGameModel.Walls")]
[assembly: SuppressMessage("Design", "CA1002:Do not expose generic lists", Justification = "<NikGitstats>", Scope = "member", Target = "~P:MoneyHeist.Model.IGameModel.Bullets")]
[assembly: SuppressMessage("StyleCop.CSharp.OrderingRules", "SA1201:Elements should appear in the correct order", Justification = "<NikGitstats>", Scope = "member", Target = "~M:MoneyHeist.Model.GameModel.#ctor")]
[assembly: SuppressMessage("Security", "CA5394:Do not use insecure randomness", Justification = "<NikGitstats>", Scope = "member", Target = "~M:MoneyHeist.Model.GameModel.#ctor")]
[assembly: SuppressMessage("Security", "CA5394:Do not use insecure randomness", Justification = "<NikGitstats>", Scope = "member", Target = "~M:MoneyHeist.Model.GameModel.PoliceMaker~MoneyHeist.Model.Police")]
