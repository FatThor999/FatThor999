﻿// <copyright file="IGameModel.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace MoneyHeist.Model
{
    using System.Collections.Generic;

    /// <summary>
    /// IGameModel interface.
    /// </summary>
    public interface IGameModel
    {
        /// <summary>
        /// Gets or sets Wall.
        /// </summary>
        MyImage Wall { get; set; }

        /// <summary>
        /// Gets or sets Player..
        /// </summary>
        Character Player { get; set; }

        /// <summary>
        /// Gets or sets PoliceOfficer.
        /// </summary>
        Police PoliceOfficer { get; set; }

        /// <summary>
        /// Gets or sets Euro..
        /// </summary>
        MyImage Euro { get; set; }

        /// <summary>
        /// Gets or sets Gold..
        /// </summary>
        MyImage Gold { get; set; }

        /// <summary>
        /// Gets or sets Ammo.
        /// </summary>
        MyImage Ammo { get; set; }

        /// <summary>
        /// Gets or sets HealthBar.
        /// </summary>
        MyImage HealthBar { get; set; }

        /// <summary>
        /// Gets or sets Bullet..
        /// </summary>
        MyImage Bullet { get; set; }

        /// <summary>
        /// Gets Bullets.
        /// </summary>
        List<MyImage> Bullets { get; }

        /// <summary>
        /// Gets or sets Professor.
        /// </summary>
        MyImage Professor { get; set; }

        /// <summary>
        /// Gets or sets Time.
        /// </summary>
        public int Time { get; set; }

        /// <summary>
        /// Gets or sets sumMoney.
        /// </summary>
        public int SumMoney { get; set; }

        /// <summary>
        /// Gets or sets SumHealth.
        /// </summary>
        public int SumHealth { get; set; }

        /// <summary>
        /// Gets or sets SumAmmo.
        /// </summary>
        public int SumAmmo { get; set; }

        /// <summary>
        /// Gets Polices.
        /// </summary>
        public List<Police> Polices { get; }

        /// <summary>
        /// Gets PoliceBullets.
        /// </summary>
        public List<MyImage> PoliceBullets { get; }

        /// <summary>
        /// Gets Walls.
        /// </summary>
        public List<MyImage> Walls { get; }

        /// <summary>
        /// Makes bullets.
        /// </summary>
        /// <param name="x">x.</param>
        /// <param name="y">y.</param>
        /// <returns>Bullets.</returns>
        public MyImage BulletMaker(double x, double y);

        /// <summary>
        /// Makes Polices.
        /// </summary>
        /// <returns>Police.</returns>
        public Police PoliceMaker();

        /// <summary>
        /// Makes professor.
        /// </summary>
        public void ProfessorMaker();
    }
}
