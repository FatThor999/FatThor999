﻿// <copyright file="MyImage.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace MoneyHeist.Model
{
    using System.Windows;

    /// <summary>
    /// Myimage class.
    /// </summary>
    public class MyImage
    {
        private Rect area;

        private bool bulletIsShotedUp;
        private bool bulletIsShotedDown;
        private bool bulletIsShotedLeft;
        private bool bulletIsShotedRight;

        /// <summary>
        /// Gets or sets area.
        /// </summary>
        public Rect Area
        {
            get { return this.area; }
            set { value = this.area; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether bulletIsShotedUp.
        /// </summary>
        public bool BulletIsShotedUp { get => this.bulletIsShotedUp; set => this.bulletIsShotedUp = value; }

        /// <summary>
        /// Gets or sets a value indicating whether bulletIsShotedDown.
        /// </summary>
        public bool BulletIsShotedDown { get => this.bulletIsShotedDown; set => this.bulletIsShotedDown = value; }

        /// <summary>
        /// Gets or sets a value indicating whether bulletIsShotedLeft.
        /// </summary>
        public bool BulletIsShotedLeft { get => this.bulletIsShotedLeft; set => this.bulletIsShotedLeft = value; }

        /// <summary>
        /// Gets or sets a value indicating whether bulletIsShotedRight.
        /// </summary>
        public bool BulletIsShotedRight { get => this.bulletIsShotedRight; set => this.bulletIsShotedRight = value; }

        /// <summary>
        /// Initializes a new instance of the <see cref="MyImage"/> class.
        /// </summary>
        /// <param name="x">x.</param>
        /// <param name="y">y.</param>
        /// <param name="w">widht.</param>
        /// <param name="h">height.</param>
        public MyImage(double x, double y, double w, double h)
        {
            this.area = new Rect(x, y, w, h);
            this.bulletIsShotedUp = false;
            this.bulletIsShotedDown = false;
            this.bulletIsShotedLeft = false;
            this.bulletIsShotedRight = false;
        }

        /// <summary>
        /// Change x.
        /// </summary>
        /// <param name="diff">difference.</param>
        public void ChangeX(double diff)
        {
            this.area.X += diff;
        }

        /// <summary>
        /// Change y.
        /// </summary>
        /// <param name="diff">difference.</param>
        public void ChangeY(double diff)
        {
            this.area.Y += diff;
        }
    }
}
