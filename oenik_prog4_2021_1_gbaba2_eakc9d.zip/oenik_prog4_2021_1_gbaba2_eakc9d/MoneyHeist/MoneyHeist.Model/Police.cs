﻿// <copyright file="Police.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace MoneyHeist.Model
{
    using System.Windows;

    /// <summary>
    /// Police class.
    /// </summary>
    public class Police
    {
        private Rect area;
        private MyImage bullet;
        private bool getShot;

        /// <summary>
        /// Gets or sets dx.
        /// </summary>
        public double Dx { get; set; }

        /// <summary>
        /// Gets or sets dy.
        /// </summary>
        public double Dy { get; set; }

        /// <summary>
        /// Gets area.
        /// </summary>
        public Rect Area
        {
            get { return this.area; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether getshot.
        /// </summary>
        public bool GetShot { get => this.getShot; set => this.getShot = value; }

        /// <summary>
        /// Gets or sets bullet.
        /// </summary>
        public MyImage Bullet { get => this.bullet; set => this.bullet = value; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Police"/> class.
        /// </summary>
        /// <param name="x">x.</param>
        /// <param name="y">y.</param>
        /// <param name="w">width.</param>
        /// <param name="h">height.</param>
        public Police(double x, double y, double w, double h)
        {
            this.area = new Rect(x, y, w, h);
            this.getShot = false;
            this.Dx = x;
            this.Dy = y;
        }

        /// <summary>
        /// Change x.
        /// </summary>
        /// <param name="diff">difference.</param>
        public void ChangeX(double diff)
        {
            this.area.X += diff;
        }

        /// <summary>
        /// Change y.
        /// </summary>
        /// <param name="diff">difference.</param>
        public void ChangeY(double diff)
        {
            this.area.Y += diff;
        }

        /// <summary>
        /// Set x and y.
        /// </summary>
        /// <param name="x">x.</param>
        /// <param name="y">y.</param>
        public void SetXY(double x, double y)
        {
            this.area.X += x;
            this.area.Y += y;
        }
    }
}
