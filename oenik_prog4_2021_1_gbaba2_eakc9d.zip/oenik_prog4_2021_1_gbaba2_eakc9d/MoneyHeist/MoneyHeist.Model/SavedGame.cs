﻿// <copyright file="SavedGame.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace MoneyHeist.Model
{
    using System;

    /// <summary>
    /// Saved game properties.
    /// </summary>
    public class SavedGame
    {
        /// <summary>
        /// Gets or sets the name .
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the Score.
        /// </summary>
        public int Score { get; set; }

        /// <summary>
        /// Gets or sets the Time.
        /// </summary>
        public int Time { get; set; }

        /// <summary>
        /// Gets or sets the Date.
        /// </summary>
        public DateTime Date { get; set; }
    }
}
