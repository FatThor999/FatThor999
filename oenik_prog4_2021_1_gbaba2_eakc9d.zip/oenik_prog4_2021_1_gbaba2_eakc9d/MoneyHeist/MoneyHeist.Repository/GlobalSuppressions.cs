﻿// <copyright file="GlobalSuppressions.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage("Design", "CA1002:Do not expose generic lists", Justification = "<NikGitstats>", Scope = "member", Target = "~M:MoneyHeist.Repository.IRepository`2.LoadHighScore~System.Collections.Generic.List{`1}")]
[assembly: SuppressMessage("Design", "CA1041:Provide ObsoleteAttribute message", Justification = "<NikGitstats>", Scope = "member", Target = "~M:MoneyHeist.Repository.MoneyHeistRepository.SaveGame(MoneyHeist.Model.IGameModel,System.String)")]
[assembly: SuppressMessage("Globalization", "CA1307:Specify StringComparison for clarity", Justification = "<NikGitstats>", Scope = "member", Target = "~M:MoneyHeist.Repository.MoneyHeistRepository.SaveHighScore(MoneyHeist.Model.SavedGame)")]
