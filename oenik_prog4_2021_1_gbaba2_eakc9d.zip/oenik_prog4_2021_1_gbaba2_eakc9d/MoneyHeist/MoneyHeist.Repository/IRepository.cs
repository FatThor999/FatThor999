// <copyright file="IRepository.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace MoneyHeist.Repository
{
    using System.Collections.Generic;

    /// <summary>
    /// IRepository interface.
    /// </summary>
    /// <typeparam name="TGameModel">Gamemodel.</typeparam>
    /// <typeparam name="THighScore">Highscore.</typeparam>
    public interface IRepository<TGameModel, THighScore>
    {
        /// <summary>
        /// Loads the game.
        /// </summary>
        /// <param name="filename">filename.</param>
        /// <returns>Gamemodel.</returns>
        TGameModel LoadGame(string filename);

        /// <summary>
        /// Save the game.
        /// </summary>
        /// <param name="game">Gamemodel.</param>
        /// <param name="filename">Filename.</param>
        void SaveGame(TGameModel game, string filename);

        /// <summary>
        /// List of highscores.
        /// </summary>
        /// <returns>Highscores.</returns>
        List<THighScore> LoadHighScore();

        /// <summary>
        /// Save the highscore.
        /// </summary>
        /// <param name="highscore">highscore.</param>
        void SaveHighScore(THighScore highscore);
    }
}
