﻿// <copyright file="MoneyHeistRepository.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

using System;

[assembly: CLSCompliant(false)]

namespace MoneyHeist.Repository
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using MoneyHeist.Model;
    using Newtonsoft.Json;

    /// <summary>
    /// Implementation of IRepository.
    /// </summary>
    public class MoneyHeistRepository : IRepository<IGameModel, SavedGame>
    {
        /// <summary>
        /// Loads the game.
        /// </summary>
        /// <param name="filename">Name of the game.</param>
        /// <returns>Game model object.</returns>
        public IGameModel LoadGame(string filename)
        {
            using (StreamReader r = new StreamReader($"{filename}.json"))
            {
                string json = r.ReadToEnd();
                GameModel gameModel = JsonConvert.DeserializeObject<GameModel>(json, new JsonSerializerSettings
                {
                    TypeNameHandling = TypeNameHandling.None,
                    MissingMemberHandling = MissingMemberHandling.Ignore,
                });
                return gameModel;
            }
        }

        /// <summary>
        /// Loads a list of highscores.
        /// </summary>
        /// <returns>List of saved scores.</returns>
        public List<SavedGame> LoadHighScore()
        {
            List<SavedGame> highScores = new List<SavedGame>();
            try
            {
                using (StreamReader r = new StreamReader("highScores.json"))
                {
                    string json = r.ReadToEnd();
                    try
                    {
                        highScores = JsonConvert.DeserializeObject<List<SavedGame>>(json);
                        return highScores;
                    }
                    catch (ArgumentException)
                    {
                        highScores.Add(JsonConvert.DeserializeObject<SavedGame>(json));
                        return highScores;
                    }
                }
            }
            catch (FileNotFoundException)
            {
                return highScores;
            }
        }

        /// <summary>
        /// Saves the game.
        /// </summary>
        /// <param name="game">gamemodel.</param>
        /// <param name="filename">name of file.</param>
        [Obsolete]
        public void SaveGame(IGameModel game, string filename)
        {
            string jsonData = JsonConvert.SerializeObject(game, Formatting.Indented, new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.None,
                TypeNameAssemblyFormat = System.Runtime.Serialization.Formatters.FormatterAssemblyStyle.Simple,
            });
            jsonData = jsonData.Substring(0, jsonData.Length - 1) + $", \"SaveDate\": \"{DateTime.Now}\" }}";

            File.WriteAllText($"{filename}.json", jsonData);
        }

        /// <summary>
        /// Saves the highscore.
        /// </summary>
        /// <param name="highscore">Highscore to save.</param>
        public void SaveHighScore(SavedGame highscore)
        {
            try
            {
                string jsonData = File.ReadAllText("highscores.json");
                List<SavedGame> highScoresList;
                if (jsonData.Contains('['))
                {
                    highScoresList = JsonConvert.DeserializeObject<List<SavedGame>>(jsonData)
                        ?? new List<SavedGame>();
                }
                else
                {
                    highScoresList = new List<SavedGame>
                    {
                        JsonConvert.DeserializeObject<SavedGame>(jsonData),
                    };
                }

                highScoresList.Add(highscore);
                jsonData = JsonConvert.SerializeObject(highScoresList, Formatting.Indented);
                File.WriteAllText("highscores.json", jsonData);
            }
            catch (FileNotFoundException)
            {
                // first highscore saved
                string jsonData = JsonConvert.SerializeObject(highscore, Formatting.Indented);
                using (StreamWriter file = new StreamWriter("highScores.json"))
                {
                    File.WriteAllText("highscores.json", jsonData);
                }
            }
        }
    }
}
