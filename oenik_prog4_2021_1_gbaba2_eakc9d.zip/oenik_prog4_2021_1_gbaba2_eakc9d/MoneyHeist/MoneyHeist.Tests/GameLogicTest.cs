// <copyright file="GameLogicTest.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

using System;

[assembly: CLSCompliant(false)]

namespace MoneyHeist.Tests
{
    using MoneyHeist.Logic;
    using MoneyHeist.Model;
    using Moq;
    using NUnit.Framework;

    /// <summary>
    /// Tests for logic class.
    /// </summary>
    [TestFixture]
    public class GameLogicTest
    {
        private MoneyHeistLogic logic;
        private Mock<GameModel> mockedModel;

        /// <summary>
        /// Setup.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.mockedModel = new Mock<GameModel>();

            Character player = new Character(Config.Width / 2, Config.Height / 2, 50, 50);
            Police police = new Police((Config.Width / 2) + 51, Config.Height / 2, 50, 50);
            MyImage wall = new MyImage((Config.Width / 2) - 51, Config.Height / 2, 50, 50);
            MyImage bullet = new MyImage(Config.Width / 2, Config.Height / 2, 5, 5);
            MyImage ammo = new MyImage(Config.Width / 2, (Config.Height / 2) - 10, 20, 20);
            MyImage gold = new MyImage(Config.Width / 2, (Config.Height / 2) + 10, 20, 20);
            MyImage euro = new MyImage((Config.Width / 2) - 10, (Config.Height / 2) + 10, 20, 20);
            MyImage healthbar = new MyImage((Config.Width / 2) + 10, (Config.Height / 2) + 10, 20, 20);
            MyImage professor = new MyImage((Config.Width / 2) - 10, (Config.Height / 2) - 10, 20, 20);
            this.mockedModel.Object.Player = player;
            this.mockedModel.Object.PoliceOfficer = police;
            this.mockedModel.Object.Wall = wall;
            this.logic = new MoneyHeistLogic(this.mockedModel.Object);
            this.mockedModel.Object.Bullet = bullet;
            this.mockedModel.Object.Ammo = ammo;
            this.mockedModel.Object.Gold = gold;
            this.mockedModel.Object.Euro = euro;
            this.mockedModel.Object.HealthBar = healthbar;
            this.mockedModel.Object.Professor = professor;
        }

        /// <summary>
        /// Logic is empty test.
        /// </summary>
        [Test]
        public void LogicIsNotEmptyTest()
        {
            Assert.That(this.logic, Is.Not.Null);
        }

        /// <summary>
        /// Game ended test.
        /// </summary>
        [Test]

        public void GameEndTest()
        {
            this.mockedModel.Object.SumHealth = 0;
            this.mockedModel.Object.SumMoney = 1000;

            Assert.IsTrue(this.logic.GameEnd());
        }

        /// <summary>
        /// Enemy movement test.
        /// </summary>
        [Test]
        public void MoveEnemyTest()
        {
            this.logic.MoveEnemy();
            Assert.That(this.mockedModel.Object.PoliceOfficer.Area.X == (Config.Width / 2) + 48);
        }

        /// <summary>
        /// Player movement test.
        /// </summary>
        [Test]
        public void MovePlayerTest()
        {
            this.logic.MovePlayer(Direction.Up);
            Assert.That(this.mockedModel.Object.Player.Area.Y == (Config.Height / 2) - 10);
        }

        /// <summary>
        /// Player shoot test.
        /// </summary>
        [Test]
        public void ShootTest()
        {
            this.logic.PlayerShoot(Direction.Down);
            Assert.That(this.mockedModel.Object.Bullet.Area.Y == Config.Height + 2);

            this.logic.PlayerShoot(Direction.Left);
            Assert.That(this.mockedModel.Object.Bullet.Area.X == (Config.Width / 2) - 20);

            this.logic.PlayerShoot(Direction.Right);
            Assert.That(this.mockedModel.Object.Bullet.Area.X == (Config.Width / 2) + 60);

            this.logic.PlayerShoot(Direction.Up);
            Assert.That(this.mockedModel.Object.Bullet.Area.Y == -2);
        }

        /// <summary>
        /// Hitbox test.
        /// </summary>
        [Test]

        public void PlayerGetsShoot()
        {
            this.logic.PlayerGetsShot();
            Assert.That(this.mockedModel.Object.SumHealth == 80);
        }

        /// <summary>
        /// Police hitbox test.
        /// </summary>
        [Test]
        public void PoliceGetsShot()
        {
            this.logic.PlayerShoot(Direction.Right);
            this.logic.PoliceGetsShot();
            Assert.That(this.mockedModel.Object.PoliceOfficer, Is.Null);
        }

        /// <summary>
        /// Ammo pick test.
        /// </summary>
        [Test]
        public void IsAmmoPickedTest()
        {
            this.mockedModel.Object.SumAmmo = 13;
            this.logic.MovePlayer(Direction.Up);
            Assert.IsTrue(this.logic.IsAmmoPicked());
            Assert.That(this.mockedModel.Object.SumAmmo == 18);
        }

        /// <summary>
        /// Gold pick test.
        /// </summary>
        [Test]
        public void IsGoldPickedTest()
        {
            this.logic.MovePlayer(Direction.Down);
            Assert.IsTrue(this.logic.IsGoldPicked());
            Assert.That(this.mockedModel.Object.SumMoney == 400000);
        }

        /// <summary>
        /// Money pick test.
        /// </summary>
        [Test]
        public void IsMoneyPickedTest()
        {
            this.logic.MovePlayer(Direction.Down);
            this.logic.MovePlayer(Direction.Left);
            Assert.IsTrue(this.logic.IsMoneyPicked());
            Assert.That(this.mockedModel.Object.SumMoney == 200000);
        }

        /// <summary>
        /// Health pick test.
        /// </summary>
        [Test]
        public void IsHealthPickedTest()
        {
            this.mockedModel.Object.SumHealth = 70;
            this.logic.MovePlayer(Direction.Up);
            this.logic.MovePlayer(Direction.Left);
            Assert.IsTrue(this.logic.IsHealthPicked());
            Assert.That(this.mockedModel.Object.SumHealth == 95);
        }
    }
}
