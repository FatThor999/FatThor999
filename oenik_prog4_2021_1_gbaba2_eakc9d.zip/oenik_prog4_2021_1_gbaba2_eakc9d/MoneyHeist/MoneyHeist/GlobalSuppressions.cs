﻿// <copyright file="GlobalSuppressions.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage("Design", "CA1062:Validate arguments of public methods", Justification = "<NikGitStats>", Scope = "member", Target = "~M:MoneyHeist.MoneyHeistControl.OnRender(System.Windows.Media.DrawingContext)")]
[assembly: SuppressMessage("Globalization", "CA1305:Specify IFormatProvider", Justification = "<NikGitStats>", Scope = "member", Target = "~M:MoneyHeist.Pages.LoadGame.LoadGames~System.Collections.Generic.List{MoneyHeist.Model.SavedGame}")]
