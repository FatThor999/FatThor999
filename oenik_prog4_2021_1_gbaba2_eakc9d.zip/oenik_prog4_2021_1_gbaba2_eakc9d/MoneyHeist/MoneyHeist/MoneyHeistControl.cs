﻿// <copyright file="MoneyHeistControl.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

using System;

[assembly: CLSCompliant(false)]

namespace MoneyHeist
{
    using System;
    using System.Windows;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Threading;
    using GameRenderer;
    using MoneyHeist.Logic;
    using MoneyHeist.Model;

    /// <summary>
    /// Control class.
    /// </summary>
    public class MoneyHeistControl : FrameworkElement
    {
        private static bool gamePaused;
        private IGameModel model;
        private MoneyHeistLogic logic;
        private MoneyheistGameRenderer renderer;
        private DispatcherTimer ticktimer;
        private DispatcherTimer gameTimer;
        private DispatcherTimer policeTicktimer;
        private DispatcherTimer policeSpawnTicktimer;

        /// <summary>
        /// Initializes a new instance of the <see cref="MoneyHeistControl"/> class.
        /// </summary>
        /// <param name="model">Gamemodel.</param>
        public MoneyHeistControl(IGameModel model)
        {
            this.model = model;
            this.Loaded += this.MoneyHeistControl_Loaded;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MoneyHeistControl"/> class.
        /// </summary>
        public MoneyHeistControl()
        {
            this.Loaded += this.MoneyHeistControl_Loaded;
        }

        /// <summary>
        /// Onrender method.
        /// </summary>
        /// <param name="drawingContext">drawingcontext.</param>
        protected override void OnRender(DrawingContext drawingContext)
        {
            if (this.renderer != null)
            {
                drawingContext.DrawDrawing(this.renderer.BuildDrawing());
            }
        }

        private void MoneyHeistControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (this.model == null)
            {
                this.model = new GameModel();
                this.logic = new MoneyHeistLogic(this.model);
                this.renderer = new MoneyheistGameRenderer(this.model);
            }

            Window win = Window.GetWindow(this);
            if (win != null)
            {
                this.ticktimer = new DispatcherTimer();
                this.ticktimer.Interval = TimeSpan.FromMilliseconds(20);
                this.ticktimer.Tick += this.Ticktimer_Tick;
                this.ticktimer.Start();

                this.gameTimer = new DispatcherTimer()
                {
                    Interval = TimeSpan.FromSeconds(1),
                };
                this.gameTimer.Tick += this.Ticktimer_Tick1;
                this.gameTimer.Start();

                this.policeTicktimer = new DispatcherTimer();
                this.policeTicktimer.Interval = TimeSpan.FromSeconds(2);
                this.policeTicktimer.Tick += this.Ticktimer_Police;
                this.policeTicktimer.Start();

                this.policeSpawnTicktimer = new DispatcherTimer();
                this.policeSpawnTicktimer.Interval = TimeSpan.FromSeconds(5);
                this.policeSpawnTicktimer.Tick += this.Ticktimer_PoliceMaking;
                this.policeSpawnTicktimer.Start();

                win.KeyDown += this.Win_KeyDown;
            }

            this.InvalidateVisual();
        }

        private void Ticktimer_Tick1(object sender, EventArgs e)
        {
            if (!gamePaused)
            {
                this.model.Time++;
                this.InvalidateVisual();
            }
        }

        private void Win_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
                switch (e.Key)
                {
                    case Key.W: this.logic.MovePlayer(Direction.Up); break;
                    case Key.A: this.logic.MovePlayer(Direction.Left); break;
                    case Key.S: this.logic.MovePlayer(Direction.Down); break;
                    case Key.D: this.logic.MovePlayer(Direction.Right); break;
                    case Key.Up: this.logic.PlayerShoot(Direction.Up); break;
                    case Key.Down: this.logic.PlayerShoot(Direction.Down); break;
                    case Key.Left: this.logic.PlayerShoot(Direction.Left); break;
                    case Key.Right: this.logic.PlayerShoot(Direction.Right); break;
                }

                gamePaused = false;
                if (e.Key == Key.Escape)
                {
                SaveGame savegamewindow = new SaveGame(this.model)
                {
                    Visibility = Visibility.Visible,
                };
                this.gameTimer.Stop();
                var w = Application.Current.Windows[0];
                w.Close();
                gamePaused = true;
                }

                this.InvalidateVisual();
        }

        private void Ticktimer_Tick(object sender, EventArgs e)
        {
            if (!gamePaused && !this.logic.GameEnd())
            {
                this.logic.MoveEnemy();
                this.logic.IsGoldPicked();
                this.logic.GoldMaker();
                this.logic.PoliceGetsShot();
                this.logic.PlayerGetsShot();
                this.logic.IsMoneyPicked();
                this.logic.EuroMaker();
                this.logic.IsAmmoPicked();
                this.logic.AmmoMaker();
                this.logic.IsHealthPicked();
                this.logic.HealthBoxMaker();
                this.logic.BulletMove();
                this.logic.PoliceBulletMove();
                this.logic.PoliceDeath();
                this.logic.ProfessorEvent();
                this.InvalidateVisual();
            }
            else if (this.logic.GameEnd())
            {
                this.ticktimer.Stop();
                gamePaused = true;
                var w = Application.Current.Windows[0];
                w.Hide();
                MessageBox.Show("Game ended.");
                SaveGame savegamewindow = new SaveGame(this.model)
                {
                    Visibility = Visibility.Visible,
                };
            }
        }

        private void Ticktimer_Police(object sender, EventArgs e)
        {
            this.logic.EnemyShoot();
            this.InvalidateVisual();
        }

        private void Ticktimer_PoliceMaking(object sender, EventArgs e)
        {
            this.logic.PoliceSpawn();
            this.InvalidateVisual();
        }
    }
}
