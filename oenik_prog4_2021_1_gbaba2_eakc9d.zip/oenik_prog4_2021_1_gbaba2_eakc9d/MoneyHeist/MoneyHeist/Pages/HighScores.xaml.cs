﻿// <copyright file="HighScores.xaml.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace MoneyHeist.Pages
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using MoneyHeist.Logic;
    using MoneyHeist.Model;

    /// <summary>
    /// Interaction logic for HighScores.xaml.
    /// </summary>
    public partial class HighScores : Window
    {
        private readonly RepoLogic repoLogic;

        /// <summary>
        /// Initializes a new instance of the <see cref="HighScores"/> class.
        /// </summary>
        public HighScores()
        {
            this.InitializeComponent();
            this.repoLogic = new RepoLogic();
            Grid grid = new Grid();
            BitmapImage bmp = new BitmapImage();
            bmp.BeginInit();
            bmp.StreamSource = Assembly.GetExecutingAssembly().GetManifestResourceStream("MoneyHeist.Pages.menubackground.jpg");
            bmp.EndInit();
            ImageBrush ib = new ImageBrush(bmp);
            this.Background = ib;

            this.HighScoreList.ItemsSource = this.LoadhighScores();
        }

        private void OnCancelButtonClick(object sender, RoutedEventArgs e)
        {
            MainMenu menuWindow = new MainMenu();
            menuWindow.Show();
            this.Close();
        }

        private List<SavedGame> LoadhighScores()
        {
            List<SavedGame> highScores = this.repoLogic.LoadHighScores();
            var scores = highScores.OrderBy(x => x.Score).Reverse().ToList();
            return scores;
        }
    }
}
