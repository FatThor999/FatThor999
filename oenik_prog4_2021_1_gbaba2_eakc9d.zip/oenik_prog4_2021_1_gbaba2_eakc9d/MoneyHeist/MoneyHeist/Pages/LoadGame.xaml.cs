﻿// <copyright file="LoadGame.xaml.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace MoneyHeist.Pages
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Reflection;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using MoneyHeist.Logic;
    using MoneyHeist.Model;
    using Newtonsoft.Json.Linq;

    /// <summary>
    /// Interaction logic for LoadGame.xaml.
    /// </summary>
    public partial class LoadGame : Window
    {
        private readonly RepoLogic repoLogic;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoadGame"/> class.
        /// </summary>
        public LoadGame()
        {
            this.InitializeComponent();
            this.repoLogic = new RepoLogic();
            Grid grid = new Grid();
            BitmapImage bmp = new BitmapImage();
            bmp.BeginInit();
            bmp.StreamSource = Assembly.GetExecutingAssembly().GetManifestResourceStream("MoneyHeist.Pages.menubackground.jpg");
            bmp.EndInit();
            ImageBrush ib = new ImageBrush(bmp);
            this.Background = ib;
            List<SavedGame> games = LoadGames();
            this.GameList.ItemsSource = games;
            if (this.GameList.SelectedItem != null)
            {
                SavedGame selectedGame = (SavedGame)this.GameList.SelectedItem;
                this.Content = new MoneyHeistControl(this.repoLogic.LoadGameModel(selectedGame.Name));
            }
        }

        private static List<SavedGame> LoadGames()
        {
            List<SavedGame> games = new List<SavedGame>();
            string path = System.IO.Directory.GetCurrentDirectory();
            string[] foundFilePaths = Directory.GetFiles(Directory.GetCurrentDirectory(), "*." + "json");
            foreach (string filePath in foundFilePaths)
            {
                string fileName = filePath.Split('\\')[filePath.Split('\\').Length - 1].Split(new string[] { ".json" }, StringSplitOptions.None)[0];
                if (fileName != "highScores" && fileName != "MoneyHeist.deps" && fileName != "MoneyHeist.runtimeconfig" && fileName != "MoneyHeist.runtimeconfig.dev")
                {
                    using (StreamReader r = new StreamReader(filePath))
                    {
                        string json = r.ReadToEnd();
                        CultureInfo enUS = new CultureInfo("en-US");
                        JObject jsonObject = JObject.Parse(json);

                        SavedGame game = new SavedGame
                        {
                            Name = fileName,
                            Date = DateTime.Parse((string)jsonObject["SaveDate"]),
                            Score = (int)jsonObject["SumMoney"],
                            Time = (int)jsonObject["Time"],
                        };
                        games.Add(game);
                    }
                }
            }

            return games;
        }

        private void OnOkButtonClick(object sender, RoutedEventArgs e)
        {
            if (this.GameList.SelectedItem != null)
            {
                SavedGame selectedGame = (SavedGame)this.GameList.SelectedItem;
                MainWindow mainwindow = new MainWindow(this.repoLogic.LoadGameModel(selectedGame.Name));
                mainwindow.Show();
                this.Close();
            }
        }

        private void OnCancelButtonClick(object sender, RoutedEventArgs e)
        {
            MainMenu menuWindow = new MainMenu();
            menuWindow.Show();
            this.Close();
        }
    }
}
