﻿// <copyright file="MainMenu.xaml.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace MoneyHeist.Pages
{
    using System;
    using System.Reflection;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;

    /// <summary>
    /// Interaction logic for MainMenu.xaml.
    /// </summary>
    public partial class MainMenu : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MainMenu"/> class.
        /// </summary>
        public MainMenu()
        {
            this.InitializeComponent();
            Grid grid = new Grid();
            BitmapImage bmp = new BitmapImage();
            bmp.BeginInit();
            bmp.StreamSource = Assembly.GetExecutingAssembly().GetManifestResourceStream("MoneyHeist.Pages.menubackground.jpg");
            bmp.EndInit();
            ImageBrush ib = new ImageBrush(bmp);
            this.Background = ib;

            Task task = new Task(() =>
            {
                MainMenuTask(@"Sound\\BellaCiao.mp3");
            });
            task.Start();
        }

        private static void MainMenuTask(string path)
        {
            MediaPlayer sound = new MediaPlayer();
            sound.Open(new Uri(path, UriKind.Relative));
            sound.Volume = 0.0;
            sound.Play();
        }

        private void StartNewGameClick(object sender, RoutedEventArgs e)
        {
            Task task = new Task(() =>
            {
                MainMenuTask(@"Sounds\\BellaCiao.mp3");
            });
            task.Start();
            MainWindow mainwindow = new MainWindow();
            mainwindow.Show();
            this.Close();
        }

        private void LoadGameClick(object sender, RoutedEventArgs e)
        {
            LoadGame loadGameWindow = new LoadGame();
            loadGameWindow.Show();
            this.Close();
        }

        private void OnExitClick(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void OnHighScoreClick(object sender, RoutedEventArgs e)
        {
            HighScores loadHighScoresWindow = new HighScores();
            loadHighScoresWindow.Show();
            this.Close();
        }
    }
}
