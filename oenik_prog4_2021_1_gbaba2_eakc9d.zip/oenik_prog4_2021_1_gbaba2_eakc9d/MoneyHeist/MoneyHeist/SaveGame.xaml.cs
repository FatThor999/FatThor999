﻿// <copyright file="SaveGame.xaml.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace MoneyHeist
{
    using System;
    using System.Windows;
    using MoneyHeist.Logic;
    using MoneyHeist.Model;
    using MoneyHeist.Pages;

    /// <summary>
    /// Interaction logic for SaveGame.xaml.
    /// </summary>
    public partial class SaveGame : Window
    {
        private IGameModel model;
        private RepoLogic repoLogic;

        /// <summary>
        /// Initializes a new instance of the <see cref="SaveGame"/> class.
        /// </summary>
        /// <param name="model">Gamemodel.</param>
        public SaveGame(IGameModel model)
        {
            this.InitializeComponent();
            this.model = model;
            this.repoLogic = new RepoLogic();
        }

        private void SaveButton(object sender, RoutedEventArgs e)
        {
            this.repoLogic.SaveHighScore(this.model, this.Textbox.Text);
            this.repoLogic.SaveGameModel(this.model, this.Textbox.Text);
            MainMenu mainMenu = new MainMenu();
            mainMenu.Show();
            MessageBox.Show("Game saved");
            this.Close();
        }

        private void ExitButton(object sender, RoutedEventArgs e)
        {
            MainMenu mainMenu = new MainMenu();
            mainMenu.Show();
            this.Close();
        }
    }
}
